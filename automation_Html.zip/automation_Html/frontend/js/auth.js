// Authentication state management
const TOKEN_KEY = 'inbox_token';
const USER_KEY = 'inbox_user';

export const Auth = {
    // Get current token
    getToken() {
        return localStorage.getItem(TOKEN_KEY);
    },

    // Get current user
    getUser() {
        const user = localStorage.getItem(USER_KEY);
        return user ? JSON.parse(user) : null;
    },

    // Check if user is authenticated
    isAuthenticated() {
        const token = this.getToken();
        if (!token) return false;
        
        // Check token expiration (JWT)
        try {
            const payload = JSON.parse(atob(token.split('.')[1]));
            return payload.exp * 1000 > Date.now();
        } catch (e) {
            return false;
        }
    },

    // Check if user is admin
    isAdmin() {
        const user = this.getUser();
        return user && user.role === 'admin';
    },

    // Save auth data
    login(token, userData) {
        localStorage.setItem(TOKEN_KEY, token);
        localStorage.setItem(USER_KEY, JSON.stringify(userData));
    },

    // Clear auth data
    logout() {
        localStorage.removeItem(TOKEN_KEY);
        localStorage.removeItem(USER_KEY);
        window.location.href = '/login.html';
    },

    // Initialize auth check on page load
    init() {
        // Protect pages that require auth
        const publicPages = ['login.html', 'signup.html'];
        const currentPage = window.location.pathname.split('/').pop();
        
        if (publicPages.includes(currentPage) && this.isAuthenticated()) {
            // Redirect to dashboard if already logged in
            window.location.href = '/index.html';
        } else if (!publicPages.includes(currentPage) && !this.isAuthenticated()) {
            // Redirect to login if not authenticated
            window.location.href = '/login.html';
        }
        
        // Admin page protection
        if (currentPage === 'admin.html' && !this.isAdmin()) {
            window.location.href = '/index.html';
        }
    }
};

// Auto-initialize on import
Auth.init();