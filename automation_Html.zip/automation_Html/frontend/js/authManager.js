const AuthManager = {
  accessToken: null,
  user: null,

  load() {
    this.accessToken = sessionStorage.getItem("access_token");
    this.user = JSON.parse(sessionStorage.getItem("user"));
  },

  save({ access_token, user }) {
    this.accessToken = access_token;
    this.user = user;

    sessionStorage.setItem("access_token", access_token);
    sessionStorage.setItem("user", JSON.stringify(user));
  },

  clear() {
    this.accessToken = null;
    this.user = null;
    sessionStorage.clear();
  },

  isAuthenticated() {
    return !!this.accessToken;
  },

  hasRole(...roles) {
    return this.user && roles.includes(this.user.role);
  }
};

AuthManager.load();
export default AuthManager;
