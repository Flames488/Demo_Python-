import AuthManager from "./authManager.js";

async function refreshAccessToken() {
  const res = await fetch("/api/auth/refresh", {
    method: "POST",
    credentials: "include" // sends refresh cookie
  });

  if (!res.ok) {
    AuthManager.clear();
    window.location.href = "/login.html";
    return null;
  }

  const data = await res.json();
  AuthManager.accessToken = data.access_token;
  sessionStorage.setItem("access_token", data.access_token);
  return data.access_token;
}

export async function apiFetch(url, options = {}) {
  if (!AuthManager.accessToken) {
    window.location.href = "/login.html";
    return;
  }

  options.headers = {
    ...(options.headers || {}),
    Authorization: `Bearer ${AuthManager.accessToken}`
  };

  options.credentials = "include";

  let res = await fetch(url, options);

  if (res.status === 401) {
    const newToken = await refreshAccessToken();
    if (!newToken) return;

    options.headers.Authorization = `Bearer ${newToken}`;
    res = await fetch(url, options);
  }

  return res;
}
if (res.status === 403) {
  const data = await res.json();

  if (data.error === "Forbidden") {
    alert("You do not have permission for this action.");
    return;
  }

  if (data.error === "Upgrade required") {
    window.location.href = "/pricing.html";
    return;
  }
}

