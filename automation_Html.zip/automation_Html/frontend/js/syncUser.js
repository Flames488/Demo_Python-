@billing_bp.post("/checkout")
@jwt_required()
def create_checkout():
    data = request.json
    plan = data.get("plan")

    if plan not in ["pro", "business"]:
        return jsonify({"error": "Invalid plan"}), 400

    # create payment provider checkout here
    checkout_url = create_payment_checkout(
        user_email=current_user.email,
        plan=plan
    )

    return jsonify({"checkout_url": checkout_url})
