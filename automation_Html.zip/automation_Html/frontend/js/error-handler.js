export const ErrorHandler = {
    showError(message, isCritical = false) {
        // Create error toast
        const toast = document.createElement('div');
        toast.className = `error-toast ${isCritical ? 'critical' : ''}`;
        toast.innerHTML = `
            <i class="fas fa-exclamation-circle"></i>
            <span>${message}</span>
            <button onclick="this.parentElement.remove()">×</button>
        `;
        
        document.body.appendChild(toast);
        
        // Auto-remove after 5 seconds
        setTimeout(() => {
            if (toast.parentNode) {
                toast.remove();
            }
        }, 5000);
        
        // If critical, also log to console and analytics
        if (isCritical) {
            console.error('Critical Error:', message);
            // Send to error tracking service
        }
    },
    
    handleNetworkError(error) {
        if (!navigator.onLine) {
            this.showError('No internet connection. Please check your network.', true);
        } else {
            this.showError('Server connection failed. Please try again.', true);
        }
    },
    
    handleApiError(error) {
        this.showError(error.message || 'Something went wrong. Please try again.');
    }
};