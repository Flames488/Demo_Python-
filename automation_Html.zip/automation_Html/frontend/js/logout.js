import AuthManager from "./authManager.js";

logoutBtn.addEventListener("click", async () => {
  await fetch("/api/auth/logout", {
    method: "POST",
    credentials: "include"
  });

  AuthManager.clear();
  window.location.href = "/login.html";
});
