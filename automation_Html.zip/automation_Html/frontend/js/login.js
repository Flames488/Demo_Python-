import AuthManager from "./authManager.js";

document.querySelector("form").addEventListener("submit", async (e) => {
  e.preventDefault();

  const email = emailInput.value;
  const password = passwordInput.value;

  const res = await fetch("/api/auth/login", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    credentials: "include", // 🔥 REQUIRED for cookies
    body: JSON.stringify({ email, password })
  });

  if (!res.ok) {
    alert("Invalid login");
    return;
  }

  const data = await res.json();
  AuthManager.save(data);

  window.location.href = "/dashboard.html";
});
