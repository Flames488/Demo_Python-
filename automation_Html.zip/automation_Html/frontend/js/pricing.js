import AuthManager from "./authManager.js";

if (AuthManager.user?.plan === "pro") {
  document.querySelector("#proBtn").innerText = "Current Plan";
  document.querySelector("#proBtn").disabled = true;
}
