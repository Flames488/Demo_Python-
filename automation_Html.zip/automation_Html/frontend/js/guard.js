import AuthManager from "./authManager.js";

if (!AuthManager.isAuthenticated()) {
  window.location.replace("/login.html");
}
