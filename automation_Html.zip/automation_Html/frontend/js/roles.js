import AuthManager from "./authManager.js";

export function hasRole(...roles) {
  return AuthManager.hasRole(...roles);
}

export function requireRoleUI(...roles) {
  if (!hasRole(...roles)) {
    document.body.innerHTML = `
      <h2>Access Denied</h2>
      <p>You do not have permission to view this page.</p>
    `;
    throw new Error("Role blocked");
  }
}
