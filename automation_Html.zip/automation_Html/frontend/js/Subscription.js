import AuthManager from "./authManager.js";

export function hasPlan(...allowedPlans) {
  if (!AuthManager.user) return false;
  return allowedPlans.includes(AuthManager.user.plan);
}

export function requirePlanUI(...allowedPlans) {
  if (!hasPlan(...allowedPlans)) {
    document.body.innerHTML = `
      <div class="upgrade">
        <h2>Upgrade Required</h2>
        <p>This feature requires ${allowedPlans.join(" or ")}</p>
        <a href="/pricing.html">Upgrade Now</a>
      </div>
    `;
    throw new Error("Subscription blocked");
  }
}
