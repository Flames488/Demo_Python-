import { apiFetch } from "./api.js";

const checkoutBtn = document.getElementById("checkoutBtn");

if (checkoutBtn) {
  checkoutBtn.addEventListener("click", async () => {
    const res = await apiFetch("/api/billing/checkout", {
      method: "POST",
      headers: {
        "Content-Type": "application/json"
      },
      body: JSON.stringify({ plan: "pro" })
    });

    if (!res.ok) {
      alert("Unable to start checkout. Try again.");
      return;
    }

    const data = await res.json();
    window.location.href = data.checkout_url;
  });
}
