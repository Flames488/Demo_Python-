# Client Onboarding Checklist

- Confirm Gmail access
- Identify priority senders
- Define follow-up delays
- Choose task platform
- Enable notifications
