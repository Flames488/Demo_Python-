
# Billing Architecture (Stripe)

- Stripe Customer per client
- Subscription per plan
- Webhooks:
  - payment_succeeded → keep active
  - payment_failed → grace period
  - canceled → disable automations

Kill-switch integrated via Script Properties.
