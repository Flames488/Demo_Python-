
# Subscription Plans

## Starter — $49/month
- Email sorting
- Task creation
- Daily digest
- Email support

## Professional — $149/month
- AI email summaries
- Follow-up automation
- WhatsApp notifications
- Audit logging (30 days)

## Enterprise — $499/month
- Unlimited automations
- Full audit logs
- SLA enforcement
- Priority support
- Custom branding
