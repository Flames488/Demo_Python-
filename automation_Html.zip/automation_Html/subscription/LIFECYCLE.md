
# Client Lifecycle

1. Trial (7 days)
2. Active subscription
3. Grace period (failed payment)
4. Suspended (automation disabled)
5. Reactivation

Automations respect lifecycle state.
