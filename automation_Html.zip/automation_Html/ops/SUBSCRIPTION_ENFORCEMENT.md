
# Subscription Enforcement

- Subscription status checked daily
- If inactive:
  - Disable triggers
  - Log suspension
  - Notify client

Manual override available for admins.
