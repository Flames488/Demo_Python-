# Google Apps Script Setup

1. Go to script.google.com
2. Create new project
3. Paste main.gs
4. Set triggers:
   - Time-driven (daily summary)
   - Gmail trigger (new mail)
