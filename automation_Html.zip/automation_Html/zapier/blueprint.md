# Zapier Automation Blueprint

## Zap 1: Gmail → Task Creation
Trigger: New Gmail label = Action Required
Actions:
- Parse email
- Create task (Todoist / Google Tasks / Notion)

## Zap 2: Follow-Up Reminder
Trigger: Gmail label = Waiting for Reply
Delay: 3 days
Condition: No reply
Action: Slack / Email reminder

## Zap 3: Daily Digest
Trigger: Every weekday 8am
Action: Compile open tasks → Send email
