
# White-Label Deployment Guide

For each client:
1. Duplicate Google Sheet (Tasks + AuditLog)
2. Set Script Properties:
   - CLIENT_NAME
   - LABELS
   - WHATSAPP NUMBER
3. Customize email summaries tone
4. Rebrand daily digests

This allows unlimited clients from one codebase.
