
# Agency White-Label Proposal

## Offering
White-labeled inbox automation for your clients.

## Benefits
- Recurring revenue
- No development overhead
- Custom branding

## Pricing
Setup: $5,000
Monthly: $999

## Support
Priority SLA & dedicated channel.
