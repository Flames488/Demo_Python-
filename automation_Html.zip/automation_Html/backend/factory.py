
from flask import Flask
from .config import settings
from .middleware import register_middleware

def create_app():
    app = Flask(__name__)
    app.config["SECRET_KEY"] = settings.SECRET_KEY

    register_middleware(app)

    @app.get("/health")
    def health():
        return {"status": "ok"}, 200

    return app
