# backend/config.py

from functools import lru_cache
from typing import Optional

from pydantic import AnyUrl, Field, ValidationError
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    """
    Centralized application configuration.
    Fails fast if anything critical is missing or malformed.
    """

    # -----------------------------
    # Core App
    # -----------------------------
    APP_NAME: str = "Automation Backend"
    ENVIRONMENT: str = Field(
        default="development",
        pattern="^(development|staging|production)$",
        description="App runtime environment",
    )
    DEBUG: bool = False

    # -----------------------------
    # Server
    # -----------------------------
    HOST: str = "0.0.0.0"
    PORT: int = Field(default=8000, ge=1, le=65535)

    # -----------------------------
    # Security
    # -----------------------------
    SECRET_KEY: str = Field(
        min_length=32,
        description="Cryptographic secret key (REQUIRED in production)",
    )

    # -----------------------------
    # Database
    # -----------------------------
    DATABASE_URL: AnyUrl = Field(
        description="Database connection URL",
    )

    # -----------------------------
    # External Services (Optional)
    # -----------------------------
    REDIS_URL: Optional[AnyUrl] = None
    STRIPE_SECRET_KEY: Optional[str] = None
    STRIPE_WEBHOOK_SECRET: Optional[str] = None

    # -----------------------------
    # Logging
    # -----------------------------
    LOG_LEVEL: str = Field(
        default="INFO",
        pattern="^(DEBUG|INFO|WARNING|ERROR|CRITICAL)$",
    )

    # -----------------------------
    # Pydantic Settings Config
    # -----------------------------
    model_config = SettingsConfigDict(
    env_file="backend/.env",
    env_file_encoding="utf-8",
    case_sensitive=True,
    extra="forbid",
    )



@lru_cache
def get_settings() -> Settings:
    """
    Cached settings loader.
    Ensures settings are only parsed once per process.
    """
    try:
        return Settings()
    except ValidationError as e:
        # 🔥 Fail fast with readable error
        print("\n❌ CONFIGURATION ERROR ❌\n")
        print(e)
        print("\nFix your environment variables and restart.\n")
        raise


# ✅ EXPORT FOR APP USAGE
# This is what fixes your ImportError
settings = get_settings()
