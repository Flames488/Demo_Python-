
from flask import request, abort
from flask_limiter import Limiter
from flask_limiter.util import get_remote_address

limiter = Limiter(key_func=get_remote_address)

def register_middleware(app):
    limiter.init_app(app)

    @app.before_request
    def enforce_auth():
        if request.endpoint in {"health"}:
            return
        token = request.headers.get("Authorization")
        if not token:
            abort(401)

    limiter.limit("100/minute")(app)
