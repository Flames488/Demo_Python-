
from app.billing.guards import validate_subscription

def test_subscription_validation():
    user = {"subscription_active": False}
    try:
        validate_subscription(user)
        assert False
    except PermissionError:
        assert True
