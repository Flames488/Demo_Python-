import pytest
from unittest.mock import patch, MagicMock
from datetime import datetime, timedelta

# Adjust imports based on your actual module structure
from app.billing.service import create_billing_event
from app.billing.models import BillingEvent, UsageRecord
from app.subscriptions.service import (
    activate_subscription, 
    user_has_active_plan, 
    check_feature_access
)
from app.models.user import User