# tests/billing_payments/test_simple.py
import pytest
from app.models.user import User


def test_simple_user_creation(db_session):
    """Minimal test to verify setup works"""
    user = User(email="test@example.com", role="user")
    user.set_password("password123")
    db_session.add(user)
    db_session.commit()
    
    assert user.id is not None
    assert user.email == "test@example.com"