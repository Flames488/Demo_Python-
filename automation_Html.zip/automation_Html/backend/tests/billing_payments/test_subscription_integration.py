import pytest
from datetime import datetime, timedelta
from app.subscriptions.middleware import subscription_required
from app.models.user import User
from app.billing.models import UsageRecord
from unittest.mock import patch