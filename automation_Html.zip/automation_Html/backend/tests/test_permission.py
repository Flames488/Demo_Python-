import pytest
from flask import session
from app.models.user import User

@pytest.fixture
def admin_user(db):
    """Create an admin user fixture"""
    admin = User(email="admin@test.com", role="admin")
    admin.set_password("password123")
    db.session.add(admin)
    db.session.commit()
    return admin

@pytest.fixture
def regular_user(db):
    """Create a regular user fixture"""
    user = User(email="user@test.com", role="user")
    user.set_password("password123")
    db.session.add(user)
    db.session.commit()
    return user

def test_admin_access(client, auth, admin_user):
    """Test admin user can access admin routes"""
    # Login as admin
    auth.login("admin@test.com", "password123")
    
    # Should be able to access admin route
    response = client.get("/admin/analytics/stats")
    assert response.status_code == 200
    
    # Check response contains admin data
    data = response.get_json()
    assert data is not None

def test_user_cannot_access_admin(client, auth, regular_user):
    """Test regular user cannot access admin routes"""
    # Login as regular user
    auth.login("user@test.com", "password123")
    
    # Should NOT be able to access admin route
    response = client.get("/admin/analytics/stats")
    assert response.status_code == 403  # Forbidden
    
    # Check error message
    data = response.get_json()
    assert "error" in data
    assert "403" in data.get('error', '') or "Forbidden" in data.get('error', '')

def test_unauthenticated_cannot_access_protected(client):
    """Test unauthenticated users cannot access protected routes"""
    # Without login, should get 401 or redirect
    response = client.get("/admin/analytics/stats")
    assert response.status_code in [401, 302]  # Unauthorized or redirect to login
    
    if response.status_code == 302:
        assert "/login" in response.location

def test_role_hierarchy(client, auth, db):
    """Test different user roles and their permissions"""
    # Test supervisor role
    supervisor = User(email="supervisor@test.com", role="supervisor")
    supervisor.set_password("password123")
    db.session.add(supervisor)
    db.session.commit()
    
    auth.login("supervisor@test.com", "password123")
    
    # Supervisor should have some admin privileges
    response = client.get("/admin/dashboard")
    assert response.status_code in [200, 403]  # Depends on your implementation
    
    # Test viewer role
    viewer = User(email="viewer@test.com", role="viewer")
    viewer.set_password("password123")
    db.session.add(viewer)
    db.session.commit()
    
    auth.login("viewer@test.com", "password123")
    
    # Viewer should have limited access
    response = client.get("/admin/analytics/stats")
    assert response.status_code == 403

def test_csrf_protection(client, auth, regular_user):
    """Test that admin routes are protected against CSRF"""
    # Login first
    auth.login("user@test.com", "password123")
    
    # Try to access admin route without proper headers/tokens
    response = client.post("/admin/users/delete/1", data={})
    assert response.status_code in [403, 400]  # Should fail

def test_admin_user_management(client, auth, admin_user):
    """Test admin can manage users"""
    auth.login("admin@test.com", "password123")
    
    # Admin should be able to list users
    response = client.get("/admin/users")
    assert response.status_code == 200
    
    # Admin should be able to create users
    new_user_data = {
        "email": "newuser@test.com",
        "password": "password123",
        "role": "user"
    }
    response = client.post("/admin/users", json=new_user_data)
    assert response.status_code == 201  # Created