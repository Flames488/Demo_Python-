import pytest
from flask import session
from unittest.mock import patch, MagicMock, Mock
from app.models.gmail_token import GmailToken
from app.services.gmail_service import GmailService

def test_gmail_connect_requires_login(client):
    """Test that connecting to Gmail requires authentication"""
    response = client.get("/gmail/connect")
    # Should redirect to login or return 401
    assert response.status_code in [302, 401]

def test_gmail_connect_logged_in(client, auth):
    """Test Gmail connect endpoint when logged in"""
    # Login first
    auth.login("test@example.com", "password123")
    
    response = client.get("/gmail/connect")
    assert response.status_code == 302  # Should redirect to Google OAuth
    assert "accounts.google.com" in response.location

def test_gmail_connect_sets_state(client, auth):
    """Test that OAuth state is stored in session"""
    auth.login("test@example.com", "password123")
    
    with client:
        response = client.get("/gmail/connect")
        assert 'oauth_state' in session
        assert session['oauth_state'] is not None
        # State should be a string
        assert isinstance(session['oauth_state'], str)
        assert len(session['oauth_state']) > 0

def test_gmail_callback_invalid_state(client, auth):
    """Test callback with invalid state parameter"""
    auth.login("test@example.com", "password123")
    
    with client:
        # Set a state in session
        session['oauth_state'] = 'valid_state_123'
        
        # Call callback with different state
        response = client.get("/gmail/callback?state=invalid_state&code=test_code")
        assert response.status_code == 400
        assert b"Invalid state parameter" in response.data

def test_gmail_callback_missing_code(client, auth):
    """Test callback without authorization code"""
    auth.login("test@example.com", "password123")
    
    with client:
        session['oauth_state'] = 'test_state'
        response = client.get("/gmail/callback?state=test_state")
        assert response.status_code == 400
        assert b"No authorization code" in response.data

@pytest.fixture
def mock_requests():
    """Fixture to mock requests library"""
    with patch('app.api.gmail.routes.requests') as mock_requests:
        yield mock_requests

def test_gmail_callback_success(mock_requests, client, auth, db):
    """Test successful OAuth callback"""
    # Login user
    auth.login("test@example.com", "password123")
    
    # Mock the token exchange response
    mock_response = MagicMock()
    mock_response.status_code = 200
    mock_response.json.return_value = {
        'access_token': 'mock_access_token',
        'refresh_token': 'mock_refresh_token',
        'expires_in': 3600,
        'token_type': 'Bearer'
    }
    mock_requests.post.return_value = mock_response
    
    with client:
        session['oauth_state'] = 'test_state'
        response = client.get(
            "/gmail/callback?state=test_state&code=auth_code_123",
            follow_redirects=False
        )
        
        # Should redirect to dashboard
        assert response.status_code == 302
        assert '/dashboard' in response.location
        
        # Check if token was saved to database
        token = GmailToken.query.filter_by(user_email="test@example.com").first()
        assert token is not None
        assert token.access_token == 'mock_access_token'
        assert token.refresh_token == 'mock_refresh_token'

def test_gmail_callback_token_exchange_failure(mock_requests, client, auth):
    """Test OAuth callback when token exchange fails"""
    auth.login("test@example.com", "password123")
    
    # Mock failed token exchange
    mock_response = MagicMock()
    mock_response.status_code = 400
    mock_response.json.return_value = {'error': 'invalid_grant'}
    mock_requests.post.return_value = mock_response
    
    with client:
        session['oauth_state'] = 'test_state'
        response = client.get("/gmail/callback?state=test_state&code=auth_code_123")
        assert response.status_code == 400
        assert b"Failed to exchange authorization code" in response.data

def test_gmail_sync_requires_login(client):
    """Test that sync endpoint requires authentication"""
    response = client.get("/gmail/sync")
    assert response.status_code in [302, 401]

def test_gmail_sync_logged_in(client, auth):
    """Test sync endpoint when logged in"""
    auth.login("test@example.com", "password123")
    
    response = client.get("/gmail/sync")
    assert response.status_code == 202  # Accepted
    data = response.get_json()
    assert "status" in data
    assert "sync initiated" in data['status']

@pytest.fixture
def mock_gmail_service():
    """Fixture to mock GmailService"""
    with patch('app.api.gmail.routes.GmailService') as mock_service:
        yield mock_service

def test_gmail_sync_with_token(mock_gmail_service, client, auth, db):
    """Test sync when user has Gmail token"""
    auth.login("test@example.com", "password123")
    
    # Add a Gmail token for the user
    token = GmailToken(
        user_email="test@example.com",
        access_token="test_token",
        refresh_token="refresh_token",
        expires_at=9999999999  # Far future
    )
    db.session.add(token)
    db.session.commit()
    
    # Mock the sync_emails method
    mock_instance = MagicMock()
    mock_instance.sync_emails.return_value = {"synced": 5, "status": "success"}
    mock_gmail_service.return_value = mock_instance
    
    response = client.get("/gmail/sync")
    assert response.status_code == 202
    
    # Verify sync was called with the correct token
    mock_gmail_service.assert_called_once_with("test@example.com")
    mock_instance.sync_emails.assert_called_once()

def test_gmail_sync_without_token(client, auth, db):
    """Test sync when user doesn't have Gmail token"""
    auth.login("test@example.com", "password123")
    
    # Ensure no token exists
    token = GmailToken.query.filter_by(user_email="test@example.com").first()
    assert token is None
    
    response = client.get("/gmail/sync")
    assert response.status_code == 202  # Still accepted
    
    # Check response indicates no token
    data = response.get_json()
    assert "status" in data

def test_gmail_disconnect(client, auth, db):
    """Test disconnecting Gmail"""
    auth.login("test@example.com", "password123")
    
    # Add a token first
    token = GmailToken(
        user_email="test@example.com",
        access_token="test_token",
        refresh_token="refresh_token"
    )
    db.session.add(token)
    db.session.commit()
    
    # Verify token exists before disconnect
    assert GmailToken.query.filter_by(user_email="test@example.com").first() is not None
    
    # Test disconnect endpoint
    response = client.delete("/gmail/disconnect")
    
    # Should return 204 (No Content) or 200
    assert response.status_code in [200, 204]
    
    # Verify token was removed
    assert GmailToken.query.filter_by(user_email="test@example.com").first() is None

def test_gmail_disconnect_no_token(client, auth):
    """Test disconnect when no token exists"""
    auth.login("test@example.com", "password123")
    
    response = client.delete("/gmail/disconnect")
    assert response.status_code == 404  # Not found

@patch.object(GmailService, 'get_user_info')
def test_gmail_status(mock_get_info, client, auth, db):
    """Test Gmail connection status endpoint"""
    auth.login("test@example.com", "password123")
    
    # Add a token
    token = GmailToken(
        user_email="test@example.com",
        access_token="test_token",
        refresh_token="refresh_token"
    )
    db.session.add(token)
    db.session.commit()
    
    mock_get_info.return_value = {
        "email": "test@gmail.com",
        "connected": True,
        "name": "Test User"
    }
    
    response = client.get("/gmail/status")
    assert response.status_code == 200
    
    data = response.get_json()
    assert data['connected'] is True
    assert data['email'] == "test@gmail.com"
    assert 'last_sync' in data  # Optional: Add last sync timestamp to response

def test_gmail_status_not_connected(client, auth, db):
    """Test status when Gmail is not connected"""
    auth.login("test@example.com", "password123")
    
    # Ensure no token exists
    token = GmailToken.query.filter_by(user_email="test@example.com").first()
    assert token is None
    
    response = client.get("/gmail/status")
    assert response.status_code == 200
    
    data = response.get_json()
    assert data['connected'] is False
    assert data.get('email') is None