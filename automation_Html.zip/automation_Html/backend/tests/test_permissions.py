
from app.security.permissions import admin_required
from flask import Flask, g

def test_admin_required_blocks_non_admin():
    app = Flask(__name__)

    @app.route("/admin")
    @admin_required
    def admin():
        return "ok"

    with app.test_request_context():
        g.current_user = {"role": "user"}
        res = admin()
        assert res[1] == 403
