# tests/conftest.py
import pytest
from datetime import datetime, timedelta

# Import only what you need
try:
    from app.billing.models import BillingEvent, UsageRecord
    from app.models.user import User
except ImportError:
    # Handle import errors if running tests differently
    pass


@pytest.fixture
def free_user(db_session):
    """Create a free tier user"""
    from app.models.user import User
    user = User(email="free-test@example.com", role="user")
    user.set_password("password123")
    user.subscription_plan = "free"
    user.subscription_status = "active"
    db_session.add(user)
    db_session.commit()
    return user


@pytest.fixture
def pro_user(db_session):
    """Create a pro tier user"""
    from app.models.user import User
    user = User(email="pro-test@example.com", role="user")
    user.set_password("password123")
    user.subscription_plan = "pro"
    user.subscription_status = "active"
    user.subscription_expires_at = datetime.utcnow() + timedelta(days=30)
    db_session.add(user)
    db_session.commit()
    return user


@pytest.fixture
def admin_user(db_session):
    """Create an admin user"""
    from app.models.user import User
    user = User(email="admin-test@example.com", role="admin")
    user.set_password("password123")
    db_session.add(user)
    db_session.commit()
    return user


@pytest.fixture
def billing_event_factory(db_session):
    """Factory for creating billing events"""
    def factory(user_id, amount=1000, status="completed"):
        import uuid
        from app.billing.models import BillingEvent
        event = BillingEvent(
            idempotency_key=str(uuid.uuid4()),
            user_id=user_id,
            amount=amount,
            currency="NGN",
            status=status
        )
        db_session.add(event)
        db_session.commit()
        return event
    return factory


@pytest.fixture
def usage_record_factory(db_session):
    """Factory for creating usage records"""
    def factory(user_id, feature="api_calls", used=0, limit=100):
        from app.billing.models import UsageRecord
        record = UsageRecord(
            user_id=user_id,
            feature=feature,
            used=used,
            limit=limit,
            reset_at=datetime.utcnow() + timedelta(days=30)
        )
        db_session.add(record)
        db_session.commit()
        return record
    return factory