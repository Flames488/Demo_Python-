# backend/tests/test_rate_limit.py
import time
import pytest
from flask.testing import FlaskClient

def test_login_rate_limit(client: FlaskClient):
    """Test that login endpoint has rate limiting."""
    # Try 6 requests in quick succession
    responses = []
    for i in range(6):
        response = client.post('/auth/login', json={
            'email': f'test{i}@example.com',
            'password': 'wrongpassword'
        })
        responses.append(response.status_code)
        time.sleep(0.1)  # Small delay
    
    # The 6th request should be rate limited (429)
    assert 429 in responses, "Rate limiting not working"
    assert responses.count(429) >= 1, "Should have at least one rate limited response"