import pytest
from flask import session, url_for

def test_login_page(client):
    """Test that login page loads successfully"""
    res = client.get("/login")
    assert res.status_code == 200
    assert b"Login" in res.data  # Check for login form

def test_login_success(client, auth):
    """Test successful login"""
    response = auth.login("test@example.com", "password123")
    assert response.status_code == 200
    assert "access_token" in response.get_json()

def test_login_invalid_credentials(client, auth):
    """Test login with invalid credentials"""
    response = auth.login("test@example.com", "wrongpassword")
    assert response.status_code == 401

def test_logout(client, auth):
    """Test logout functionality"""
    # Login first
    auth.login("test@example.com", "password123")
    
    # Logout
    response = client.post("/logout")
    assert response.status_code == 200
    
    # Verify protected route is now inaccessible
    response = client.get("/protected-route")
    assert response.status_code in [401, 302]

def test_protected_route_requires_auth(client):
    """Test that protected routes require authentication"""
    response = client.get("/dashboard")
    assert response.status_code in [401, 302]  # Unauthorized or redirect to login