# tests/test_paystack_webhook.py
import pytest
from unittest.mock import Mock

def test_verify_paystack_signature():
    secret = "test_secret"
    payload = b'{"event": "charge.success"}'
    
    # Generate valid signature
    import hmac
    import hashlib
    valid_signature = hmac.new(
        secret.encode("utf-8"),
        payload,
        hashlib.sha512
    ).hexdigest()
    
    # Mock settings
    settings.PAYSTACK_SECRET = secret
    
    # Should return True
    assert verify_paystack(valid_signature, payload) == True
    
    # Should return False for invalid signature
    assert verify_paystack("invalid_signature", payload) == False