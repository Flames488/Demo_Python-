# tests/fixtures.py
import pytest
from datetime import datetime, timedelta
import uuid


def create_free_user(db_session, email=None):
    """Helper to create free user"""
    from app.models.user import User
    if not email:
        email = f"free-{uuid.uuid4().hex[:8]}@example.com"
    user = User(email=email, role="user")
    user.set_password("password123")
    user.subscription_plan = "free"
    user.subscription_status = "active"
    db_session.add(user)
    db_session.commit()
    return user


def create_pro_user(db_session, email=None):
    """Helper to create pro user"""
    from app.models.user import User
    if not email:
        email = f"pro-{uuid.uuid4().hex[:8]}@example.com"
    user = User(email=email, role="user")
    user.set_password("password123")
    user.subscription_plan = "pro"
    user.subscription_status = "active"
    user.subscription_expires_at = datetime.utcnow() + timedelta(days=30)
    db_session.add(user)
    db_session.commit()
    return user