from app.config import settings


def validate_env():
    assert settings.STRIPE_SECRET_KEY, "Stripe secret key missing"
    assert settings.PAYSTACK_SECRET, "Paystack secret missing"
    assert settings.SECRET_KEY, "App secret key missing"
