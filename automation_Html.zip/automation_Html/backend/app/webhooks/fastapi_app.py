# app/webhooks/fastapi_app.py
from fastapi import FastAPI, Request, HTTPException
from fastapi.responses import JSONResponse
import time

app = FastAPI(title="Webhooks API", version="1.0.0")

class RateLimitExceeded(Exception):
    def __init__(self, detail: str = "Rate limit exceeded"):
        self.detail = detail

async def rate_limit_exceeded_handler(request: Request, exc: RateLimitExceeded):
    return JSONResponse(
        status_code=429,
        content={"error": "rate_limit_exceeded", "message": exc.detail}
    )

app.add_exception_handler(RateLimitExceeded, rate_limit_exceeded_handler)

@app.middleware("http")
async def add_process_time_header(request: Request, call_next):
    start_time = time.time()
    response = await call_next(request)
    process_time = time.time() - start_time
    response.headers["X-Process-Time"] = str(process_time)
    return response

# Import your FastAPI routers
from app.webhooks.routes import router as webhook_router

app.include_router(webhook_router, prefix="/webhooks", tags=["webhooks"])