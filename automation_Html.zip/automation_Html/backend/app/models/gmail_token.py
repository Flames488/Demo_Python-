from app.extensions import db

class GmailToken(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, nullable=False)
    access_token = db.Column(db.Text)
    refresh_token = db.Column(db.Text)