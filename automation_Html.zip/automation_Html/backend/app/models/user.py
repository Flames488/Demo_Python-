from flask_login import UserMixin
from werkzeug.security import generate_password_hash, check_password_hash
from app.extensions import db, login_manager
from datetime import datetime

class User(UserMixin, db.Model):
    __tablename__ = 'users'
    
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(80), unique=True, nullable=False)
    email = db.Column(db.String(255), unique=True, nullable=False)  # Increased length from 120 to 255
    password_hash = db.Column(db.String(256), nullable=False)
    first_name = db.Column(db.String(50))
    last_name = db.Column(db.String(50))
    role = db.Column(db.String(50), nullable=False, default='user')  # Made nullable=False and increased length from 20 to 50
    
    # Stripe-related fields (integrated from your existing code)
    stripe_customer_id = db.Column(db.String, unique=True)
    stripe_subscription_id = db.Column(db.String)
    
    # Payment customer ID field (compatible with your existing stripe_customer_id)
    payment_customer_id = db.Column(db.String(120), nullable=True)
    
    # Plan and subscription fields (integrated from both versions)
    plan = db.Column(db.String(20), default="free")
    subscription_status = db.Column(db.String, default="inactive")  # From your existing code
    plan_expires_at = db.Column(db.DateTime, nullable=True)
    
    # Security and status fields
    is_active = db.Column(db.Boolean, default=True)
    is_locked = db.Column(db.Boolean, default=False)
    failed_login_attempts = db.Column(db.Integer, default=0)
    last_login_at = db.Column(db.DateTime)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # Password methods
    def set_password(self, password):
        self.password_hash = generate_password_hash(password)
        self.updated_at = datetime.utcnow()
    
    def check_password(self, password):
        return check_password_hash(self.password_hash, password)
    
    # Flask-Login required methods
    def get_id(self):
        return str(self.id)
    
    def is_authenticated(self):
        return True
    
    def is_active_user(self):  # Renamed to avoid conflict with is_active column
        return self.is_active
    
    def is_anonymous(self):
        return False
    
    # Security methods
    def reset_failed_logins(self):
        self.failed_login_attempts = 0
        self.is_locked = False
        self.updated_at = datetime.utcnow()
        db.session.commit()
    
    def lock_account(self):
        self.is_locked = True
        self.updated_at = datetime.utcnow()
        db.session.commit()
    
    # Role helper properties
    @property
    def is_admin(self):
        return self.role == "admin"
    
    @property
    def is_user(self):
        return self.role == "user"
    
    # Optional: Add more role helpers if needed
    @property
    def is_moderator(self):
        return self.role == "moderator"
    
    # Optional: Role checking method
    def has_role(self, role_name):
        return self.role == role_name
    
    # Plan helper properties
    @property
    def is_premium(self):
        return self.plan == "premium"
    
    @property
    def is_enterprise(self):
        return self.plan == "enterprise"
    
    @property
    def plan_is_active(self):
        """Check if the user's plan is still active based on expiration date"""
        if not self.plan_expires_at:
            return True
        return datetime.utcnow() < self.plan_expires_at
    
    # Payment helper properties (compatible with both stripe_customer_id and payment_customer_id)
    @property
    def has_payment_customer_id(self):
        """Check if the user has a payment customer ID set"""
        return bool(self.payment_customer_id or self.stripe_customer_id)
    
    @property
    def customer_id(self):
        """Get the primary customer ID (prioritizes stripe_customer_id for backward compatibility)"""
        return self.stripe_customer_id or self.payment_customer_id
    
    # Subscription helper properties
    @property
    def has_active_subscription(self):
        """Check if the user has an active subscription"""
        return self.subscription_status == "active"
    
    @property
    def subscription_is_active(self):
        """Alias for has_active_subscription for backward compatibility"""
        return self.has_active_subscription
    
    # Method to update customer IDs
    def set_customer_id(self, customer_id, provider="stripe"):
        """Set customer ID for a specific payment provider"""
        if provider == "stripe":
            self.stripe_customer_id = customer_id
        else:
            self.payment_customer_id = customer_id
        self.updated_at = datetime.utcnow()

@login_manager.user_loader
def load_user(user_id):
    return User.query.get(int(user_id))