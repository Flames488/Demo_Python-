
from app.extensions.db import db
from datetime import datetime

class AuditLog(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    actor = db.Column(db.String(120))
    action = db.Column(db.String(255))
    correlation_id = db.Column(db.String(64))
    timestamp = db.Column(db.DateTime, default=datetime.utcnow)
