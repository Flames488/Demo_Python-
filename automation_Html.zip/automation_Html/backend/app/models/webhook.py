# models/webhook.py
from sqlalchemy import Column, String, DateTime, Boolean, Integer, Float, JSON, Text
from sqlalchemy.dialects.postgresql import UUID
import uuid
from datetime import datetime

from app.database.base import Base


class WebhookLog(Base):
    """Model for storing webhook processing logs"""
    __tablename__ = "webhook_logs"
    
    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    event_id = Column(String, nullable=False, index=True)
    event_type = Column(String, nullable=False, index=True)
    livemode = Column(Boolean, nullable=False)
    created = Column(DateTime, nullable=False)
    processing_start = Column(DateTime, nullable=False)
    processing_end = Column(DateTime)
    processing_time_ms = Column(Float)
    attempts = Column(Integer, default=1)
    success = Column(Boolean, nullable=False)
    error_message = Column(Text)
    payload = Column(JSON)
    created_at = Column(DateTime, default=datetime.utcnow)
    
    __table_args__ = (
        Index('ix_webhook_logs_event_id_type', 'event_id', 'event_type'),
        Index('ix_webhook_logs_created', 'created'),
        Index('ix_webhook_logs_success', 'success'),
    )