from datetime import datetime
from typing import Optional, TYPE_CHECKING
from sqlalchemy import Column, Integer, String, Boolean, DateTime
from sqlalchemy.orm import declarative_base, validates

if TYPE_CHECKING:
    from sqlalchemy.orm import Session

Base = declarative_base()


class Subscription(Base):
    """Represents a user's subscription to a service plan."""
    
    __tablename__ = "subscriptions"

    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, nullable=False, index=True)
    plan_id = Column(String(50), nullable=False)
    provider = Column(String(50), nullable=False)
    is_active = Column(Boolean, default=True, nullable=False)
    current_period_end = Column(DateTime, nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow, nullable=False)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow, nullable=False)

    __table_args__ = (
        # Add indexes for common query patterns
        Index("idx_subscription_user_active", "user_id", "is_active"),
        Index("idx_subscription_active_period", "is_active", "current_period_end"),
    )

    @validates("plan_id", "provider")
    def validate_string_length(self, key: str, value: str) -> str:
        """Validate string field lengths."""
        max_length = 50  # Based on column definition
        if len(value) > max_length:
            raise ValueError(f"{key} must be at most {max_length} characters")
        return value

    @validates("current_period_end")
    def validate_future_date(self, key: str, value: Optional[datetime]) -> Optional[datetime]:
        """Validate that current_period_end is in the future if set."""
        if value and value < datetime.utcnow():
            raise ValueError("current_period_end must be in the future")
        return value

    @classmethod
    def get_active_for_user(cls, user_id: int, session: Optional["Session"] = None) -> Optional["Subscription"]:
        """
        Retrieve the active subscription for a given user.
        
        Args:
            user_id: The ID of the user
            session: Optional database session (will create one if not provided)
            
        Returns:
            Optional[Subscription]: Active subscription or None if not found
            
        Raises:
            ValueError: If user_id is not positive
        """
        if user_id <= 0:
            raise ValueError("user_id must be a positive integer")

        if session is None:
            from app.db import session_factory
            with session_factory() as session:
                return cls._query_active_subscription(session, user_id)
        
        return cls._query_active_subscription(session, user_id)

    @classmethod
    def _query_active_subscription(cls, session: "Session", user_id: int) -> Optional["Subscription"]:
        """Internal method to query active subscription."""
        return session.query(cls).filter(
            cls.user_id == user_id,
            cls.is_active.is_(True)
        ).first()

    def is_expired(self) -> bool:
        """Check if subscription is expired."""
        if not self.current_period_end:
            return False
        return self.current_period_end < datetime.utcnow()

    def deactivate(self, session: "Session") -> None:
        """Deactivate this subscription."""
        self.is_active = False
        self.updated_at = datetime.utcnow()
        session.add(self)

    def __repr__(self) -> str:
        return (
            f"<Subscription(id={self.id}, user_id={self.user_id}, "
            f"plan_id='{self.plan_id}', provider='{self.provider}', "
            f"is_active={self.is_active})>"
        )