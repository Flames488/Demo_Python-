from app.extensions import db

class StripeEvent(db.Model):
    __tablename__ = "stripe_events"

    id = db.Column(db.String, primary_key=True)
    processed_at = db.Column(db.DateTime, server_default=db.func.now())

    @staticmethod
    def already_processed(event_id: str) -> bool:
        return db.session.get(StripeEvent, event_id) is not None
