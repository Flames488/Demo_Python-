from sqlalchemy import Column, Integer, String, UniqueConstraint
from app.db import Base


class BillingEvent(Base):
    __tablename__ = "billing_events"

    id = Column(Integer, primary_key=True)
    provider = Column(String, nullable=False)
    event_id = Column(String, nullable=False)

    __table_args__ = (
        UniqueConstraint("provider", "event_id", name="uq_provider_event"),
    )

    @staticmethod
    def exists(provider, event_id):
        from app.db import session
        return session.query(BillingEvent).filter_by(
            provider=provider,
            event_id=event_id
        ).first() is not None

    @staticmethod
    def create(provider, event_id):
        from app.db import session
        session.add(
            BillingEvent(provider=provider, event_id=event_id)
        )
