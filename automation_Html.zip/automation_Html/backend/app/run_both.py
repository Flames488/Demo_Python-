# run_both.py
import threading
import uvicorn
from app.main import app as flask_app
from app.webhooks.fastapi_app import app as fastapi_app

def run_flask():
    flask_app.run(host="0.0.0.0", port=5000, debug=False)

def run_fastapi():
    uvicorn.run(fastapi_app, host="0.0.0.0", port=5001)

if __name__ == "__main__":
    # Start Flask in a thread
    flask_thread = threading.Thread(target=run_flask)
    flask_thread.daemon = True
    flask_thread.start()
    
    # Start FastAPI in main thread
    run_fastapi()