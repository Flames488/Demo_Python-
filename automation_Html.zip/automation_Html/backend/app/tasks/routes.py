from flask import Blueprint, jsonify, request
from flask_login import login_required, current_user
from app.models.task import Task
from app.extensions import db
from app.utils.errors import ValidationError
from app.utils.decorators import validate_json

bp = Blueprint("tasks", __name__, url_prefix="/tasks")

@bp.route("/", methods=["GET"])
@login_required
def get_tasks():
    """Get tasks for the current user"""
    # Filter tasks by user if you have user_id in Task model
    tasks = Task.query.all()  # Modify based on your needs
    
    return jsonify({
        "tasks": [
            {
                "id": task.id,
                "title": task.title,
                "summary": task.summary,
                "source": task.source
            }
            for task in tasks
        ],
        "count": len(tasks)
    })

@bp.route("/", methods=["POST"])
@login_required
@validate_json()
def create_task():
    """Create a new task"""
    data = request.get_json()
    
    if not data.get('title'):
        raise ValidationError("Title is required")
    
    task = Task(
        title=data['title'],
        summary=data.get('summary', ''),
        source=data.get('source', 'manual')
    )
    
    db.session.add(task)
    db.session.commit()
    
    return jsonify({
        "message": "Task created successfully",
        "task": {
            "id": task.id,
            "title": task.title,
            "summary": task.summary,
            "source": task.source
        }
    }), 201