from .routes import bp

__all__ = ['bp']from app.main import create_app
