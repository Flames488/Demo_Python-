import logging
from functools import wraps
from typing import Any, Dict, Optional

from flask import Flask, g, jsonify, request
import sentry_sdk  # Optional: for production error tracking

logger = logging.getLogger(__name__)


def setup_error_handlers(app: Flask) -> None:
    """
    Configure error handlers for the Flask application.
    
    Args:
        app: Flask application instance
    """
    app.errorhandler(Exception)(_handle_generic_exception)
    app.errorhandler(404)(_handle_not_found)
    app.errorhandler(401)(_handle_unauthorized)
    app.errorhandler(400)(_handle_bad_request)
    

def _log_error(
    error: Exception, 
    user_id: Optional[str] = None, 
    extra_context: Optional[Dict[str, Any]] = None
) -> None:
    """
    Log error with contextual information.
    
    Args:
        error: The exception that occurred
        user_id: Current user ID if available
        extra_context: Additional context for debugging
    """
    error_data = {
        "user_id": user_id,
        "error_type": error.__class__.__name__,
        "error_message": str(error),
        "endpoint": request.endpoint if request else None,
        "method": request.method if request else None,
        "path": request.path if request else None,
        "extra": extra_context or {},
    }
    
    # Send to Sentry in production
    if sentry_sdk.Hub.current.client:
        sentry_sdk.capture_exception(error, extra=error_data)
    
    # Structured logging
    logger.error(
        f"{error.__class__.__name__}: {str(error)}",
        extra=error_data,
        exc_info=True,
    )


def _handle_generic_exception(error: Exception) -> tuple:
    """
    Handle unhandled exceptions with logging and user-friendly response.
    
    Args:
        error: The unhandled exception
    
    Returns:
        Tuple of (JSON response, HTTP status code)
    """
    user_id = getattr(g, "user_id", None)  # Prefer explicit attribute naming
    
    # Log the actual error with full context
    _log_error(error, user_id=user_id)
    
    # For production, mask internal error details
    if app.config.get("ENV") == "production" or app.config.get("DEBUG") is False:
        error_message = "Internal server error"
        error_details = {"error": error_message}
    else:
        # In development, provide more details
        error_message = f"{error.__class__.__name__}: {str(error)}"
        error_details = {
            "error": error_message,
            "type": error.__class__.__name__,
            "traceback": getattr(error, "__traceback__", None),
        }
    
    return jsonify(error_details), 500


def _handle_not_found(error: Exception) -> tuple:
    """Handle 404 Not Found errors."""
    return jsonify({"error": "Resource not found"}), 404


def _handle_unauthorized(error: Exception) -> tuple:
    """Handle 401 Unauthorized errors."""
    return jsonify({"error": "Authentication required"}), 401


def _handle_bad_request(error: Exception) -> tuple:
    """Handle 400 Bad Request errors."""
    error_message = str(error) or "Invalid request"
    return jsonify({"error": error_message}), 400


# Decorator for consistent error handling in routes
def with_error_handling(f):
    """
    Decorator to wrap route handlers with consistent error handling.
    
    Usage:
        @app.route("/endpoint")
        @with_error_handling
        def endpoint():
            # your code here
    """
    @wraps(f)
    def decorated_function(*args, **kwargs):
        try:
            return f(*args, **kwargs)
        except (ValidationError, BadRequest) as e:
            # Handle expected errors differently
            logger.warning(f"Validation error: {str(e)}")
            return jsonify({"error": str(e)}), 400
        except Unauthorized as e:
            logger.warning(f"Unauthorized: {str(e)}")
            return jsonify({"error": "Authentication required"}), 401
        except Exception as e:
            # Fall back to the generic handler
            return _handle_generic_exception(e)
    
    return decorated_function


# Optional: Custom exception classes for better error handling
class ValidationError(Exception):
    """Raised when input validation fails."""
    pass


class ServiceError(Exception):
    """Raised when an external service fails."""
    pass


# Initialize with your Flask app
app = Flask(__name__)

# Setup error handlers
setup_error_handlers(app)


# Example usage in a route
@app.route("/api/data/<int:item_id>")
@with_error_handling
def get_data(item_id: int):
    """
    Example endpoint with built-in error handling.
    
    Args:
        item_id: ID of the item to retrieve
    
    Returns:
        JSON response with item data
    """
    if item_id < 0:
        raise ValidationError("Item ID must be positive")
    
    # Your business logic here
    data = fetch_data_from_database(item_id)
    
    if not data:
        raise ValidationError(f"Item {item_id} not found")
    
    return jsonify(data)