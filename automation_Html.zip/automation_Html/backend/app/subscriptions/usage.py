# subscription/usage.py
from app import db

def increment_usage(user, feature: str, amount: int = 1):
    """Increment usage counter and save to database"""
    if not hasattr(user, 'usage'):
        user.usage = {}
    
    current = user.usage.get(feature, 0)
    user.usage[feature] = current + amount
    
    # Mark as modified for SQLAlchemy JSON field
    if hasattr(user, '_sa_instance_state'):
        from sqlalchemy.orm.attributes import flag_modified
        flag_modified(user, 'usage')
    
    db.session.commit()