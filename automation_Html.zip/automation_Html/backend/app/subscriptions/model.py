# subscription/service.py
from datetime import datetime, timedelta
from app import db
from app.subscriptions.models import Subscription, SubscriptionData
from models.user import User

def activate_subscription(user_id: int, plan: str = "pro", days: int = 30):
    """Activate or renew a subscription for a user with specific plan"""
    # Default limits based on plan (you should define these per your PLANS.md)
    plan_limits = {
        "free": {"projects": 3, "storage_mb": 100, "collaborators": 1},
        "pro": {"projects": 50, "storage_mb": 5000, "collaborators": 10, "api_calls": 10000},
        "business": {"projects": 500, "storage_mb": 50000, "collaborators": 100, "api_calls": 100000}
    }
    
    expires_at = datetime.utcnow() + timedelta(days=days)
    
    sub = Subscription.query.filter_by(user_id=user_id).first()

    if not sub:
        # Create new subscription with dataclass pattern
        subscription_data = SubscriptionData(
            plan=plan,
            expires_at=expires_at,
            limits=plan_limits.get(plan, {}),
            status="active"
        )
        sub = subscription_data.to_model(user_id)
        db.session.add(sub)
    else:
        # Update existing subscription
        sub.plan = plan
        sub.expires_at = expires_at
        sub.limits = plan_limits.get(plan, {})
        sub.status = "active"
        sub.active = True
    
    # Also update the user's subscription fields if they exist (for backward compatibility)
    user = User.query.get(user_id)
    if user:
        if hasattr(user, 'subscription_status'):
            user.subscription_status = 'active'
        if hasattr(user, 'subscription_expires_at'):
            user.subscription_expires_at = expires_at
        if hasattr(user, 'subscription_plan'):
            user.subscription_plan = plan
    
    db.session.commit()
    return sub

def user_has_active_plan(user_id):
    """Bridge between subscription design and enforcement.
    Checks subscription status and plan limits."""
    
    # Get user's subscription
    subscription = Subscription.query.filter_by(user_id=user_id).first()
    if not subscription:
        # No subscription record found
        return False
    
    # Check if subscription is active using the model's method
    if not subscription.is_active():
        return False
    
    # Additional checks can be added here based on your requirements
    # For example, check if user is suspended, etc.
    
    return True

def check_feature_access(user_id: int, feature: str, usage_count: int = 0) -> bool:
    """Check if user has access to a specific feature and hasn't exceeded limits"""
    subscription = Subscription.query.filter_by(user_id=user_id).first()
    if not subscription:
        return False
    
    # Check if subscription is active
    if not subscription.is_active():
        return False
    
    # Check if feature is in the plan's limits
    if not subscription.has_access_to(feature):
        return False
    
    # Get the limit for this feature
    limit = subscription.get_limit(feature)
    if limit is None:
        # No limit defined - unlimited access
        return True
    
    # Check if usage is within limits
    # You'll need to implement usage tracking separately
    return usage_count < limit

def get_user_subscription_data(user_id: int) -> SubscriptionData:
    """Get user's subscription as a dataclass for easy use"""
    subscription = Subscription.query.filter_by(user_id=user_id).first()
    
    if subscription:
        return SubscriptionData(
            plan=subscription.plan,
            expires_at=subscription.expires_at,
            limits=subscription.limits or {},
            status=subscription.status
        )
    
    # Return free plan by default
    return SubscriptionData(
        plan="free",
        expires_at=None,
        limits={"projects": 3, "storage_mb": 100, "collaborators": 1},
        status="active"
    )

def upgrade_plan(user_id: int, new_plan: str) -> Subscription:
    """Upgrade user to a new plan"""
    subscription = Subscription.query.filter_by(user_id=user_id).first()
    if not subscription:
        # Create new subscription if none exists
        return activate_subscription(user_id, new_plan)
    
    plan_limits = {
        "free": {"projects": 3, "storage_mb": 100, "collaborators": 1},
        "pro": {"projects": 50, "storage_mb": 5000, "collaborators": 10, "api_calls": 10000},
        "business": {"projects": 500, "storage_mb": 50000, "collaborators": 100, "api_calls": 100000}
    }
    
    # Update subscription
    subscription.plan = new_plan
    subscription.limits = plan_limits.get(new_plan, {})
    
    # Extend expiration if already has time remaining
    if subscription.expires_at and subscription.expires_at > datetime.utcnow():
        # Keep existing expiration for upgrades
        pass
    else:
        # Set new expiration
        subscription.expires_at = datetime.utcnow() + timedelta(days=30)
    
    db.session.commit()
    return subscription

def cancel_subscription(user_id: int) -> Subscription:
    """Cancel user's subscription (keeps it active until expires)"""
    subscription = Subscription.query.filter_by(user_id=user_id).first()
    if not subscription:
        raise ValueError(f"No subscription found for user {user_id}")
    
    subscription.status = "canceled"
    # Note: active flag remains True until expiration
    db.session.commit()
    return subscription

# Helper function for backward compatibility
def get_user_plan(user_id):
    """Bridge function for backward compatibility with old code"""
    return get_user_subscription_data(user_id)