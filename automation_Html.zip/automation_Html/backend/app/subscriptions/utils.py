# subscription/utils.py
from datetime import datetime
from .models import Subscription

def load_user_subscription(user) -> Subscription:
    """
    Load subscription from user object.
    Assumes user model has subscription-related fields.
    """
    if not user or not hasattr(user, 'subscription_plan'):
        return None
    
    # Map database fields to subscription object
    return Subscription(
        plan=user.subscription_plan,
        expires_at=user.subscription_expires_at,
        limits=user.plan_limits or {},
        status=user.subscription_status or "inactive"
    )