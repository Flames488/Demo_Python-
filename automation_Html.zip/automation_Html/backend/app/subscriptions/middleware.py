# subscription/middleware.py - Enhanced version
from functools import wraps
from flask import jsonify, current_app
from flask_jwt_extended import get_jwt_identity
from .models import Subscription
from .utils import load_user_subscription
from app.models import User

def subscription_required(feature=None):
    def decorator(fn):
        @wraps(fn)
        def wrapper(*args, **kwargs):
            user_id = get_jwt_identity()
            
            # Get user from database
            user = User.query.get(user_id)
            if not user:
                return jsonify({"error": "User not found"}), 404

            # Load subscription
            sub = load_user_subscription(user)
            if not sub:
                return jsonify({"error": "No subscription found"}), 403
            
            # Check active status
            if not sub.is_active():
                return jsonify({"error": "Subscription expired or inactive"}), 403

            # Check specific feature
            if feature:
                limit = sub.get_limit(feature)
                if limit is not None:
                    current_usage = user.usage.get(feature, 0)
                    if current_usage >= limit:
                        return jsonify({
                            "error": f"Plan limit reached for {feature}",
                            "current": current_usage,
                            "limit": limit
                        }), 403

            return fn(*args, **kwargs)
        return wrapper
    return decorator