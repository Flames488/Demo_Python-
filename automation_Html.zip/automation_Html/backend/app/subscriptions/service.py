# subscription/service.py
from datetime import datetime, timedelta
from app import db
from app.subscriptions.models import Subscription
from models.user import User
from app.subscriptions.utils import get_user_plan  # Assuming this exists based on your code

def activate_subscription(user_id: int):
    """Activate or renew a subscription for a user"""
    sub = Subscription.query.filter_by(user_id=user_id).first()

    if not sub:
        sub = Subscription(
            user_id=user_id,
            plan="pro",
            active=True,
            expires_at=datetime.utcnow() + timedelta(days=30)
        )
        db.session.add(sub)
    else:
        sub.active = True
        sub.expires_at = datetime.utcnow() + timedelta(days=30)

    # Also update the user's subscription fields for backward compatibility
    user = User.query.get(user_id)
    if user:
        user.subscription_status = 'active'
        user.subscription_expires_at = datetime.utcnow() + timedelta(days=30)
    
    db.session.commit()
    return sub

def user_has_active_plan(user_id):
    """Bridge between subscription design and enforcement.
    Checks both Subscription model and User fields for compatibility."""
    
    # First check the dedicated Subscription model
    subscription = Subscription.query.filter_by(user_id=user_id).first()
    if subscription and subscription.active:
        if subscription.expires_at and subscription.expires_at < datetime.utcnow():
            # Subscription expired
            subscription.active = False
            db.session.commit()
            return False
        return True
    
    # Fallback: Check user fields (for backward compatibility)
    user = User.query.get(user_id)
    if not user:
        return False
    
    # Check subscription status based on your design rules
    if hasattr(user, 'subscription_status'):
        if user.subscription_status not in ['active', 'trialing']:
            return False
        
        # Check expiration
        if (hasattr(user, 'subscription_expires_at') and 
            user.subscription_expires_at and 
            user.subscription_expires_at < datetime.utcnow()):
            # Update status if expired
            user.subscription_status = 'expired'
            db.session.commit()
            return False
    
    # Check plan limits (implement based on PLANS.md)
    try:
        current_plan = get_user_plan(user_id)
        if current_plan and not getattr(current_plan, 'is_active', True):
            return False
    except (ImportError, AttributeError):
        # get_user_plan might not be implemented yet
        pass
    
    return True

def get_subscription_status(user_id):
    """Get comprehensive subscription status"""
    status = {
        'has_active_subscription': False,
        'plan': None,
        'expires_at': None,
        'days_remaining': 0
    }
    
    # Check Subscription model first
    subscription = Subscription.query.filter_by(user_id=user_id).first()
    if subscription:
        status['plan'] = subscription.plan
        status['expires_at'] = subscription.expires_at
        if subscription.active and subscription.expires_at:
            if subscription.expires_at > datetime.utcnow():
                status['has_active_subscription'] = True
                status['days_remaining'] = (subscription.expires_at - datetime.utcnow()).days
            else:
                subscription.active = False
                db.session.commit()
    
    # Fallback to user fields
    if not status['has_active_subscription']:
        user = User.query.get(user_id)
        if user and hasattr(user, 'subscription_status'):
            if user.subscription_status in ['active', 'trialing']:
                if (hasattr(user, 'subscription_expires_at') and 
                    user.subscription_expires_at and 
                    user.subscription_expires_at > datetime.utcnow()):
                    status['has_active_subscription'] = True
                    status['expires_at'] = user.subscription_expires_at
                    status['days_remaining'] = (user.subscription_expires_at - datetime.utcnow()).days
                else:
                    user.subscription_status = 'expired'
                    db.session.commit()
    
    return status