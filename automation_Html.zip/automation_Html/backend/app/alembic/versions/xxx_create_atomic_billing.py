# alembic/versions/xxx_create_atomic_billing_advanced.py
"""
Advanced atomic billing system migration with safety features, validation,
and progress tracking.

FEATURES:
1. Complete schema creation with all constraints
2. Data validation and integrity checks
3. Rollback safety with intermediate backups
4. Progress tracking and logging
5. Emergency recovery procedures
6. Performance optimizations

SAFETY PROTOCOLS:
- Never auto-creates tables in production
- Validates data before and after migration
- Maintains rollback capability at each stage
- Tracks migration progress for crash recovery
"""

from alembic import op
import sqlalchemy as sa
from sqlalchemy.dialects import postgresql
from sqlalchemy.sql import text
import logging
import uuid
from datetime import datetime, timezone

# Configure migration logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


def create_migration_tracking():
    """Create a table to track migration progress for crash recovery."""
    conn = op.get_bind()
    
    # Check if migration tracking table exists
    result = conn.execute(text("""
        SELECT EXISTS (
            SELECT FROM information_schema.tables 
            WHERE table_name = 'alembic_migration_progress'
        );
    """))
    
    if not result.scalar():
        conn.execute(text("""
            CREATE TABLE alembic_migration_progress (
                id SERIAL PRIMARY KEY,
                migration_version VARCHAR(255) NOT NULL,
                step_name VARCHAR(255) NOT NULL,
                step_number INTEGER NOT NULL,
                status VARCHAR(50) NOT NULL,
                started_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
                completed_at TIMESTAMP WITH TIME ZONE,
                error_message TEXT,
                metadata JSONB
            );
            
            CREATE INDEX idx_migration_progress_version 
            ON alembic_migration_progress(migration_version, step_number);
            
            CREATE INDEX idx_migration_progress_status 
            ON alembic_migration_progress(status, started_at);
        """))
        logger.info("Created migration progress tracking table")


def log_migration_step(step_name, step_number, status, metadata=None):
    """Log migration step progress."""
    conn = op.get_bind()
    migration_version = 'xxx_create_atomic_billing'
    
    if status == 'started':
        conn.execute(text("""
            INSERT INTO alembic_migration_progress 
            (migration_version, step_name, step_number, status, metadata)
            VALUES (:version, :step, :number, :status, :metadata)
        """), {
            'version': migration_version,
            'step': step_name,
            'number': step_number,
            'status': status,
            'metadata': metadata
        })
    else:
        conn.execute(text("""
            UPDATE alembic_migration_progress 
            SET status = :status, 
                completed_at = NOW(),
                error_message = :error,
                metadata = COALESCE(:metadata, metadata)
            WHERE migration_version = :version 
            AND step_number = :number
            AND status = 'started'
        """), {
            'version': migration_version,
            'number': step_number,
            'status': status,
            'error': metadata.get('error') if metadata else None,
            'metadata': metadata
        })
    
    logger.info(f"Migration step {step_number}: {step_name} - {status}")


def validate_existing_data():
    """Validate that no conflicting data exists before migration."""
    conn = op.get_bind()
    step = 0
    
    log_migration_step('validate_existing_data', step, 'started')
    
    try:
        # Check if any tables already exist
        tables_to_check = ['users', 'billing_events', 'billing_ledger', 'usage_records', 'billing_locks']
        
        for table_name in tables_to_check:
            result = conn.execute(text("""
                SELECT EXISTS (
                    SELECT FROM information_schema.tables 
                    WHERE table_name = :table_name
                );
            """), {'table_name': table_name})
            
            if result.scalar():
                error_msg = f"Table '{table_name}' already exists. Cannot proceed with migration."
                log_migration_step('validate_existing_data', step, 'failed', 
                                  {'error': error_msg})
                raise ValueError(error_msg)
        
        log_migration_step('validate_existing_data', step, 'completed')
        return True
        
    except Exception as e:
        logger.error(f"Data validation failed: {e}")
        log_migration_step('validate_existing_data', step, 'failed', {'error': str(e)})
        raise


def create_users_table():
    """Create users table with constraints and indexes."""
    step = 1
    log_migration_step('create_users_table', step, 'started')
    
    try:
        op.create_table('users',
            sa.Column('id', sa.Integer(), nullable=False),
            sa.Column('email', sa.String(length=255), nullable=False),
            sa.Column('balance', sa.Numeric(precision=20, scale=4), nullable=False, server_default='0.0000'),
            sa.Column('subscription_active', sa.Boolean(), nullable=True),
            sa.Column('subscription_ends_at', sa.DateTime(timezone=True), nullable=True),
            sa.Column('version', sa.Integer(), nullable=False, server_default='0'),
            sa.Column('created_at', sa.DateTime(timezone=True), nullable=False, server_default=sa.func.now()),
            sa.Column('updated_at', sa.DateTime(timezone=True), nullable=False, server_default=sa.func.now()),
            
            # Constraints
            sa.PrimaryKeyConstraint('id', name='pk_users'),
            sa.CheckConstraint('balance >= 0', name='ck_users_non_negative_balance'),
            sa.CheckConstraint('version >= 0', name='ck_users_non_negative_version'),
            
            # Unique constraints
            sa.UniqueConstraint('email', name='uq_users_email')
        )
        
        # Indexes
        op.create_index('idx_users_email', 'users', ['email'], unique=True)
        op.create_index('idx_users_subscription', 'users', 
                       ['subscription_active', 'subscription_ends_at'], 
                       postgresql_where=sa.text('subscription_active = true'))
        op.create_index('idx_users_created_at', 'users', ['created_at'])
        
        # Add updated_at trigger function
        conn = op.get_bind()
        conn.execute(text("""
            CREATE OR REPLACE FUNCTION update_updated_at_column()
            RETURNS TRIGGER AS $$
            BEGIN
                NEW.updated_at = NOW();
                RETURN NEW;
            END;
            $$ language 'plpgsql';
        """))
        
        conn.execute(text("""
            CREATE TRIGGER update_users_updated_at 
            BEFORE UPDATE ON users 
            FOR EACH ROW 
            EXECUTE FUNCTION update_updated_at_column();
        """))
        
        log_migration_step('create_users_table', step, 'completed')
        
    except Exception as e:
        logger.error(f"Failed to create users table: {e}")
        log_migration_step('create_users_table', step, 'failed', {'error': str(e)})
        raise


def create_billing_events_table():
    """Create billing events table with audit trail capabilities."""
    step = 2
    log_migration_step('create_billing_events_table', step, 'started')
    
    try:
        op.create_table('billing_events',
            sa.Column('id', postgresql.UUID(as_uuid=True), nullable=False, 
                     server_default=sa.text('gen_random_uuid()')),
            sa.Column('idempotency_key', sa.String(length=128), nullable=False),
            sa.Column('correlation_id', sa.String(length=128), nullable=True),
            sa.Column('user_id', sa.Integer(), nullable=False),
            sa.Column('amount', sa.Numeric(precision=20, scale=4), nullable=False),
            sa.Column('currency', sa.String(length=10), nullable=False, server_default='USD'),
            sa.Column('status', sa.String(length=32), nullable=False, 
                     server_default='pending'),
            sa.Column('event_type', sa.String(length=64), nullable=False),
            sa.Column('description', sa.String(length=512), nullable=True),
            sa.Column('metadata', postgresql.JSONB(astext_type=sa.Text()), nullable=True),
            sa.Column('error_details', postgresql.JSONB(astext_type=sa.Text()), nullable=True),
            sa.Column('created_at', sa.DateTime(timezone=True), nullable=False, 
                     server_default=sa.func.now()),
            sa.Column('updated_at', sa.DateTime(timezone=True), nullable=False, 
                     server_default=sa.func.now()),
            sa.Column('completed_at', sa.DateTime(timezone=True), nullable=True),
            
            # Constraints
            sa.PrimaryKeyConstraint('id', name='pk_billing_events'),
            sa.ForeignKeyConstraint(['user_id'], ['users.id'], 
                                  name='fk_billing_events_user_id',
                                  ondelete='RESTRICT'),
            sa.UniqueConstraint('idempotency_key', name='uq_billing_events_idempotency_key'),
            
            # Check constraints
            sa.CheckConstraint(
                "status IN ('pending', 'processing', 'completed', 'failed', 'cancelled')",
                name='ck_billing_events_valid_status'
            ),
            sa.CheckConstraint(
                "event_type IN ('charge', 'refund', 'credit', 'adjustment', 'subscription')",
                name='ck_billing_events_valid_event_type'
            ),
            sa.CheckConstraint(
                "completed_at IS NULL OR completed_at >= created_at",
                name='ck_billing_events_valid_timeline'
            )
        )
        
        # Indexes
        op.create_index('idx_billing_events_user_id', 'billing_events', ['user_id'])
        op.create_index('idx_billing_events_status', 'billing_events', ['status', 'created_at'])
        op.create_index('idx_billing_events_created_at', 'billing_events', ['created_at'])
        op.create_index('idx_billing_events_idempotency', 'billing_events', 
                       ['idempotency_key'], unique=True)
        op.create_index('idx_billing_events_correlation', 'billing_events', ['correlation_id'])
        op.create_index('idx_billing_events_user_status', 'billing_events', 
                       ['user_id', 'status', 'created_at'])
        
        # Add updated_at trigger
        conn = op.get_bind()
        conn.execute(text("""
            CREATE TRIGGER update_billing_events_updated_at 
            BEFORE UPDATE ON billing_events 
            FOR EACH ROW 
            EXECUTE FUNCTION update_updated_at_column();
        """))
        
        # Create function to validate idempotency
        conn.execute(text("""
            CREATE OR REPLACE FUNCTION validate_billing_event_idempotency()
            RETURNS TRIGGER AS $$
            BEGIN
                -- Check if idempotency key already exists with different parameters
                IF EXISTS (
                    SELECT 1 FROM billing_events 
                    WHERE idempotency_key = NEW.idempotency_key 
                    AND (user_id != NEW.user_id OR amount != NEW.amount OR event_type != NEW.event_type)
                ) THEN
                    RAISE EXCEPTION 'Idempotency key conflict: same key with different parameters';
                END IF;
                
                -- If same key with same parameters exists, prevent duplicate insertion
                IF EXISTS (
                    SELECT 1 FROM billing_events 
                    WHERE idempotency_key = NEW.idempotency_key 
                    AND user_id = NEW.user_id 
                    AND amount = NEW.amount 
                    AND event_type = NEW.event_type
                    AND status != 'failed'
                ) THEN
                    RAISE EXCEPTION 'Duplicate idempotency key for non-failed event';
                END IF;
                
                RETURN NEW;
            END;
            $$ language 'plpgsql';
        """))
        
        conn.execute(text("""
            CREATE TRIGGER validate_billing_event_idempotency_trigger
            BEFORE INSERT ON billing_events
            FOR EACH ROW
            EXECUTE FUNCTION validate_billing_event_idempotency();
        """))
        
        log_migration_step('create_billing_events_table', step, 'completed')
        
    except Exception as e:
        logger.error(f"Failed to create billing events table: {e}")
        log_migration_step('create_billing_events_table', step, 'failed', {'error': str(e)})
        raise


def create_billing_ledger_table():
    """Create double-entry accounting ledger table."""
    step = 3
    log_migration_step('create_billing_ledger_table', step, 'started')
    
    try:
        op.create_table('billing_ledger',
            sa.Column('id', postgresql.UUID(as_uuid=True), nullable=False,
                     server_default=sa.text('gen_random_uuid()')),
            sa.Column('event_id', postgresql.UUID(as_uuid=True), nullable=False),
            sa.Column('user_id', sa.Integer(), nullable=False),
            sa.Column('entry_type', sa.String(length=32), nullable=False),
            sa.Column('account', sa.String(length=64), nullable=False),
            sa.Column('amount', sa.Numeric(precision=20, scale=4), nullable=False),
            sa.Column('balance_before', sa.Numeric(precision=20, scale=4), nullable=False),
            sa.Column('balance_after', sa.Numeric(precision=20, scale=4), nullable=False),
            sa.Column('reference', sa.String(length=128), nullable=True),
            sa.Column('description', sa.String(length=512), nullable=True),
            sa.Column('created_at', sa.DateTime(timezone=True), nullable=False,
                     server_default=sa.func.now()),
            
            # Constraints
            sa.PrimaryKeyConstraint('id', name='pk_billing_ledger'),
            sa.ForeignKeyConstraint(['event_id'], ['billing_events.id'],
                                  name='fk_billing_ledger_event_id',
                                  ondelete='CASCADE'),
            sa.ForeignKeyConstraint(['user_id'], ['users.id'],
                                  name='fk_billing_ledger_user_id',
                                  ondelete='CASCADE'),
            
            # Check constraints
            sa.CheckConstraint('amount != 0', name='ck_billing_ledger_non_zero_amount'),
            sa.CheckConstraint(
                "entry_type IN ('debit', 'credit')",
                name='ck_billing_ledger_valid_entry_type'
            ),
            sa.CheckConstraint(
                "account IN ('user_balance', 'revenue', 'accounts_receivable', 'refunds_payable')",
                name='ck_billing_ledger_valid_account'
            ),
            sa.CheckConstraint(
                "(entry_type = 'debit' AND amount > 0) OR (entry_type = 'credit' AND amount < 0)",
                name='ck_billing_ledger_amount_sign'
            ),
            sa.CheckConstraint(
                "balance_after = balance_before + amount",
                name='ck_billing_ledger_balance_consistency'
            )
        )
        
        # Indexes
        op.create_index('idx_billing_ledger_user_id', 'billing_ledger', ['user_id'])
        op.create_index('idx_billing_ledger_event_id', 'billing_ledger', ['event_id'])
        op.create_index('idx_billing_ledger_account', 'billing_ledger', ['account', 'created_at'])
        op.create_index('idx_billing_ledger_created_at', 'billing_ledger', ['created_at'])
        op.create_index('idx_billing_ledger_user_account', 'billing_ledger', 
                       ['user_id', 'account', 'created_at'])
        op.create_index('idx_billing_ledger_reference', 'billing_ledger', ['reference'])
        
        # Create materialized view for account balances
        conn = op.get_bind()
        conn.execute(text("""
            CREATE MATERIALIZED VIEW account_balances AS
            SELECT 
                user_id,
                account,
                SUM(amount) as current_balance,
                COUNT(*) as transaction_count,
                MAX(created_at) as last_transaction_at
            FROM billing_ledger
            GROUP BY user_id, account;
            
            CREATE UNIQUE INDEX idx_account_balances_user_account 
            ON account_balances(user_id, account);
            
            CREATE INDEX idx_account_balances_balance 
            ON account_balances(current_balance);
        """))
        
        # Create function to refresh materialized view
        conn.execute(text("""
            CREATE OR REPLACE FUNCTION refresh_account_balances()
            RETURNS TRIGGER AS $$
            BEGIN
                REFRESH MATERIALIZED VIEW CONCURRENTLY account_balances;
                RETURN NULL;
            END;
            $$ language 'plpgsql';
            
            CREATE TRIGGER refresh_account_balances_trigger
            AFTER INSERT OR UPDATE OR DELETE ON billing_ledger
            FOR EACH STATEMENT
            EXECUTE FUNCTION refresh_account_balances();
        """))
        
        log_migration_step('create_billing_ledger_table', step, 'completed')
        
    except Exception as e:
        logger.error(f"Failed to create billing ledger table: {e}")
        log_migration_step('create_billing_ledger_table', step, 'failed', {'error': str(e)})
        raise


def create_usage_records_table():
    """Create usage records table for feature usage tracking."""
    step = 4
    log_migration_step('create_usage_records_table', step, 'started')
    
    try:
        op.create_table('usage_records',
            sa.Column('id', postgresql.UUID(as_uuid=True), nullable=False,
                     server_default=sa.text('gen_random_uuid()')),
            sa.Column('user_id', sa.Integer(), nullable=False),
            sa.Column('feature', sa.String(length=64), nullable=False),
            sa.Column('period', sa.String(length=32), nullable=False),
            sa.Column('used', sa.Integer(), nullable=False, server_default='0'),
            sa.Column('limit', sa.Integer(), nullable=False),
            sa.Column('reset_at', sa.DateTime(timezone=True), nullable=False),
            sa.Column('version', sa.Integer(), nullable=False, server_default='0'),
            sa.Column('created_at', sa.DateTime(timezone=True), nullable=False,
                     server_default=sa.func.now()),
            sa.Column('updated_at', sa.DateTime(timezone=True), nullable=False,
                     server_default=sa.func.now()),
            
            # Constraints
            sa.PrimaryKeyConstraint('id', name='pk_usage_records'),
            sa.ForeignKeyConstraint(['user_id'], ['users.id'],
                                  name='fk_usage_records_user_id',
                                  ondelete='CASCADE'),
            sa.UniqueConstraint('user_id', 'feature', 'reset_at',
                               name='uq_usage_records_user_feature_window'),
            
            # Check constraints
            sa.CheckConstraint('used >= 0', name='ck_usage_records_non_negative_usage'),
            sa.CheckConstraint('limit > 0', name='ck_usage_records_positive_limit'),
            sa.CheckConstraint(
                "period IN ('daily', 'weekly', 'monthly', 'yearly', 'custom')",
                name='ck_usage_records_valid_period'
            ),
            sa.CheckConstraint(
                "used <= limit",
                name='ck_usage_records_usage_within_limit'
            ),
            sa.CheckConstraint('version >= 0', name='ck_usage_records_non_negative_version')
        )
        
        # Indexes
        op.create_index('idx_usage_records_user_feature', 'usage_records',
                       ['user_id', 'feature', 'reset_at'], unique=True)
        op.create_index('idx_usage_records_reset_at', 'usage_records', ['reset_at'])
        op.create_index('idx_usage_records_period', 'usage_records', ['period', 'reset_at'])
        op.create_index('idx_usage_records_user_period', 'usage_records',
                       ['user_id', 'period', 'reset_at'])
        
        # Add updated_at trigger
        conn = op.get_bind()
        conn.execute(text("""
            CREATE TRIGGER update_usage_records_updated_at 
            BEFORE UPDATE ON usage_records 
            FOR EACH ROW 
            EXECUTE FUNCTION update_updated_at_column();
        """))
        
        # Create function to enforce version increment
        conn.execute(text("""
            CREATE OR REPLACE FUNCTION increment_usage_version()
            RETURNS TRIGGER AS $$
            BEGIN
                NEW.version = OLD.version + 1;
                RETURN NEW;
            END;
            $$ language 'plpgsql';
            
            CREATE TRIGGER increment_usage_version_trigger
            BEFORE UPDATE ON usage_records
            FOR EACH ROW
            WHEN (OLD.* IS DISTINCT FROM NEW.*)
            EXECUTE FUNCTION increment_usage_version();
        """))
        
        log_migration_step('create_usage_records_table', step, 'completed')
        
    except Exception as e:
        logger.error(f"Failed to create usage records table: {e}")
        log_migration_step('create_usage_records_table', step, 'failed', {'error': str(e)})
        raise


def create_billing_locks_table():
    """Create distributed locking table for atomic operations."""
    step = 5
    log_migration_step('create_billing_locks_table', step, 'started')
    
    try:
        op.create_table('billing_locks',
            sa.Column('id', sa.Integer(), sa.Identity(start=1, increment=1), nullable=False),
            sa.Column('user_id', sa.Integer(), nullable=False),
            sa.Column('lock_id', postgresql.UUID(as_uuid=True), nullable=False,
                     server_default=sa.text('gen_random_uuid()')),
            sa.Column('resource_type', sa.String(length=64), nullable=False,
                     server_default='billing'),
            sa.Column('expires_at', sa.DateTime(timezone=True), nullable=False),
            sa.Column('created_at', sa.DateTime(timezone=True), nullable=False,
                     server_default=sa.func.now()),
            sa.Column('updated_at', sa.DateTime(timezone=True), nullable=False,
                     server_default=sa.func.now()),
            
            # Constraints
            sa.PrimaryKeyConstraint('id', name='pk_billing_locks'),
            sa.ForeignKeyConstraint(['user_id'], ['users.id'],
                                  name='fk_billing_locks_user_id',
                                  ondelete='CASCADE'),
            sa.UniqueConstraint('user_id', 'resource_type',
                               name='uq_billing_locks_user_resource'),
            
            # Check constraints
            sa.CheckConstraint(
                "expires_at > created_at",
                name='ck_billing_locks_valid_expiry'
            )
        )
        
        # Indexes
        op.create_index('idx_billing_locks_user_id', 'billing_locks', ['user_id'])
        op.create_index('idx_billing_locks_expires_at', 'billing_locks', ['expires_at'])
        op.create_index('idx_billing_locks_lock_id', 'billing_locks', ['lock_id'], unique=True)
        op.create_index('idx_billing_locks_user_resource', 'billing_locks',
                       ['user_id', 'resource_type'], unique=True)
        
        # Add updated_at trigger
        conn = op.get_bind()
        conn.execute(text("""
            CREATE TRIGGER update_billing_locks_updated_at 
            BEFORE UPDATE ON billing_locks 
            FOR EACH ROW 
            EXECUTE FUNCTION update_updated_at_column();
        """))
        
        # Create function to automatically clean expired locks
        conn.execute(text("""
            CREATE OR REPLACE FUNCTION cleanup_expired_locks()
            RETURNS TRIGGER AS $$
            BEGIN
                DELETE FROM billing_locks WHERE expires_at < NOW();
                RETURN NULL;
            END;
            $$ language 'plpgsql';
            
            CREATE TRIGGER cleanup_expired_locks_trigger
            AFTER INSERT OR UPDATE ON billing_locks
            FOR EACH STATEMENT
            EXECUTE FUNCTION cleanup_expired_locks();
        """))
        
        log_migration_step('create_billing_locks_table', step, 'completed')
        
    except Exception as e:
        logger.error(f"Failed to create billing locks table: {e}")
        log_migration_step('create_billing_locks_table', step, 'failed', {'error': str(e)})
        raise


def create_audit_log_table():
    """Create audit log table for tracking all changes."""
    step = 6
    log_migration_step('create_audit_log_table', step, 'started')
    
    try:
        op.create_table('audit_logs',
            sa.Column('id', postgresql.UUID(as_uuid=True), nullable=False,
                     server_default=sa.text('gen_random_uuid()')),
            sa.Column('table_name', sa.String(length=128), nullable=False),
            sa.Column('record_id', sa.String(length=255), nullable=False),
            sa.Column('operation', sa.String(length=32), nullable=False),
            sa.Column('old_values', postgresql.JSONB(astext_type=sa.Text()), nullable=True),
            sa.Column('new_values', postgresql.JSONB(astext_type=sa.Text()), nullable=True),
            sa.Column('changed_by', sa.String(length=255), nullable=True),
            sa.Column('ip_address', postgresql.INET(), nullable=True),
            sa.Column('user_agent', sa.String(length=512), nullable=True),
            sa.Column('created_at', sa.DateTime(timezone=True), nullable=False,
                     server_default=sa.func.now()),
            
            # Constraints
            sa.PrimaryKeyConstraint('id', name='pk_audit_logs'),
            
            # Check constraints
            sa.CheckConstraint(
                "operation IN ('INSERT', 'UPDATE', 'DELETE', 'TRUNCATE')",
                name='ck_audit_logs_valid_operation'
            )
        )
        
        # Indexes
        op.create_index('idx_audit_logs_table_record', 'audit_logs',
                       ['table_name', 'record_id', 'created_at'])
        op.create_index('idx_audit_logs_operation', 'audit_logs', ['operation', 'created_at'])
        op.create_index('idx_audit_logs_created_at', 'audit_logs', ['created_at'])
        op.create_index('idx_audit_logs_changed_by', 'audit_logs', ['changed_by', 'created_at'])
        
        # Create audit trigger function
        conn = op.get_bind()
        conn.execute(text("""
            CREATE OR REPLACE FUNCTION audit_trigger_function()
            RETURNS TRIGGER AS $$
            DECLARE
                audit_row audit_logs;
                excluded_columns TEXT[] := ARRAY['updated_at', 'version', 'created_at'];
                column_name TEXT;
                old_value JSONB;
                new_value JSONB;
                changed_fields JSONB := '{}'::JSONB;
                old_data JSONB;
                new_data JSONB;
            BEGIN
                audit_row = ROW(
                    gen_random_uuid(),
                    TG_TABLE_NAME,
                    NULL,
                    TG_OP,
                    NULL,
                    NULL,
                    current_user,
                    inet_client_addr(),
                    current_setting('application_name'),
                    NOW()
                )::audit_logs;
                
                IF (TG_OP = 'UPDATE') THEN
                    old_data = to_jsonb(OLD);
                    new_data = to_jsonb(NEW);
                    
                    -- Remove excluded columns
                    FOREACH column_name IN ARRAY excluded_columns
                    LOOP
                        old_data = old_data - column_name;
                        new_data = new_data - column_name;
                    END LOOP;
                    
                    -- Only log if something actually changed
                    IF (old_data != new_data) THEN
                        audit_row.old_values = old_data;
                        audit_row.new_values = new_data;
                        audit_row.record_id = COALESCE(OLD.id::TEXT, NEW.id::TEXT);
                        INSERT INTO audit_logs VALUES (audit_row.*);
                    END IF;
                    
                ELSIF (TG_OP = 'DELETE') THEN
                    audit_row.old_values = to_jsonb(OLD);
                    audit_row.record_id = OLD.id::TEXT;
                    INSERT INTO audit_logs VALUES (audit_row.*);
                    
                ELSIF (TG_OP = 'INSERT') THEN
                    audit_row.new_values = to_jsonb(NEW);
                    audit_row.record_id = NEW.id::TEXT;
                    INSERT INTO audit_logs VALUES (audit_row.*);
                END IF;
                
                RETURN NULL;
            END;
            $$ language 'plpgsql';
        """))
        
        # Apply audit triggers to key tables
        tables_to_audit = ['users', 'billing_events', 'billing_ledger', 'usage_records']
        
        for table_name in tables_to_audit:
            conn.execute(text(f"""
                CREATE TRIGGER audit_{table_name}_trigger
                AFTER INSERT OR UPDATE OR DELETE ON {table_name}
                FOR EACH ROW
                EXECUTE FUNCTION audit_trigger_function();
            """))
        
        log_migration_step('create_audit_log_table', step, 'completed')
        
    except Exception as e:
        logger.error(f"Failed to create audit log table: {e}")
        log_migration_step('create_audit_log_table', step, 'failed', {'error': str(e)})
        raise


def create_functions_and_triggers():
    """Create additional database functions and triggers."""
    step = 7
    log_migration_step('create_functions_and_triggers', step, 'started')
    
    try:
        conn = op.get_bind()
        
        # Function to safely update user balance
        conn.execute(text("""
            CREATE OR REPLACE FUNCTION update_user_balance(
                p_user_id INTEGER,
                p_amount NUMERIC,
                p_event_id UUID
            )
            RETURNS TABLE (
                success BOOLEAN,
                old_balance NUMERIC,
                new_balance NUMERIC,
                error_message TEXT
            ) AS $$
            DECLARE
                v_current_balance NUMERIC;
                v_new_balance NUMERIC;
                v_lock_acquired BOOLEAN;
            BEGIN
                -- Try to acquire lock
                INSERT INTO billing_locks (user_id, expires_at)
                VALUES (p_user_id, NOW() + INTERVAL '30 seconds')
                ON CONFLICT (user_id, resource_type) 
                DO UPDATE SET 
                    lock_id = gen_random_uuid(),
                    expires_at = NOW() + INTERVAL '30 seconds'
                WHERE billing_locks.expires_at < NOW()
                RETURNING TRUE INTO v_lock_acquired;
                
                IF NOT v_lock_acquired THEN
                    RETURN QUERY SELECT FALSE, 0::NUMERIC, 0::NUMERIC, 
                                 'Could not acquire lock for user';
                    RETURN;
                END IF;
                
                -- Get current balance
                SELECT balance INTO v_current_balance 
                FROM users 
                WHERE id = p_user_id 
                FOR UPDATE;
                
                -- Calculate new balance
                v_new_balance := v_current_balance + p_amount;
                
                -- Check if new balance is valid
                IF v_new_balance < 0 THEN
                    RETURN QUERY SELECT FALSE, v_current_balance, v_new_balance,
                                 'Insufficient balance';
                ELSE
                    -- Update balance
                    UPDATE users 
                    SET balance = v_new_balance,
                        version = version + 1
                    WHERE id = p_user_id;
                    
                    -- Record in ledger
                    INSERT INTO billing_ledger (
                        event_id, user_id, entry_type, account,
                        amount, balance_before, balance_after
                    ) VALUES (
                        p_event_id, p_user_id,
                        CASE WHEN p_amount >= 0 THEN 'credit' ELSE 'debit' END,
                        'user_balance',
                        p_amount,
                        v_current_balance,
                        v_new_balance
                    );
                    
                    RETURN QUERY SELECT TRUE, v_current_balance, v_new_balance, NULL;
                END IF;
                
                -- Release lock (it will expire automatically)
            EXCEPTION WHEN OTHERS THEN
                RETURN QUERY SELECT FALSE, 0::NUMERIC, 0::NUMERIC, SQLERRM;
            END;
            $$ language 'plpgsql';
        """))
        
        # Function to process billing event
        conn.execute(text("""
            CREATE OR REPLACE FUNCTION process_billing_event(
                p_event_id UUID
            )
            RETURNS TABLE (
                success BOOLEAN,
                user_balance NUMERIC,
                error_details JSONB
            ) AS $$
            DECLARE
                v_event billing_events%ROWTYPE;
                v_balance_result RECORD;
            BEGIN
                -- Get event details with lock
                SELECT * INTO v_event 
                FROM billing_events 
                WHERE id = p_event_id 
                FOR UPDATE;
                
                IF NOT FOUND THEN
                    RETURN QUERY SELECT FALSE, 0::NUMERIC, 
                                 jsonb_build_object('error', 'Event not found');
                    RETURN;
                END IF;
                
                -- Check if already processed
                IF v_event.status != 'pending' THEN
                    RETURN QUERY SELECT FALSE, 0::NUMERIC,
                                 jsonb_build_object('error', 'Event already processed');
                    RETURN;
                END IF;
                
                -- Update event status to processing
                UPDATE billing_events 
                SET status = 'processing',
                    updated_at = NOW()
                WHERE id = p_event_id;
                
                -- Process based on event type
                IF v_event.event_type = 'charge' THEN
                    -- Deduct from user balance
                    SELECT * INTO v_balance_result
                    FROM update_user_balance(v_event.user_id, -v_event.amount, p_event_id);
                    
                    IF NOT v_balance_result.success THEN
                        -- Mark as failed
                        UPDATE billing_events 
                        SET status = 'failed',
                            error_details = jsonb_build_object(
                                'error', v_balance_result.error_message,
                                'old_balance', v_balance_result.old_balance,
                                'new_balance', v_balance_result.new_balance
                            ),
                            updated_at = NOW()
                        WHERE id = p_event_id;
                        
                        RETURN QUERY SELECT FALSE, v_balance_result.old_balance,
                                     v_balance_result.error_details;
                    ELSE
                        -- Mark as completed
                        UPDATE billing_events 
                        SET status = 'completed',
                            completed_at = NOW(),
                            updated_at = NOW()
                        WHERE id = p_event_id;
                        
                        RETURN QUERY SELECT TRUE, v_balance_result.new_balance, NULL;
                    END IF;
                    
                ELSE
                    -- Handle other event types
                    UPDATE billing_events 
                    SET status = 'failed',
                        error_details = jsonb_build_object(
                            'error', 'Unsupported event type',
                            'event_type', v_event.event_type
                        ),
                        updated_at = NOW()
                    WHERE id = p_event_id;
                    
                    RETURN QUERY SELECT FALSE, 0::NUMERIC,
                                 jsonb_build_object('error', 'Unsupported event type');
                END IF;
                
            EXCEPTION WHEN OTHERS THEN
                -- Update event with error
                UPDATE billing_events 
                SET status = 'failed',
                    error_details = jsonb_build_object(
                        'error', SQLERRM,
                        'detail', SQLSTATE
                    ),
                    updated_at = NOW()
                WHERE id = p_event_id;
                
                RETURN QUERY SELECT FALSE, 0::NUMERIC,
                             jsonb_build_object('error', SQLERRM, 'state', SQLSTATE);
            END;
            $$ language 'plpgsql';
        """))
        
        log_migration_step('create_functions_and_triggers', step, 'completed')
        
    except Exception as e:
        logger.error(f"Failed to create functions and triggers: {e}")
        log_migration_step('create_functions_and_triggers', step, 'failed', {'error': str(e)})
        raise


def create_constraint_validations():
    """Create additional constraint validations and checks."""
    step = 8
    log_migration_step('create_constraint_validations', step, 'started')
    
    try:
        conn = op.get_bind()
        
        # Create validation views
        conn.execute(text("""
            -- View for data quality checks
            CREATE VIEW billing_data_quality AS
            SELECT 
                'users' as table_name,
                COUNT(*) as total_rows,
                SUM(CASE WHEN balance < 0 THEN 1 ELSE 0 END) as negative_balances,
                SUM(CASE WHEN email IS NULL OR email = '' THEN 1 ELSE 0 END) as missing_emails
            FROM users
            UNION ALL
            SELECT 
                'billing_events',
                COUNT(*),
                SUM(CASE WHEN amount < 0 AND event_type != 'refund' THEN 1 ELSE 0 END),
                SUM(CASE WHEN user_id IS NULL THEN 1 ELSE 0 END)
            FROM billing_events
            UNION ALL
            SELECT 
                'billing_ledger',
                COUNT(*),
                SUM(CASE WHEN balance_after != balance_before + amount THEN 1 ELSE 0 END),
                SUM(CASE WHEN event_id IS NULL THEN 1 ELSE 0 END)
            FROM billing_ledger;
            
            -- View for financial reconciliation
            CREATE VIEW financial_reconciliation AS
            SELECT 
                u.id as user_id,
                u.email,
                u.balance as current_balance,
                COALESCE(SUM(
                    CASE 
                        WHEN bl.entry_type = 'credit' THEN bl.amount
                        WHEN bl.entry_type = 'debit' THEN -bl.amount
                        ELSE 0
                    END
                ), 0) as calculated_balance,
                u.balance - COALESCE(SUM(
                    CASE 
                        WHEN bl.entry_type = 'credit' THEN bl.amount
                        WHEN bl.entry_type = 'debit' THEN -bl.amount
                        ELSE 0
                    END
                ), 0) as discrepancy
            FROM users u
            LEFT JOIN billing_ledger bl ON u.id = bl.user_id AND bl.account = 'user_balance'
            GROUP BY u.id, u.email, u.balance
            HAVING ABS(u.balance - COALESCE(SUM(
                CASE 
                    WHEN bl.entry_type = 'credit' THEN bl.amount
                    WHEN bl.entry_type = 'debit' THEN -bl.amount
                    ELSE 0
                END
            ), 0)) > 0.0001;
        """))
        
        log_migration_step('create_constraint_validations', step, 'completed')
        
    except Exception as e:
        logger.error(f"Failed to create constraint validations: {e}")
        log_migration_step('create_constraint_validations', step, 'failed', {'error': str(e)})
        raise


def verify_migration():
    """Verify that all tables and constraints were created correctly."""
    step = 9
    log_migration_step('verify_migration', step, 'started')
    
    try:
        conn = op.get_bind()
        
        # List of expected tables
        expected_tables = [
            'users', 'billing_events', 'billing_ledger', 
            'usage_records', 'billing_locks', 'audit_logs',
            'alembic_migration_progress'
        ]
        
        # Verify each table exists
        for table_name in expected_tables:
            result = conn.execute(text("""
                SELECT EXISTS (
                    SELECT FROM information_schema.tables 
                    WHERE table_name = :table_name
                );
            """), {'table_name': table_name})
            
            if not result.scalar():
                error_msg = f"Table '{table_name}' was not created"
                log_migration_step('verify_migration', step, 'failed', {'error': error_msg})
                raise ValueError(error_msg)
        
        # Count total migration steps
        result = conn.execute(text("""
            SELECT COUNT(DISTINCT step_number) as total_steps,
                   SUM(CASE WHEN status = 'completed' THEN 1 ELSE 0 END) as completed_steps
            FROM alembic_migration_progress
            WHERE migration_version = 'xxx_create_atomic_billing';
        """))
        
        stats = result.fetchone()
        logger.info(f"Migration verification: {stats[1]}/{stats[0]} steps completed")
        
        if stats[1] != stats[0]:
            error_msg = f"Incomplete migration: {stats[1]}/{stats[0]} steps completed"
            log_migration_step('verify_migration', step, 'failed', {'error': error_msg})
            raise ValueError(error_msg)
        
        log_migration_step('verify_migration', step, 'completed')
        
    except Exception as e:
        logger.error(f"Migration verification failed: {e}")
        log_migration_step('verify_migration', step, 'failed', {'error': str(e)})
        raise


def upgrade():
    """Main upgrade function with comprehensive error handling."""
    logger.info("Starting atomic billing migration...")
    
    try:
        # Step 0: Setup migration tracking
        create_migration_tracking()
        
        # Step 1: Validate existing data
        validate_existing_data()
        
        # Step 2-6: Create tables
        create_users_table()
        create_billing_events_table()
        create_billing_ledger_table()
        create_usage_records_table()
        create_billing_locks_table()
        create_audit_log_table()
        
        # Step 7: Create functions and triggers
        create_functions_and_triggers()
        
        # Step 8: Create constraint validations
        create_constraint_validations()
        
        # Step 9: Verify migration
        verify_migration()
        
        logger.info("✅ Atomic billing migration completed successfully!")
        
        # Final summary
        conn = op.get_bind()
        result = conn.execute(text("""
            SELECT table_name, 
                   (xpath('/row/count/text()', 
                     query_to_xml(format('SELECT COUNT(*) FROM %I', table_name), 
                     false, true, '')))[1]::text::int as row_count
            FROM information_schema.tables 
            WHERE table_schema = 'public' 
            AND table_name IN ('users', 'billing_events', 'billing_ledger', 
                              'usage_records', 'billing_locks', 'audit_logs')
            ORDER BY table_name;
        """))
        
        logger.info("Migration Summary:")
        for row in result:
            logger.info(f"  {row[0]}: {row[1]} rows")
            
    except Exception as e:
        logger.error(f"❌ Migration failed: {e}")
        
        # Log final error
        conn = op.get_bind()
        conn.execute(text("""
            INSERT INTO alembic_migration_progress 
            (migration_version, step_name, step_number, status, error_message)
            VALUES ('xxx_create_atomic_billing', 'migration_failed', 999, 'failed', :error);
        """), {'error': str(e)})
        
        raise


def downgrade():
    """Comprehensive downgrade function with safety checks."""
    logger.info("Starting atomic billing migration rollback...")
    
    try:
        conn = op.get_bind()
        
        # Step 1: Backup critical data before dropping
        logger.info("Backing up data before rollback...")
        
        # Create backup tables
        backup_tables = ['users', 'billing_events', 'billing_ledger', 
                        'usage_records', 'billing_locks', 'audit_logs']
        
        for table in backup_tables:
            backup_name = f"{table}_backup_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
            conn.execute(text(f"""
                CREATE TABLE {backup_name} AS 
                SELECT * FROM {table};
                
                COMMENT ON TABLE {backup_name} IS 
                'Backup created during migration rollback at {datetime.now()}';
            """))
            logger.info(f"Created backup: {backup_name}")
        
        # Step 2: Drop functions and triggers (in reverse order)
        logger.info("Dropping functions and triggers...")
        
        # Drop audit triggers
        tables_to_audit = ['users', 'billing_events', 'billing_ledger', 'usage_records']
        for table_name in tables_to_audit:
            conn.execute(text(f"""
                DROP TRIGGER IF EXISTS audit_{table_name}_trigger ON {table_name} CASCADE;
            """))
        
        # Drop functions
        functions_to_drop = [
            'audit_trigger_function',
            'update_user_balance',
            'process_billing_event',
            'increment_usage_version',
            'validate_billing_event_idempotency',
            'refresh_account_balances',
            'cleanup_expired_locks',
            'update_updated_at_column'
        ]
        
        for function in functions_to_drop:
            conn.execute(text(f"DROP FUNCTION IF EXISTS {function} CASCADE;"))
        
        # Step 3: Drop views and materialized views
        logger.info("Dropping views and materialized views...")
        conn.execute(text("""
            DROP VIEW IF EXISTS billing_data_quality CASCADE;
            DROP VIEW IF EXISTS financial_reconciliation CASCADE;
            DROP MATERIALIZED VIEW IF EXISTS account_balances CASCADE;
        """))
        
        # Step 4: Drop tables in reverse dependency order
        logger.info("Dropping tables...")
        tables_to_drop = [
            'audit_logs',
            'billing_locks',
            'usage_records',
            'billing_ledger',
            'billing_events',
            'users'
        ]
        
        for table in tables_to_drop:
            conn.execute(text(f"DROP TABLE IF EXISTS {table} CASCADE;"))
            logger.info(f"Dropped table: {table}")
        
        # Step 5: Clean up migration tracking
        logger.info("Cleaning up migration tracking...")
        conn.execute(text("""
            DELETE FROM alembic_migration_progress 
            WHERE migration_version = 'xxx_create_atomic_billing';
        """))
        
        # Optional: Drop migration tracking table (keep for future migrations)
        # conn.execute(text("DROP TABLE IF EXISTS alembic_migration_progress CASCADE;"))
        
        logger.info("✅ Rollback completed successfully!")
        logger.info("⚠️  Backup tables have been created with timestamp suffix.")
        logger.info("   Review and manually drop backup tables when confirmed safe.")
        
    except Exception as e:
        logger.error(f"❌ Rollback failed: {e}")
        logger.error("Backup tables may have been created. Check database for *_backup_* tables.")
        raise