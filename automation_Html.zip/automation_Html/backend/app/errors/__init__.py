"""
Centralized error handling for the application
"""
from flask import jsonify, request
from werkzeug.exceptions import HTTPException
import logging
from typing import Dict, Any, Optional

logger = logging.getLogger(__name__)

class AppError(Exception):
    """Base application error class"""
    def __init__(self, message: str, status_code: int = 500, 
                 error_code: Optional[str] = None, details: Optional[Dict] = None):
        super().__init__(message)
        self.message = message
        self.status_code = status_code
        self.error_code = error_code
        self.details = details or {}

class BusinessError(AppError):
    """Business logic errors (400-499 range)"""
    def __init__(self, message: str, error_code: Optional[str] = None, 
                 details: Optional[Dict] = None):
        super().__init__(message, status_code=400, error_code=error_code, details=details)

class AuthError(AppError):
    """Authentication/Authorization errors"""
    def __init__(self, message: str = "Unauthorized", error_code: Optional[str] = None):
        super().__init__(message, status_code=401, error_code=error_code)

class ForbiddenError(AppError):
    """Permission denied errors"""
    def __init__(self, message: str = "Forbidden", error_code: Optional[str] = None):
        super().__init__(message, status_code=403, error_code=error_code)

class NotFoundError(AppError):
    """Resource not found errors"""
    def __init__(self, message: str = "Resource not found", error_code: Optional[str] = None):
        super().__init__(message, status_code=404, error_code=error_code)

# Error schemas for consistent responses
ERROR_SCHEMA = {
    "error": {
        "message": "Error message",
        "code": "ERROR_CODE",  # Machine-readable code
        "status": 400,
        "details": {},  # Additional context
        "request_id": "optional-request-id"
    }
}

def create_error_response(message: str, status_code: int = 500, 
                         error_code: Optional[str] = None, 
                         details: Optional[Dict] = None) -> Dict:
    """Create a standardized error response"""
    return {
        "error": {
            "message": message,
            "code": error_code or f"ERR_{status_code}",
            "status": status_code,
            "details": details or {},
            "request_id": getattr(request, 'request_id', None) if request else None
        }
    }

def register_error_handlers(app):
    """Register global error handlers"""
    
    @app.errorhandler(AppError)
    def handle_app_error(error: AppError):
        """Handle custom application errors"""
        logger.warning(f"AppError: {error.message}", exc_info=True, 
                      extra={'status_code': error.status_code, 'error_code': error.error_code})
        
        response = jsonify(create_error_response(
            message=error.message,
            status_code=error.status_code,
            error_code=error.error_code,
            details=error.details
        ))
        response.status_code = error.status_code
        return response
    
    @app.errorhandler(HTTPException)
    def handle_http_error(error: HTTPException):
        """Handle HTTP exceptions"""
        logger.info(f"HTTPError: {error.description}", 
                   extra={'status_code': error.code})
        
        response = jsonify(create_error_response(
            message=error.description,
            status_code=error.code
        ))
        response.status_code = error.code
        return response
    
    @app.errorhandler(Exception)
    def handle_unexpected_error(error: Exception):
        """Catch-all for unexpected errors"""
        error_id = f"err_{hash(error) % 1000000:06d}"
        logger.error(f"Unexpected error [{error_id}]: {str(error)}", 
                    exc_info=True, extra={'error_id': error_id})
        
        # Never expose internal error details in production
        message = "An internal server error occurred"
        if app.config.get('ENV') == 'development':
            message = f"{str(error)} [{error_id}]"
        
        response = jsonify(create_error_response(
            message=message,
            status_code=500,
            error_code="INTERNAL_SERVER_ERROR",
            details={"error_id": error_id} if app.config.get('ENV') != 'development' else {}
        ))
        response.status_code = 500
        return response