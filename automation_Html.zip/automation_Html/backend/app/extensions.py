"""
Flask extensions initialization.
No logging configuration here - it's centralized in utils/logging.py
"""
from flask_sqlalchemy import SQLAlchemy
from flask_login import LoginManager
from flask_migrate import Migrate
from flask_jwt_extended import JWTManager
from flask_cors import CORS
from flask_limiter import Limiter
from flask_limiter.util import get_remote_address

import stripe
from core.config import settings

stripe.api_key = settings.STRIPE_SECRET_KEY


# Initialize extensions
db = SQLAlchemy()
login_manager = LoginManager()
migrate = Migrate()
jwt = JWTManager()
cors = CORS()
limiter = Limiter(key_func=get_remote_address, default_limits=["200 per day", "50 per hour"])

def init_extensions(app):
    """
    Initialize all Flask extensions with the app.
    
    Args:
        app: Flask application instance
    """
    db.init_app(app)
    login_manager.init_app(app)
    migrate.init_app(app, db)
    jwt.init_app(app)
    cors.init_app(app)
    limiter.init_app(app)  # Initialize rate limiter
    
    # Configure login manager
    login_manager.login_view = 'auth.login'
    login_manager.login_message_category = 'info'
    
    # Optional: Configure JWT settings
    app.config.setdefault('JWT_TOKEN_LOCATION', ['headers'])
    app.config.setdefault('JWT_ACCESS_TOKEN_EXPIRES', 3600)  # 1 hour
    
    return app