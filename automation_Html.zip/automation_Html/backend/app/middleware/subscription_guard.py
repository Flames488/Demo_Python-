from flask import abort
from flask_jwt_extended import get_jwt_identity
from functools import wraps
import logging

logger = logging.getLogger(__name__)

class SubscriptionService:
    """Mock subscription service - implement your actual logic here"""
    
    @staticmethod
    def check_subscription_status(user_id):
        """Check if user has active subscription"""
        # TODO: Implement actual subscription check
        # This could check database, external service, etc.
        
        # Mock implementation
        return True  # Change to actual logic
    
    @staticmethod
    def get_subscription_tier(user_id):
        """Get user's subscription tier"""
        # TODO: Implement actual tier retrieval
        return "premium"


def subscription_required(tier=None):
    """Middleware to require subscription"""
    def decorator(fn):
        @wraps(fn)
        def wrapper(*args, **kwargs):
            user_id = get_jwt_identity()
            
            # Check if subscription is active
            if not SubscriptionService.check_subscription_status(user_id):
                logger.warning(f"Subscription required for user {user_id}")
                abort(402, description="Active subscription required")
            
            # Check specific tier if required
            if tier:
                user_tier = SubscriptionService.get_subscription_tier(user_id)
                tier_hierarchy = ['basic', 'pro', 'premium', 'enterprise']
                
                if tier_hierarchy.index(user_tier) < tier_hierarchy.index(tier):
                    abort(403, description=f"{tier} subscription required")
            
            return fn(*args, **kwargs)
        return wrapper
    return decorator