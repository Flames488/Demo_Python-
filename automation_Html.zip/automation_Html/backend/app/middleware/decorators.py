# File: app/middleware/decorators.py
"""
Decorators for fine-grained control when needed.
Use these when you need different behavior than the global defaults.
"""

from functools import wraps
from flask import request, g
from . import middleware_manager


def public_route(f):
    """Explicitly mark a route as public (no auth required)."""
    @wraps(f)
    def decorated_function(*args, **kwargs):
        # Temporarily bypass auth for this route
        g._auth_bypassed = True
        return f(*args, **kwargs)
    return decorated_function


def custom_auth(auth_func):
    """Use custom authentication for this route."""
    def decorator(f):
        @wraps(f)
        def wrapper(*args, **kwargs):
            user = auth_func(request)
            if not user:
                abort(401, "Custom authentication failed")
            
            g.user = user
            g.auth_method = 'custom'
            return f(*args, **kwargs)
        return wrapper
    return decorator


def exempt_from_rate_limit(f):
    """Exempt this route from rate limiting."""
    middleware_manager.exempt(request.path, {request.method})
    return f


def require_tier(tier):
    """Require specific subscription tier for this route."""
    def decorator(f):
        @wraps(f)
        def wrapper(*args, **kwargs):
            user = getattr(g, 'user', None)
            if not user:
                abort(401, "Authentication required")
            
            user_tier = getattr(user, 'subscription_tier', 'free')
            tier_levels = {'free': 0, 'basic': 1, 'pro': 2, 'premium': 3, 'enterprise': 4}
            
            if tier_levels.get(user_tier, 0) < tier_levels.get(tier, 0):
                abort(403, f"{tier} subscription required")
            
            return f(*args, **kwargs)
        return wrapper
    return decorator