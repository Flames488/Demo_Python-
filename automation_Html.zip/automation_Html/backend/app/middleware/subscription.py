from functools import wraps
from flask import jsonify, request, g
from flask_jwt_extended import get_jwt_identity
from datetime import datetime
from models import User
from backend.utils.auth import decode_jwt  # Add this import

def require_plan(*allowed_plans):
    """
    Decorator to check user's plan against allowed plans.
    Example usage: @require_plan('premium', 'business') or @require_plan('premium')
    
    Works with flask_jwt_extended's get_jwt_identity().
    Also checks plan expiration for non-free plans.
    """
    def decorator(fn):
        @wraps(fn)
        def wrapper(*args, **kwargs):
            user_id = get_jwt_identity()
            user = User.query.get(user_id)

            if not user:
                return jsonify({"error": "User not found"}), 401

            if user.plan not in allowed_plans:
                return jsonify({
                    "error": "Upgrade required",
                    "required_plan": allowed_plans
                }), 403

            if user.plan != "free" and user.plan_expires_at:
                if user.plan_expires_at < datetime.utcnow():
                    return jsonify({
                        "error": "Subscription expired"
                    }), 403

            return fn(*args, **kwargs)
        return wrapper
    return decorator


def subscription_required(required_tier):
    """
    Decorator to enforce subscription tier on routes.
    Example usage: @subscription_required('premium')
    
    Works with raw JWT tokens from Authorization header.
    Uses decode_jwt() from backend.utils.auth.
    """
    def decorator(f):
        @wraps(f)
        def wrapper(*args, **kwargs):
            auth_header = request.headers.get('Authorization')
            if not auth_header:
                return jsonify({"error": "Missing auth token"}), 401

            token = auth_header.split(" ")[1] if " " in auth_header else auth_header
            user_data = decode_jwt(token)
            if not user_data:
                return jsonify({"error": "Invalid token"}), 401

            user_tier = user_data.get("subscription_tier", "free")
            if user_tier.lower() != required_tier.lower():
                return jsonify({"error": "Upgrade your subscription to access this resource"}), 403

            return f(*args, **kwargs)
        return wrapper
    return decorator


def require_active_subscription(feature=None):
    """
    Decorator to check for active subscription and optional feature access.
    Example usage: 
        @require_active_subscription() - just checks for active subscription
        @require_active_subscription('advanced_analytics') - checks for specific feature
    
    Assumes g.user is set (e.g., from a before_request hook that loads the user).
    """
    def decorator(f):
        @wraps(f)
        def wrapper(*args, **kwargs):
            # Check if user is available in g context
            if not hasattr(g, 'user') or not g.user:
                return jsonify({"error": "User not found in context"}), 401
            
            sub = g.user.subscription

            if not sub or sub.status != "active":
                return jsonify({"error": "Subscription required"}), 403

            if sub.expires_at < datetime.utcnow():
                return jsonify({"error": "Subscription expired"}), 403

            if feature and not sub.has_feature(feature):
                return jsonify({"error": "Upgrade required"}), 403

            return f(*args, **kwargs)
        return wrapper
    return decorator


# Optional: Add a helper decorator to select the right authentication method
def require_auth(method='jwt_extended'):
    """
    Helper decorator to select which authentication/subscription check to use.
    Options: 'jwt_extended', 'raw_jwt', 'context_user'
    """
    def decorator(f):
        @wraps(f)
        def wrapper(*args, **kwargs):
            # This would need to be implemented based on your application's needs
            # For now, it just passes through
            return f(*args, **kwargs)
        return wrapper
    return decorator