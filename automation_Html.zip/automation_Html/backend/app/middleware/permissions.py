from flask import abort
from flask_jwt_extended import get_jwt
from functools import wraps
from flask import g, jsonify

class PermissionManager:
    """Centralized permission management"""
    
    ROLES = {
        'admin': ['admin:read', 'admin:write', 'user:read', 'user:write'],
        'user': ['user:read', 'user:write'],
        'guest': ['user:read']
    }
    
    @staticmethod
    def has_permission(required_permission):
        """Check if user has specific permission"""
        claims = get_jwt()
        user_role = claims.get('role', 'guest')
        
        if user_role not in PermissionManager.ROLES:
            return False
            
        return required_permission in PermissionManager.ROLES[user_role]


def permission_required(permission):
    """Decorator for specific permission checks"""
    def decorator(fn):
        @wraps(fn)
        def wrapper(*args, **kwargs):
            if not PermissionManager.has_permission(permission):
                abort(403, description=f"Permission '{permission}' required")
            return fn(*args, **kwargs)
        return wrapper
    return decorator


def role_required(role):
    """Enhanced role checker with permission inheritance"""
    def decorator(fn):
        @wraps(fn)
        def wrapper(*args, **kwargs):
            claims = get_jwt()
            user_role = claims.get('role')
            
            # Role hierarchy (admin > user > guest)
            role_hierarchy = ['guest', 'user', 'admin']
            
            if user_role not in role_hierarchy:
                abort(403, description="Invalid role")
            
            if role_hierarchy.index(user_role) < role_hierarchy.index(role):
                abort(403, description=f"Role '{role}' or higher required")
            
            return fn(*args, **kwargs)
        return wrapper
    return decorator



def require_role(*roles):
    def decorator(f):
        @wraps(f)
        def wrapper(*args, **kwargs):
            if g.user.role not in roles:
                return jsonify({"error": "Forbidden"}), 403
            return f(*args, **kwargs)
        return wrapper
    return decorator
