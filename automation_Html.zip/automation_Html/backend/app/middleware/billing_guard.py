from functools import wraps
from flask import request
from app.subscriptions.service import get_active_subscription
from app.billing.usage import consume_usage

def billing_required(feature: str):
    def decorator(fn):
        @wraps(fn)
        def wrapper(*args, **kwargs):
            user = request.user  # assumed from auth middleware

            get_active_subscription(user.id)
            consume_usage(user.id, feature)

            return fn(*args, **kwargs)
        return wrapper
    return decorator
