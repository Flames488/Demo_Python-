from flask import request, jsonify, g, current_app
from functools import wraps
import time
import hashlib
import threading
import redis
from collections import defaultdict
import json
from datetime import datetime, timedelta
from typing import Optional, Dict, Any, Callable

# Remove slowapi imports since we're building our own
# from slowapi import Limiter
# from slowapi.util import get_remote_address

# Redis connection pool (thread-safe)
redis_pool = None

def get_redis():
    """Get Redis connection from pool"""
    global redis_pool
    
    if redis_pool is None:
        redis_pool = redis.ConnectionPool.from_url(
            current_app.config.get('REDIS_URL', 'redis://localhost:6379/0'),
            decode_responses=True,
            max_connections=20
        )
    
    return redis.Redis(connection_pool=redis_pool)


class RedisRateLimiter:
    """Production-ready Redis-based rate limiter with multiple strategies"""
    
    _instance = None
    _lock = threading.Lock()
    
    def __new__(cls):
        with cls._lock:
            if cls._instance is None:
                cls._instance = super().__new__(cls)
                cls._instance.redis = get_redis()
                # Fallback in-memory limiter if Redis is unavailable
                cls._instance.fallback_requests = defaultdict(list)
        return cls._instance
    
    def is_allowed(
        self, 
        key: str, 
        limit: int, 
        window: int,
        burst_limit: Optional[int] = None,
        cost: int = 1
    ) -> Dict[str, Any]:
        """
        Check if request is within rate limits using Redis sorted sets
        
        Args:
            key: Rate limit key
            limit: Maximum requests per window
            window: Time window in seconds
            burst_limit: Optional burst limit (higher than sustained limit)
            cost: Cost of this request (default 1)
            
        Returns:
            Dict with allowed status and metadata
        """
        current_time = time.time()
        window_start = current_time - window
        
        try:
            r = self.redis
            pipe = r.pipeline()
            
            # Use sorted set to track requests
            zset_key = f"ratelimit:{key}"
            
            # Remove old requests
            pipe.zremrangebyscore(zset_key, 0, window_start)
            
            # Get current count
            pipe.zcard(zset_key)
            
            # Check burst limit first if specified
            if burst_limit:
                burst_zset_key = f"ratelimit:burst:{key}"
                pipe.zremrangebyscore(burst_zset_key, 0, current_time - 5)  # 5s burst window
                pipe.zcard(burst_zset_key)
            
            results = pipe.execute()
            
            current_count = results[1]
            
            # Check burst limit
            if burst_limit and results[3] >= burst_limit:
                return {
                    'allowed': False,
                    'limit': burst_limit,
                    'remaining': 0,
                    'reset': int(current_time + 5),  # 5s burst window
                    'window': 5,
                    'burst_violation': True
                }
            
            # Check sustained limit
            if current_count + cost > limit:
                # Get oldest request time to calculate reset time
                oldest = r.zrange(zset_key, 0, 0, withscores=True)
                reset_time = int(oldest[0][1] + window) if oldest else int(current_time + window)
                
                return {
                    'allowed': False,
                    'limit': limit,
                    'remaining': 0,
                    'reset': reset_time,
                    'window': window,
                    'burst_violation': False
                }
            
            # Add current request
            pipe.zadd(zset_key, {str(current_time): current_time})
            pipe.expire(zset_key, window + 10)  # Keep slightly longer than window
            
            if burst_limit:
                pipe.zadd(burst_zset_key, {str(current_time): current_time})
                pipe.expire(burst_zset_key, 10)  # Short expiration for burst tracking
            
            pipe.execute()
            
            return {
                'allowed': True,
                'limit': limit,
                'remaining': limit - (current_count + cost),
                'reset': int(current_time + window),
                'window': window
            }
            
        except redis.RedisError:
            # Fallback to in-memory limiter if Redis fails
            current_app.logger.warning("Redis unavailable, using in-memory rate limiting")
            return self._fallback_is_allowed(key, limit, window, cost)
    
    def _fallback_is_allowed(self, key, limit, window, cost=1):
        """In-memory fallback if Redis is unavailable"""
        current_time = time.time()
        
        with self._lock:
            # Clean old requests
            self.fallback_requests[key] = [
                req_time for req_time in self.fallback_requests[key] 
                if current_time - req_time < window
            ]
            
            # Check if under limit
            if len(self.fallback_requests[key]) + cost <= limit:
                for _ in range(cost):
                    self.fallback_requests[key].append(current_time)
                return {
                    'allowed': True,
                    'limit': limit,
                    'remaining': limit - len(self.fallback_requests[key]),
                    'reset': int(current_time + window),
                    'window': window,
                    'fallback': True
                }
            
            return {
                'allowed': False,
                'limit': limit,
                'remaining': 0,
                'reset': int(self.fallback_requests[key][0] + window) if self.fallback_requests[key] else int(current_time + window),
                'window': window,
                'fallback': True
            }


def get_user_id():
    """
    Enhanced user ID extraction with proper authentication checks
    
    Returns:
        Tuple: (user_id, is_authenticated, authentication_method)
    """
    user_id = 'anonymous'
    is_authenticated = False
    auth_method = None
    
    # Check multiple authentication methods with priority
    
    # 1. JWT token (highest priority)
    auth_header = request.headers.get('Authorization')
    if auth_header and auth_header.startswith('Bearer '):
        try:
            # In production, decode and verify JWT
            # This is a simplified example
            token = auth_header.split(' ')[1]
            # Verify token and extract user_id
            # user_id = jwt.decode(token, verify=True)['sub']
            user_id = f"jwt_{hashlib.md5(token[-20:].encode()).hexdigest()[:8]}"
            is_authenticated = True
            auth_method = 'jwt'
        except Exception:
            pass
    
    # 2. API Key
    api_key = request.headers.get('X-API-Key') or request.args.get('api_key')
    if api_key and not is_authenticated:
        # Validate API key against database/cache
        user_id = f"api_{hashlib.md5(api_key.encode()).hexdigest()[:12]}"
        is_authenticated = True
        auth_method = 'api_key'
    
    # 3. Session-based
    if not is_authenticated and hasattr(g, 'user') and g.user and hasattr(g.user, 'id'):
        user_id = str(g.user.id)
        is_authenticated = True
        auth_method = 'session'
    
    # 4. Custom header (lowest priority)
    if not is_authenticated:
        custom_user_id = request.headers.get('X-User-ID')
        if custom_user_id:
            user_id = f"custom_{custom_user_id}"
            # Not considered fully authenticated
            auth_method = 'header'
    
    return user_id, is_authenticated, auth_method


def get_client_fingerprint() -> str:
    """
    Generate a comprehensive client fingerprint to prevent IP rotation attacks
    
    Combines:
    - IP address
    - User agent hash
    - Accept language
    - Timezone offset (if available via JS)
    - Screen resolution (if available)
    """
    ip = request.remote_addr or 'unknown_ip'
    user_agent = request.headers.get('User-Agent', '')
    accept_lang = request.headers.get('Accept-Language', '')
    
    # Get additional headers that can fingerprint clients
    fingerprint_parts = [
        ip,
        hashlib.sha256(user_agent.encode()).hexdigest()[:16],
        hashlib.md5(accept_lang.encode()).hexdigest()[:8],
        request.headers.get('X-Client-TZ', ''),
        request.headers.get('X-Client-Screen', ''),
        request.headers.get('X-Client-Timezone', ''),
    ]
    
    fingerprint = hashlib.sha256('|'.join(filter(None, fingerprint_parts)).encode()).hexdigest()[:32]
    
    return f"fp:{fingerprint}"


def rate_limit(
    limit: int = 100, 
    window: int = 60, 
    burst_limit: Optional[int] = None,
    key_func: Optional[Callable] = None,
    strict_mode: bool = False,
    scope: str = "endpoint",  # "global", "endpoint", "user", "ip"
    cost: int = 1,
    per_user: bool = True
):
    """
    Advanced rate limiting middleware with multiple strategies
    
    Args:
        limit: Maximum requests per window
        window: Time window in seconds
        burst_limit: Optional burst limit (e.g., 150 in first 5 seconds)
        key_func: Custom function to generate rate limit key
        strict_mode: Apply stricter limits for anonymous users
        scope: Scope of rate limiting: "global", "endpoint", "user", "ip"
        cost: Cost of this request (for weighted endpoints)
        per_user: Whether to scope by user (False for IP-only limits)
    """
    limiter = RedisRateLimiter()
    
    def decorator(fn):
        @wraps(fn)
        def wrapper(*args, **kwargs):
            # Generate rate limit key
            if key_func:
                rate_key = key_func()
            else:
                # Get client information
                ip = request.remote_addr or 'unknown_ip'
                user_id, is_authenticated, auth_method = get_user_id()
                fingerprint = get_client_fingerprint()
                
                # Build key based on scope
                if scope == "global":
                    key_parts = ["global"]
                elif scope == "ip":
                    key_parts = ["ip", ip]
                elif scope == "user":
                    key_parts = ["user", user_id]
                else:  # endpoint (default)
                    key_parts = ["endpoint", request.endpoint or fn.__name__]
                
                # Add user/IP based on per_user flag
                if per_user and user_id != 'anonymous':
                    key_parts.append(user_id)
                else:
                    key_parts.append(ip)
                
                # Add fingerprint for additional security
                if strict_mode:
                    key_parts.append(fingerprint)
                
                rate_key = ":".join(key_parts)
            
            # Determine limits based on authentication
            effective_limit = limit
            effective_window = window
            effective_burst = burst_limit
            
            if strict_mode and not is_authenticated:
                # Stricter limits for anonymous users
                effective_limit = max(limit // 3, 5)  # One third, minimum 5
                effective_window = min(window, 30)  # Shorter window
                if burst_limit:
                    effective_burst = max(burst_limit // 2, 10)
            
            # Check rate limit
            result = limiter.is_allowed(
                key=rate_key,
                limit=effective_limit,
                window=effective_window,
                burst_limit=effective_burst,
                cost=cost
            )
            
            if not result['allowed']:
                # Add rate limit headers (RFC 6585)
                headers = {
                    'X-RateLimit-Limit': str(result['limit']),
                    'X-RateLimit-Remaining': str(result['remaining']),
                    'X-RateLimit-Reset': str(result['reset']),
                    'X-RateLimit-Window': str(result['window']),
                    'Retry-After': str(result['reset'] - int(time.time()))
                }
                
                if result.get('burst_violation'):
                    error_msg = "Burst rate limit exceeded. Please slow down."
                else:
                    error_msg = "Rate limit exceeded"
                
                response = jsonify({
                    "error": error_msg,
                    "retry_after": result['reset'] - int(time.time()),
                    "limit": result['limit'],
                    "window": result['window'],
                    "burst_limit": burst_limit,
                    "scope": scope
                }), 429
                
                # Add headers to response
                for key, value in headers.items():
                    response[1].headers[key] = value
                    
                return response
            
            # Add rate limit info to response headers even when successful
            g.rate_limit_info = {
                'limit': result['limit'],
                'remaining': result['remaining'],
                'reset': result['reset'],
                'window': result['window']
            }
            
            return fn(*args, **kwargs)
        
        return wrapper
    return decorator


class RateLimitTier:
    """Define rate limit tiers for different user types"""
    
    TIERS = {
        'anonymous': {'limit': 50, 'window': 60, 'burst': 75},
        'authenticated': {'limit': 200, 'window': 60, 'burst': 300},
        'premium': {'limit': 1000, 'window': 60, 'burst': 1500},
        'enterprise': {'limit': 5000, 'window': 60, 'burst': 7500},
        'admin': {'limit': 10000, 'window': 60, 'burst': 15000},
    }
    
    @classmethod
    def get_tier_limits(cls, tier_name: str) -> Dict[str, Any]:
        """Get rate limits for a specific tier"""
        return cls.TIERS.get(tier_name, cls.TIERS['anonymous'])


def tiered_rate_limit(tier_func: Optional[Callable] = None):
    """
    Tiered rate limiting based on user subscription/role
    
    Args:
        tier_func: Function that returns user's tier based on request
    """
    limiter = RedisRateLimiter()
    
    def decorator(fn):
        @wraps(fn)
        def wrapper(*args, **kwargs):
            # Determine user tier
            if tier_func:
                user_tier = tier_func()
            else:
                # Default: determine tier from user info
                user_id, is_authenticated, auth_method = get_user_id()
                
                if user_id == 'anonymous':
                    user_tier = 'anonymous'
                elif user_id.startswith('admin_'):
                    user_tier = 'admin'
                elif hasattr(g, 'user') and hasattr(g.user, 'subscription_tier'):
                    user_tier = g.user.subscription_tier
                else:
                    user_tier = 'authenticated'
            
            # Get limits for this tier
            limits = RateLimitTier.get_tier_limits(user_tier)
            
            # Generate rate limit key
            ip = request.remote_addr or 'unknown_ip'
            user_id, is_authenticated, _ = get_user_id()
            
            key = f"tier:{user_tier}:{user_id}:{ip}:{request.endpoint}"
            
            # Check rate limit
            result = limiter.is_allowed(
                key=key,
                limit=limits['limit'],
                window=limits['window'],
                burst_limit=limits.get('burst')
            )
            
            if not result['allowed']:
                headers = {
                    'X-RateLimit-Limit': str(result['limit']),
                    'X-RateLimit-Remaining': str(result['remaining']),
                    'X-RateLimit-Reset': str(result['reset']),
                    'X-RateLimit-Tier': user_tier
                }
                
                response = jsonify({
                    "error": "Rate limit exceeded",
                    "tier": user_tier,
                    "limit": result['limit'],
                    "retry_after": result['reset'] - int(time.time())
                }), 429
                
                for key, value in headers.items():
                    response[1].headers[key] = value
                    
                return response
            
            # Store tier info in globals
            g.rate_limit_tier = user_tier
            g.rate_limit_info = {
                'limit': result['limit'],
                'remaining': result['remaining'],
                'reset': result['reset']
            }
            
            return fn(*args, **kwargs)
        
        return wrapper
    return decorator


def sliding_window_log(limit: int, window: int):
    """Alternative: Sliding window log algorithm for more precise limits"""
    limiter = RedisRateLimiter()
    
    def decorator(fn):
        @wraps(fn)
        def wrapper(*args, **kwargs):
            user_id, is_authenticated, _ = get_user_id()
            key = f"sliding:{user_id}:{request.endpoint}"
            
            current_time = time.time()
            window_start = current_time - window
            
            try:
                r = get_redis()
                # Get all requests in current window
                requests = r.zrangebyscore(key, window_start, current_time)
                
                if len(requests) >= limit:
                    # Calculate earliest time we can make a new request
                    oldest = r.zrange(key, 0, 0, withscores=True)
                    reset_time = int(oldest[0][1] + window) if oldest else int(current_time + window)
                    
                    return jsonify({
                        "error": "Sliding window rate limit exceeded",
                        "retry_after": reset_time - int(current_time)
                    }), 429
                
                # Add current request
                r.zadd(key, {str(current_time): current_time})
                r.expire(key, window + 10)
                
                return fn(*args, **kwargs)
                
            except redis.RedisError:
                # Fallback
                return fn(*args, **kwargs)
        
        return wrapper
    return decorator


# Utility function to get current rate limit status
def get_rate_limit_status(key: str) -> Dict[str, Any]:
    """Get current rate limit status for a key"""
    limiter = RedisRateLimiter()
    
    # This would need a separate method in RedisRateLimiter to get status without incrementing
    # For simplicity, returning basic info
    return {
        'key': key,
        'timestamp': time.time()
    }


# Example usage in Flask app
"""
@app.route('/api/sensitive', methods=['GET'])
@rate_limit(limit=30, window=60, burst_limit=50, strict_mode=True, scope="ip")
def sensitive_endpoint():
    return jsonify({"data": "sensitive data"})

@app.route('/api/premium', methods=['GET'])
@tiered_rate_limit()
def premium_endpoint():
    return jsonify({"data": "premium data"})

@app.route('/api/expensive', methods=['POST'])
@rate_limit(limit=10, window=60, cost=5)  # Each request costs 5 points
def expensive_operation():
    return jsonify({"result": "expensive operation completed"})
"""