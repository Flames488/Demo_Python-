"""
Unified routes with global middleware protection.
All routes are protected by default unless explicitly marked as public.
"""

from functools import wraps
from flask import Flask, jsonify, request, g, abort
from flask_jwt_extended import JWTManager, create_access_token, get_jwt
from app.middleware.decorators import public_route, require_tier
from app.middleware.permissions import role_required, permission_required
from app.models.user import User
from app.extensions import db

app = Flask(__name__)

# Configure JWT
app.config["JWT_SECRET_KEY"] = "your-secret-key-change-this"  # Change this!
jwt = JWTManager(app)

# IMPORTANT: Global middleware protects ALL routes by default
# Only routes with @public_route decorator are exempt from auth

# Public login route (explicitly marked as public)
@app.route("/api/login", methods=["POST"])
@public_route
def login():
    """Public login endpoint - exempt from global auth middleware."""
    from flask_jwt_extended import create_access_token
    
    # In real app, verify username/password here
    data = request.get_json()
    username = data.get('username')
    password = data.get('password')
    
    # Mock authentication - replace with real auth logic
    if username == "admin" and password == "password":
        # Get user from database
        user = User.query.filter_by(username=username).first()
        if not user:
            return jsonify({"error": "User not found"}), 401
        
        # Create token with claims
        access_token = create_access_token(
            identity=str(user.id),  # User ID as identity
            additional_claims={
                "role": user.role,
                "email": user.email,
                "subscription_tier": user.subscription_tier
            }
        )
        
        return jsonify({
            "access_token": access_token,
            "user": {
                "id": user.id,
                "username": user.username,
                "role": user.role,
                "subscription_tier": user.subscription_tier
            }
        }), 200
    else:
        return jsonify({"error": "Invalid credentials"}), 401

# Public registration route
@app.route("/api/register", methods=["POST"])
@public_route
def register():
    """Public registration endpoint."""
    data = request.get_json()
    
    # Validate input
    if not data.get('username') or not data.get('email') or not data.get('password'):
        return jsonify({"error": "Missing required fields"}), 400
    
    # Check if user exists
    if User.query.filter_by(email=data['email']).first():
        return jsonify({"error": "Email already registered"}), 400
    
    if User.query.filter_by(username=data['username']).first():
        return jsonify({"error": "Username already taken"}), 400
    
    # Create new user
    user = User(
        username=data['username'],
        email=data['email'],
        role='user',  # Default role
        subscription_tier='free'  # Default tier
    )
    user.set_password(data['password'])
    
    db.session.add(user)
    db.session.commit()
    
    # Create token
    access_token = create_access_token(
        identity=str(user.id),
        additional_claims={
            "role": user.role,
            "email": user.email,
            "subscription_tier": user.subscription_tier
        }
    )
    
    return jsonify({
        "access_token": access_token,
        "user": {
            "id": user.id,
            "username": user.username,
            "email": user.email,
            "role": user.role
        }
    }), 201

# Protected user profile route
# No @jwt_required needed - global middleware handles authentication
# User is already available in g.user
@app.route("/api/user/profile", methods=["GET"])
def get_profile():
    """Protected user profile endpoint.
    Global middleware ensures user is authenticated.
    User object is available in g.user."""
    
    user = g.user  # Set by global middleware
    
    return jsonify({
        "message": "User profile data",
        "user": {
            "id": user.id,
            "username": user.username,
            "email": user.email,
            "role": user.role,
            "subscription_tier": user.subscription_tier,
            "created_at": user.created_at.isoformat() if user.created_at else None
        }
    }), 200

# Protected route with role requirement
@app.route("/api/admin/dashboard", methods=["GET"])
@role_required("admin")  # Additional role check
def admin_dashboard():
    """Admin dashboard - requires admin role."""
    user = g.user
    
    return jsonify({
        "message": "Admin dashboard",
        "stats": {
            "total_users": User.query.count(),
            "active_sessions": 42,  # Example stat
            "system_status": "online"
        }
    }), 200

# Protected route requiring admin role for deletion
@app.route("/api/admin/delete-user/<user_id>", methods=["DELETE"])
@role_required("admin")
@permission_required("user:delete")
def delete_user(user_id):
    """Delete user - requires admin role AND delete permission."""
    
    # User to delete
    target_user = User.query.get(user_id)
    if not target_user:
        return jsonify({"error": "User not found"}), 404
    
    # Prevent self-deletion
    if target_user.id == g.user.id:
        return jsonify({"error": "Cannot delete yourself"}), 400
    
    # Delete user
    db.session.delete(target_user)
    db.session.commit()
    
    return jsonify({
        "message": f"User {user_id} deleted successfully",
        "deleted_by": g.user.id
    }), 200

# Premium feature requiring subscription tier
@app.route("/api/premium/feature", methods=["GET"])
@require_tier('premium')  # Requires premium subscription or higher
def premium_feature():
    """Premium feature - requires premium subscription tier."""
    
    return jsonify({
        "message": "Premium feature accessed",
        "feature": "advanced_analytics",
        "user_tier": g.user.subscription_tier
    }), 200

# Pro feature requiring pro tier
@app.route("/api/pro/feature", methods=["GET"])
@require_tier('pro')
def pro_feature():
    """Pro feature - requires pro subscription tier."""
    
    return jsonify({
        "message": "Pro feature accessed",
        "feature": "advanced_export",
        "user_tier": g.user.subscription_tier
    }), 200

# Public health check
@app.route("/health", methods=["GET"])
@public_route
def health():
    """Public health check endpoint."""
    return jsonify({"status": "healthy"}), 200

# User settings update (requires authentication)
@app.route("/api/user/settings", methods=["PUT"])
def update_settings():
    """Update user settings - automatically protected by global middleware."""
    data = request.get_json()
    user = g.user
    
    # Update allowed fields
    allowed_fields = ['email_notifications', 'theme', 'language']
    for field in allowed_fields:
        if field in data:
            setattr(user, field, data[field])
    
    db.session.commit()
    
    return jsonify({
        "message": "Settings updated",
        "settings": {field: getattr(user, field) for field in allowed_fields}
    }), 200

# API key management (requires authentication)
@app.route("/api/user/api-keys", methods=["GET"])
def list_api_keys():
    """List user API keys."""
    user = g.user
    
    # Get API keys from database
    from app.models.api_key import APIKey
    api_keys = APIKey.query.filter_by(user_id=user.id, is_active=True).all()
    
    return jsonify({
        "api_keys": [
            {
                "id": key.id,
                "name": key.name,
                "created_at": key.created_at.isoformat(),
                "last_used": key.last_used_at.isoformat() if key.last_used_at else None
            }
            for key in api_keys
        ]
    }), 200

# Create API key (requires authentication)
@app.route("/api/user/api-keys", methods=["POST"])
@require_tier('basic')  # Requires at least basic tier
def create_api_key():
    """Create new API key."""
    data = request.get_json()
    name = data.get('name', 'Default API Key')
    
    user = g.user
    
    # Generate API key
    import secrets
    api_key_value = secrets.token_urlsafe(32)
    
    from app.models.api_key import APIKey
    api_key = APIKey(
        user_id=user.id,
        name=name,
        key=api_key_value,
        is_active=True
    )
    
    db.session.add(api_key)
    db.session.commit()
    
    return jsonify({
        "message": "API key created",
        "api_key": api_key_value,  # Only returned once!
        "key_info": {
            "id": api_key.id,
            "name": api_key.name,
            "created_at": api_key.created_at.isoformat()
        }
    }), 201

# Webhook endpoint (public but with signature verification)
@app.route("/webhooks/stripe", methods=["POST"])
@public_route  # Public but has its own signature verification
def stripe_webhook():
    """Stripe webhook endpoint - public but verifies signature."""
    from app.webhook import verify_stripe_webhook
    
    # Verify webhook signature
    if not verify_stripe_webhook(request):
        return jsonify({"error": "Invalid signature"}), 401
    
    # Process webhook
    payload = request.get_json()
    event_type = payload.get('type')
    
    # Handle different event types
    if event_type == 'invoice.payment_succeeded':
        # Update user subscription
        customer_id = payload['data']['object']['customer']
        # ... process payment success
        pass
    elif event_type == 'customer.subscription.deleted':
        # Handle subscription cancellation
        pass
    
    return jsonify({"received": True}), 200

# Public API documentation
@app.route("/api/docs", methods=["GET"])
@public_route
def api_docs():
    """Public API documentation."""
    return jsonify({
        "version": "1.0.0",
        "endpoints": {
            "/api/login": "POST - Authenticate user",
            "/api/register": "POST - Register new user",
            "/api/user/profile": "GET - Get user profile (requires auth)",
            "/api/user/settings": "PUT - Update user settings (requires auth)",
            "/api/admin/*": "Admin endpoints (requires admin role)",
            "/api/premium/*": "Premium features (requires premium subscription)",
            "/health": "GET - Health check"
        }
    }), 200

if __name__ == "__main__":
    app.run(debug=True)