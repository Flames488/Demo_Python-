from functools import wraps
from flask import request, jsonify, abort, g
import logging

from flask_jwt_extended import verify_jwt_in_request, get_jwt
from app.models import User
from app.extensions import db

logger = logging.getLogger(__name__)

# Shared authentication logic
def authenticate_request():
    """
    Shared authentication logic used by both middleware and decorators
    """
    token = request.headers.get("Authorization")
    
    if not token:
        return None, jsonify({"error": "Unauthorized"}), 401
    
    # Try JWT first
    try:
        verify_jwt_in_request()
        claims = get_jwt()
        user_id = claims.get('sub')
        user = User.query.get(user_id) if user_id else None
        if user:
            g.user = user
            logger.info(f"JWT Auth successful for user: {user_id}")
            return user, None, None
    except:
        pass
    
    # Try legacy token
    user = User.verify_token(token)
    if user:
        g.user = user
        return user, None, None
    
    return None, jsonify({"error": "Invalid token"}), 401


def auth_middleware():
    """
    Flask middleware using shared authentication logic
    """
    user, error_response, status_code = authenticate_request()
    if error_response:
        return error_response, status_code


def auth_required():
    """
    Decorator using shared authentication logic
    """
    def decorator(fn):
        @wraps(fn)
        def wrapper(*args, **kwargs):
            user, error_response, status_code = authenticate_request()
            if error_response:
                return error_response, status_code
            return fn(*args, **kwargs)
        return wrapper
    return decorator