# backend/app/middleware/request_logger.py
"""
Request logging middleware for consistent logging across all requests.
Handles correlation IDs, request timing, and structured logging.
"""
import time
import uuid
import logging
from typing import Dict, Any, Optional, Callable
from functools import wraps

from flask import request, g, current_app, has_request_context
from flask_jwt_extended import get_jwt_identity, get_jwt

logger = logging.getLogger(__name__)


class RequestLogger:
    """Middleware for request logging with correlation IDs and timing."""
    
    @staticmethod
    def generate_request_id() -> str:
        """Generate a unique request ID."""
        return str(uuid.uuid4())
    
    @staticmethod
    def get_correlation_id() -> Optional[str]:
        """Extract correlation ID from request headers."""
        if not has_request_context():
            return None
        
        # Try various headers in order of preference
        headers = request.headers if request else None
        if not headers:
            return None
        
        return (
            headers.get('X-Correlation-ID') or
            headers.get('X-Request-ID') or
            headers.get('Request-ID') or
            headers.get('Correlation-ID')
        )
    
    @staticmethod
    def get_user_info() -> Dict[str, Any]:
        """Extract user information from JWT if available."""
        user_info = {}
        
        try:
            # Try to get JWT identity
            user_id = get_jwt_identity()
            if user_id:
                user_info['user_id'] = user_id
            
            # Try to get additional claims
            claims = get_jwt()
            if claims:
                if 'sub' in claims and claims['sub'] != user_id:
                    user_info['subject'] = claims['sub']
                if 'role' in claims:
                    user_info['role'] = claims['role']
                if 'email' in claims:
                    user_info['email'] = claims['email']
                    
        except Exception:
            # JWT not available or invalid - that's OK
            pass
        
        return user_info
    
    @staticmethod
    def get_request_info() -> Dict[str, Any]:
        """Extract request information."""
        if not has_request_context():
            return {}
        
        info = {
            'method': request.method,
            'path': request.path,
            'endpoint': request.endpoint,
            'remote_addr': request.remote_addr,
            'user_agent': request.user_agent.string if request.user_agent else None,
            'content_type': request.content_type,
            'content_length': request.content_length,
        }
        
        # Add query parameters (sanitized)
        if request.args:
            info['query_params'] = dict(request.args)
        
        return info
    
    @staticmethod
    def setup_request_context():
        """Setup request context with correlation ID and timing."""
        if not has_request_context():
            return
        
        # Generate or get correlation ID
        correlation_id = RequestLogger.get_correlation_id() or RequestLogger.generate_request_id()
        request_id = RequestLogger.generate_request_id()
        
        # Store in context
        g.correlation_id = correlation_id
        g.request_id = request_id
        g.request_start_time = time.time()
        
        # Add to request environment for other services
        request.environ['CORRELATION_ID'] = correlation_id
        request.environ['REQUEST_ID'] = request_id
        
        # Get user info
        user_info = RequestLogger.get_user_info()
        if user_info:
            g.user_info = user_info
    
    @staticmethod
    def log_request_start():
        """Log the start of a request."""
        if not has_request_context():
            return
        
        log_data = {
            'event': 'request_start',
            'correlation_id': getattr(g, 'correlation_id', None),
            'request_id': getattr(g, 'request_id', None),
            'method': request.method,
            'path': request.path,
            'remote_addr': request.remote_addr,
        }
        
        # Add user info if available
        if hasattr(g, 'user_info') and 'user_id' in g.user_info:
            log_data['user_id'] = g.user_info['user_id']
        
        logger.info("Request started", extra=log_data)
    
    @staticmethod
    def log_request_complete(response=None, error=None):
        """Log the completion of a request."""
        if not has_request_context():
            return
        
        # Calculate latency
        start_time = getattr(g, 'request_start_time', None)
        latency_ms = None
        if start_time:
            latency_ms = round((time.time() - start_time) * 1000, 2)
        
        # Prepare log data
        log_data = {
            'event': 'request_complete',
            'correlation_id': getattr(g, 'correlation_id', None),
            'request_id': getattr(g, 'request_id', None),
            'method': request.method,
            'path': request.path,
            'status_code': getattr(response, 'status_code', None) if response else None,
            'latency_ms': latency_ms,
            'remote_addr': request.remote_addr,
            'user_agent': request.user_agent.string if request.user_agent else None,
        }
        
        # Add user info if available
        if hasattr(g, 'user_info'):
            if 'user_id' in g.user_info:
                log_data['user_id'] = g.user_info['user_id']
            if 'role' in g.user_info:
                log_data['user_role'] = g.user_info['role']
        
        # Add error info if present
        if error:
            log_data['error'] = str(error)
            log_data['error_type'] = type(error).__name__
        
        # Determine log level
        status_code = log_data.get('status_code')
        if status_code:
            if status_code >= 500:
                log_level = 'error'
            elif status_code >= 400:
                log_level = 'warning'
            else:
                log_level = 'info'
        elif error:
            log_level = 'error'
        else:
            log_level = 'info'
        
        # Log the message
        getattr(logger, log_level)(f"Request completed", extra=log_data)
        
        return response
    
    @staticmethod
    def add_response_headers(response):
        """Add correlation ID headers to response."""
        if not has_request_context():
            return response
        
        correlation_id = getattr(g, 'correlation_id', None)
        request_id = getattr(g, 'request_id', None)
        
        if correlation_id and hasattr(response, 'headers'):
            response.headers['X-Correlation-ID'] = correlation_id
        
        if request_id and hasattr(response, 'headers'):
            response.headers['X-Request-ID'] = request_id
        
        return response
    
    @staticmethod
    def middleware(app):
        """Register middleware with Flask app."""
        
        @app.before_request
        def before_request():
            """Setup request context before each request."""
            RequestLogger.setup_request_context()
            RequestLogger.log_request_start()
        
        @app.after_request
        def after_request(response):
            """Process response and log completion."""
            try:
                RequestLogger.log_request_complete(response)
                response = RequestLogger.add_response_headers(response)
            except Exception as e:
                logger.error(f"Error in after_request middleware: {str(e)}")
            return response
        
        @app.teardown_request
        def teardown_request(exception=None):
            """Handle request teardown (for error cases)."""
            if exception:
                RequestLogger.log_request_complete(error=exception)
        
        logger.info("Request logging middleware registered")
        return app
    
    @staticmethod
    def decorator(fn: Optional[Callable] = None):
        """Decorator version for individual routes."""
        def decorator_func(f):
            @wraps(f)
            def decorated_function(*args, **kwargs):
                # Setup context if not already done
                if not hasattr(g, 'correlation_id'):
                    RequestLogger.setup_request_context()
                    RequestLogger.log_request_start()
                
                try:
                    response = f(*args, **kwargs)
                    RequestLogger.add_response_headers(response)
                    return response
                except Exception as e:
                    RequestLogger.log_request_complete(error=e)
                    raise
            
            return decorated_function
        
        if fn:
            return decorator_func(fn)
        return decorator_func


# Convenience decorator
request_logger = RequestLogger.decorator