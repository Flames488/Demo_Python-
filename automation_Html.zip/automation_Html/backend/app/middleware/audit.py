import uuid
import logging
from fastapi import Request

logger = logging.getLogger("audit")

async def audit_log_middleware(request: Request, call_next):
    request_id = str(uuid.uuid4())
    request.state.request_id = request_id

    response = await call_next(request)

    logger.info(
        "request",
        extra={
            "request_id": request_id,
            "path": request.url.path,
            "method": request.method,
            "status": response.status_code,
            "client": request.client.host if request.client else None,
        }
    )
    return response
