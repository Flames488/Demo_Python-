# File: app/middleware/__init__.py
"""
Unified middleware system for global protection.
All routes are protected unless explicitly whitelisted.
"""

import re
from typing import Set, Callable, Optional, Tuple
from functools import wraps
from flask import request, g, jsonify, current_app, abort
from flask_jwt_extended import verify_jwt_in_request, get_jwt_identity, get_jwt


class GlobalMiddlewareManager:
    """Centralized middleware management with strict defaults."""
    
    def __init__(self, app=None):
        self.app = app
        self._exempt_routes: Set[str] = set()
        self._exempt_patterns = []
        self._rate_limit_config = {}
        self._subscription_checks = {}
        
        if app:
            self.init_app(app)
    
    def init_app(self, app):
        """Initialize middleware with the Flask app."""
        self.app = app
        
        # Register all middleware in correct order
        self._register_request_tracking(app)
        self._register_auth_middleware(app)
        self._register_rate_limiting(app)
        self._register_subscription_middleware(app)
        self._register_permission_middleware(app)
        
        app.logger.info("Global middleware system initialized")
    
    def exempt(self, path: str, methods: Optional[Set[str]] = None):
        """Explicitly exempt a route from middleware."""
        self._exempt_routes.add((path, frozenset(methods) if methods else None))
    
    def exempt_pattern(self, pattern: str):
        """Exempt routes matching a regex pattern."""
        self._exempt_patterns.append(re.compile(pattern))
    
    def is_exempt(self, path: str, method: str) -> bool:
        """Check if a route is exempt from middleware."""
        # Check exact matches
        if (path, None) in self._exempt_routes:
            return True
        if (path, frozenset([method])) in self._exempt_routes:
            return True
        
        # Check pattern matches
        for pattern in self._exempt_patterns:
            if pattern.match(path):
                return True
        
        return False
    
    def _register_request_tracking(self, app):
        """Register request ID and logging middleware."""
        
        @app.before_request
        def track_request():
            """Add request ID and start timing."""
            g.request_start = time.time()
            g.request_id = request.headers.get('X-Request-ID') or str(uuid.uuid4())
            g.request_method = request.method
            g.request_path = request.path
            
            # Add to response headers later
            request.environ['REQUEST_ID'] = g.request_id
            
            app.logger.info(f"Request started: {request.method} {request.path}")
    
    def _register_auth_middleware(self, app):
        """Global authentication middleware - protects ALL routes by default."""
        
        @app.before_request
        def enforce_global_auth():
            """Enforce authentication on all routes unless exempt."""
            
            # Skip OPTIONS preflight requests
            if request.method == 'OPTIONS':
                return
            
            # Check if route is exempt
            if self.is_exempt(request.path, request.method):
                return
            
            # Check if webhook (handled separately)
            if request.path.startswith('/webhooks/'):
                # Webhooks use signature verification instead of JWT
                if not self._verify_webhook_signature(request):
                    abort(401, "Invalid webhook signature")
                return
            
            # Try multiple authentication methods in order
            user = None
            
            # 1. JWT Bearer token (primary)
            auth_header = request.headers.get('Authorization', '')
            if auth_header.startswith('Bearer '):
                token = auth_header[7:]
                user = self._validate_jwt_and_get_user(token)
            
            # 2. API Key (secondary)
            if not user:
                api_key = request.headers.get('X-API-Key')
                if api_key:
                    user = self._validate_api_key_and_get_user(api_key)
            
            # 3. Session cookie (tertiary)
            if not user and request.cookies.get('session'):
                user = self._validate_session_and_get_user(request.cookies.get('session'))
            
            # If no valid authentication found
            if not user:
                app.logger.warning(
                    f"Authentication failed for {request.method} {request.path}",
                    extra={
                        'ip': request.remote_addr,
                        'user_agent': request.user_agent.string[:200] if request.user_agent else None
                    }
                )
                
                abort(401, jsonify({
                    'error': 'authentication_required',
                    'message': 'Valid authentication is required',
                    'docs': 'https://docs.example.com/authentication'
                }))
            
            # Store authenticated user in request context
            g.user = user
            g.auth_method = getattr(user, '_auth_method', 'unknown')
            
            # Also set on request for compatibility
            try:
                request.user = user
            except:
                pass  # Some Flask versions don't allow this
    
    def _register_rate_limiting(self, app):
        """Global rate limiting middleware."""
        
        @app.before_request
        def apply_rate_limits():
            """Apply rate limits based on user tier and endpoint."""
            if self.is_exempt(request.path, request.method):
                return
            
            # Get rate limit key
            user_id = getattr(g, 'user', None)
            if user_id and hasattr(user_id, 'id'):
                key = f"rl:user:{user_id.id}:{request.path}"
                tier = getattr(user_id, 'subscription_tier', 'free')
            else:
                key = f"rl:ip:{request.remote_addr}:{request.path}"
                tier = 'anonymous'
            
            # Get limits based on tier
            limits = self._get_rate_limits_for_tier(tier, request.path)
            
            # Check rate limit
            if not self._rate_limiter.check(key, limits):
                abort(429, jsonify({
                    'error': 'rate_limit_exceeded',
                    'message': f'Rate limit exceeded for {tier} tier',
                    'retry_after': self._rate_limiter.get_retry_after(key),
                    'limits': limits
                }))
    
    def _register_subscription_middleware(self, app):
        """Global subscription checking middleware."""
        
        @app.before_request
        def check_subscription():
            """Check subscription for premium features."""
            if self.is_exempt(request.path, request.method):
                return
            
            # Skip for admin users
            user = getattr(g, 'user', None)
            if not user:
                return
            
            if hasattr(user, 'is_admin') and user.is_admin:
                return
            
            # Check if route requires specific subscription
            required_tier = self._get_required_tier_for_route(request.path, request.method)
            if required_tier:
                user_tier = getattr(user, 'subscription_tier', 'free')
                
                # Check tier hierarchy
                tier_levels = {'free': 0, 'basic': 1, 'pro': 2, 'premium': 3, 'enterprise': 4}
                
                if tier_levels.get(user_tier, 0) < tier_levels.get(required_tier, 0):
                    abort(403, jsonify({
                        'error': 'subscription_required',
                        'message': f'{required_tier} subscription required',
                        'required_tier': required_tier,
                        'current_tier': user_tier,
                        'upgrade_url': 'https://app.example.com/upgrade'
                    }))
    
    def _register_permission_middleware(self, app):
        """Global permission checking middleware."""
        
        @app.before_request
        def check_permissions():
            """Check user permissions for the requested action."""
            if self.is_exempt(request.path, request.method):
                return
            
            user = getattr(g, 'user', None)
            if not user:
                return
            
            # Get required permission for this route
            required_permission = self._get_required_permission(
                request.path, 
                request.method
            )
            
            if required_permission and not self._check_user_permission(user, required_permission):
                abort(403, jsonify({
                    'error': 'insufficient_permissions',
                    'message': f'Permission denied: {required_permission}',
                    'required': required_permission,
                    'user_permissions': getattr(user, 'permissions', [])
                }))
    
    def _validate_jwt_and_get_user(self, token):
        """Validate JWT token and return user object."""
        try:
            from app.utils.jwt import decode_token
            payload = decode_token(token)
            user_id = payload.get('sub')
            
            if not user_id:
                return None
            
            # Get user from database
            from app.models.user import User
            user = User.query.get(user_id)
            
            if user and getattr(user, 'is_active', True):
                user._auth_method = 'jwt'
                return user
                
        except Exception as e:
            current_app.logger.debug(f"JWT validation failed: {e}")
        
        return None
    
    def _validate_api_key_and_get_user(self, api_key):
        """Validate API key and return user."""
        try:
            from app.models.api_key import APIKey
            key_record = APIKey.query.filter_by(
                key=api_key,
                is_active=True
            ).first()
            
            if key_record and not key_record.is_expired():
                user = key_record.user
                if user and getattr(user, 'is_active', True):
                    user._auth_method = 'api_key'
                    return user
                    
        except Exception as e:
            current_app.logger.debug(f"API key validation failed: {e}")
        
        return None
    
    def _verify_webhook_signature(self, request):
        """Verify webhook signature."""
        # Implementation depends on your webhook provider
        # Example for Stripe:
        try:
            from app.webhooks.stripe import verify_signature
            return verify_signature(request)
        except:
            return False
    
    def _get_rate_limits_for_tier(self, tier, endpoint):
        """Get rate limits for user tier and endpoint."""
        # Default limits
        defaults = {
            'anonymous': {'requests': 10, 'window': 60},
            'free': {'requests': 100, 'window': 60},
            'basic': {'requests': 1000, 'window': 60},
            'pro': {'requests': 5000, 'window': 60},
            'premium': {'requests': 20000, 'window': 60},
            'enterprise': {'requests': 100000, 'window': 60},
            'admin': {'requests': 1000000, 'window': 60}
        }
        
        return defaults.get(tier, defaults['anonymous'])
    
    def _get_required_tier_for_route(self, path, method):
        """Determine required subscription tier for route."""
        # Define tier requirements
        tier_requirements = {
            ('/api/premium', 'GET'): 'premium',
            ('/api/pro', 'POST'): 'pro',
            ('/api/enterprise', 'PUT'): 'enterprise',
            # Add more as needed
        }
        
        return tier_requirements.get((path, method))
    
    def _get_required_permission(self, path, method):
        """Determine required permission for route."""
        # Map routes to permissions
        permission_map = {
            ('/api/admin', 'GET'): 'admin:read',
            ('/api/admin', 'POST'): 'admin:write',
            ('/api/users', 'DELETE'): 'user:delete',
            # Add more as needed
        }
        
        return permission_map.get((path, method))
    
    def _check_user_permission(self, user, permission):
        """Check if user has specific permission."""
        user_permissions = getattr(user, 'permissions', [])
        user_role = getattr(user, 'role', 'user')
        
        # Role-based permission checking
        role_permissions = {
            'admin': ['admin:read', 'admin:write', 'user:read', 'user:write', 'user:delete'],
            'user': ['user:read', 'user:write'],
            'guest': ['user:read']
        }
        
        # Check direct permissions first
        if permission in user_permissions:
            return True
        
        # Check role-based permissions
        role_perm_list = role_permissions.get(user_role, [])
        if permission in role_perm_list:
            return True
        
        return False


# Initialize global middleware
middleware_manager = GlobalMiddlewareManager()


def init_middleware(app):
    """Initialize middleware with default exemptions."""
    
    # Initialize the manager
    middleware_manager.init_app(app)
    
    # Define exempt routes (public endpoints)
    middleware_manager.exempt('/health')
    middleware_manager.exempt('/api/health')
    middleware_manager.exempt('/metrics')
    middleware_manager.exempt('/docs')
    middleware_manager.exempt('/swagger')
    middleware_manager.exempt('/favicon.ico')
    
    # Public auth endpoints
    middleware_manager.exempt('/api/auth/login')
    middleware_manager.exempt('/api/auth/register')
    middleware_manager.exempt('/api/auth/refresh')
    middleware_manager.exempt('/api/auth/forgot-password')
    middleware_manager.exempt('/api/auth/reset-password')
    
    # Webhook endpoints (handled separately)
    middleware_manager.exempt_pattern(r'^/webhooks/.*')
    
    # Static files
    middleware_manager.exempt_pattern(r'^/static/.*')
    middleware_manager.exempt_pattern(r'^/assets/.*')
    
    return middleware_manager