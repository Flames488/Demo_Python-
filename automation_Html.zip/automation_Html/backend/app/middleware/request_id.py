"""
Request ID middleware for tracing
"""
import uuid
from flask import request, g
import logging

class RequestIDMiddleware:
    def __init__(self, app):
        self.app = app
        self.app.before_request(self._add_request_id)
        
    def _add_request_id(self):
        """Add a unique request ID to each request"""
        request_id = request.headers.get('X-Request-ID') or str(uuid.uuid4())
        g.request_id = request_id
        request.request_id = request_id
        
        # Add request ID to logger
        logger = logging.getLogger(__name__)
        logger = logging.LoggerAdapter(logger, {'request_id': request_id})