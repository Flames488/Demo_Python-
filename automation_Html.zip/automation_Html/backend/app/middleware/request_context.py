import uuid
from flask import g, request

def request_context():
    g.request_id = request.headers.get("X-Request-ID", str(uuid.uuid4()))
