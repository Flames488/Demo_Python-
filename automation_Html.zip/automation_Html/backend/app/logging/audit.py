import json, uuid, datetime

def audit_log(req, resp):
    record = {
        "id": str(uuid.uuid4()),
        "path": req.path,
        "method": req.method,
        "status": resp.status_code,
        "time": datetime.datetime.utcnow().isoformat()
    }
    with open("audit.log", "a") as f:
        f.write(json.dumps(record) + "\n")