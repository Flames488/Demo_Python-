from .dev import DevConfig

class TestConfig(DevConfig):
    """Testing configuration."""
    
    DEBUG = True
    ENV = 'testing'
    TESTING = True
    LOG_LEVEL = 'WARNING'  # Less verbose in tests
    
    # Testing overrides
    SQLALCHEMY_DATABASE_URI = 'sqlite:///:memory:'
    SQLALCHEMY_ECHO = False
    SESSION_COOKIE_SECURE = False
    PREFERRED_URL_SCHEME = 'http'
    
    # Test-specific settings
    WTF_CSRF_ENABLED = False
    
    @classmethod
    def validate(cls):
        """Testing validation - minimal checks."""
        print("✅ Testing configuration validated")