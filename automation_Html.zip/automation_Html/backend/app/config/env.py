# config/env.py
import os
import sys
from typing import Optional, Any
from pathlib import Path

# Load .env file
BASE_DIR = Path(__file__).resolve().parent.parent
env_path = BASE_DIR / '.env'

if env_path.exists():
    from dotenv import load_dotenv
    load_dotenv(env_path)
    print(f"✅ Loaded environment from {env_path}")
elif os.environ.get('FLASK_ENV') == 'production':
    print(f"ℹ️  Running in production, expecting environment variables")
else:
    print(f"⚠️  Warning: .env file not found at {env_path}")

def get_env(
    key: str, 
    default: Optional[str] = None, 
    required: bool = False,
    min_length: Optional[int] = None,
    allowed_values: Optional[list] = None
) -> str:
    """
    Get environment variable with validation.
    
    Args:
        key: Environment variable name
        default: Default value if not set
        required: If True, raise error when not set
        min_length: Minimum length requirement
        allowed_values: List of allowed values
    
    Returns:
        Environment variable value
    
    Raises:
        RuntimeError: If validation fails
    """
    value = os.environ.get(key)
    
    if value is None:
        if required:
            raise RuntimeError(
                f"❌ Environment variable '{key}' is required but not set.\n"
                f"   Please add it to your .env file or environment variables."
            )
        elif default is not None:
            return default
        else:
            return ""
    
    value = value.strip()
    
    # Validations
    if required and not value:
        raise RuntimeError(
            f"❌ Environment variable '{key}' is set but empty.\n"
            f"   Please provide a valid value."
        )
    
    if min_length and len(value) < min_length:
        raise RuntimeError(
            f"❌ Environment variable '{key}' must be at least {min_length} characters.\n"
            f"   Current length: {len(value)}"
        )
    
    if allowed_values and value not in allowed_values:
        raise RuntimeError(
            f"❌ Environment variable '{key}' must be one of: {allowed_values}\n"
            f"   Got: {value}"
        )
    
    return value


def get_bool_env(key: str, default: bool = False) -> bool:
    """Get boolean environment variable."""
    value = os.environ.get(key, str(default)).lower()
    return value in ('true', '1', 'yes', 'y', 't')


def get_int_env(key: str, default: int = 0) -> int:
    """Get integer environment variable."""
    try:
        return int(os.environ.get(key, str(default)))
    except ValueError:
        raise RuntimeError(f"Environment variable '{key}' must be an integer")