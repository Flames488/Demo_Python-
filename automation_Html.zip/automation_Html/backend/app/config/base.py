# Core settings base configuration
from .env import get_env, get_bool_env

class BaseConfig:
    """Base configuration that all configs inherit from."""
    
    # Core settings
    SECRET_KEY = get_env('SECRET_KEY', required=True, min_length=50)
    FLASK_ENV = get_env('FLASK_ENV', 'development', 
                       allowed_values=['development', 'production', 'testing'])
    FLASK_DEBUG = get_bool_env('FLASK_DEBUG', False)

    # Database
    SQLALCHEMY_DATABASE_URI = get_env('DATABASE_URL', required=True)
    SQLALCHEMY_TRACK_MODIFICATIONS = False
    SQLALCHEMY_ENGINE_OPTIONS = {
        'pool_recycle': 300,
        'pool_pre_ping': True,
    }

    class BaseConfig:
    SECRET_KEY: str
    DATABASE_URL: str


    # Redis
    REDIS_URL = get_env('REDIS_URL', 'redis://redis:6379/0')

    # Security headers (common)
    SESSION_COOKIE_HTTPONLY = True
    SESSION_COOKIE_SAMESITE = 'Lax'
    PREFERRED_URL_SCHEME = 'https'

    # Logging
    LOG_LEVEL = get_env('LOG_LEVEL', 'INFO').upper()

    @classmethod
    def validate(cls):
        """Validate configuration - must be implemented by subclasses."""
        raise NotImplementedError("Subclasses must implement validate()")

    @classmethod
    def init_app(cls, app):
        """Initialize app with this config."""
        app.config.from_object(cls)
        cls.validate()