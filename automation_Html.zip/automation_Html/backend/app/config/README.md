# Configuration Guide

## Quick Start
1. Copy `.env.example` to `.env`
2. Fill in ALL required values (no empty values)
3. Generate a secret key:
   ```bash
   python -c "import secrets; print('SECRET_KEY=' + secrets.token_urlsafe(64))"