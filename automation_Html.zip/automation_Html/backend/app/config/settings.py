# Fixed imports for pydantic v2
from pydantic_settings import BaseSettings
from pydantic import AnyUrl, field_validator, HttpUrl
from typing import List, Optional, Union
import secrets


class Settings(BaseSettings):
    # === Core App ===
    APP_NAME: str = "Application"
    ENVIRONMENT: str = "production"  # production | staging | development
    DEBUG: bool = False
    API_VERSION: str = "1.0"
    
    # === Server ===
    HOST: str = "0.0.0.0"
    PORT: int = 5000
    
    # === Security ===
    SECRET_KEY: str
    ACCESS_TOKEN_EXPIRE_MINUTES: int = 15
    REFRESH_TOKEN_EXPIRE_DAYS: int = 7
    REQUIRE_HTTPS: bool = True
    
    # === CORS ===
    CORS_ALLOWED_ORIGINS: List[AnyUrl] = []  # Changed from AnyHttpUrl to AnyUrl
    CORS_SUPPORTS_CREDENTIALS: bool = True
    CORS_ALLOW_METHODS: List[str] = ["GET", "POST", "PUT", "DELETE", "OPTIONS", "PATCH"]
    CORS_ALLOW_HEADERS: List[str] = ["*"]
    CORS_EXPOSE_HEADERS: List[str] = []
    CORS_MAX_AGE: int = 600
    
    # === Database ===
    DATABASE_URL: str
    SQLALCHEMY_DATABASE_URI: str = ""
    SQLALCHEMY_TRACK_MODIFICATIONS: bool = False
    CREATE_TABLES_ON_START: bool = False
    
    # === Rate Limiting ===
    RATE_LIMIT: str = "200/hour"
    
    # === Logging ===
    LOG_LEVEL: str = "INFO"
    LOG_FORMAT: str = "json"
    
    @field_validator("SECRET_KEY")
    @classmethod
    def validate_secret_strength(cls, v):
        if len(v) < 32:
            raise ValueError("SECRET_KEY must be at least 32 characters long")
        return v
    
    @field_validator("ENVIRONMENT")
    @classmethod
    def validate_environment(cls, v):
        allowed = {"production", "staging", "development"}
        if v not in allowed:
            raise ValueError(f"ENVIRONMENT must be one of {allowed}")
        return v
    
    @field_validator("CORS_ALLOWED_ORIGINS", mode="before")
    @classmethod
    def parse_cors_origins(cls, v):
        if isinstance(v, str):
            if v == "*":
                return ["*"]
            return [origin.strip() for origin in v.split(",") if origin.strip()]
        return v
    
    @field_validator("SQLALCHEMY_DATABASE_URI", mode="before")
    @classmethod
    def set_sqlalchemy_database_uri(cls, v, info):
        if not v and "DATABASE_URL" in info.data:
            # Convert DATABASE_URL to SQLALCHEMY_DATABASE_URI if not set
            db_url = info.data.get("DATABASE_URL", "")
            if db_url.startswith("postgres://"):
                # SQLAlchemy requires postgresql:// not postgres://
                db_url = db_url.replace("postgres://", "postgresql://", 1)
            return db_url
        return v
    
    @field_validator("CREATE_TABLES_ON_START")
    @classmethod
    def set_create_tables(cls, v, info):
        # Only create tables automatically in development
        if "ENVIRONMENT" in info.data and info.data["ENVIRONMENT"] == "development":
            return True
        return v
    
    class Config:
        env_file = ".env"
        case_sensitive = True

# Add these classes at the end of settings.py, after the Settings class

class Config(Settings):
    """Base configuration"""
    pass

class DevConfig(Config):
    """Development configuration"""
    ENVIRONMENT: str = "development"
    DEBUG: bool = True
    CREATE_TABLES_ON_START: bool = True
    LOG_LEVEL: str = "DEBUG"
    
class ProdConfig(Config):
    """Production configuration"""
    ENVIRONMENT: str = "production"
    DEBUG: bool = False
    REQUIRE_HTTPS: bool = True
    LOG_LEVEL: str = "WARNING"
    
class TestConfig(Config):
    """Testing configuration"""
    ENVIRONMENT: str = "testing"
    DEBUG: bool = True
    TESTING: bool = True
    SQLALCHEMY_DATABASE_URI: str = "sqlite:///:memory:"
    CREATE_TABLES_ON_START: bool = True
    
settings = Settings()