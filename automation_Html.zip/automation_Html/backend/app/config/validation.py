# config/validation.py
import os
import re
from urllib.parse import urlparse
from .env import get_env

def validate_config():
    """Validate all configuration on startup."""
    errors = []
    
    # Secret key validation
    secret_key = get_env('SECRET_KEY', '')
    if len(secret_key) < 50:
        errors.append("SECRET_KEY must be at least 50 characters")
    
    # Database URL validation
    db_url = get_env('DATABASE_URL', '')
    if not db_url.startswith(('postgresql://', 'postgres://')):
        errors.append("DATABASE_URL must start with postgresql:// or postgres://")
    
    # Stripe key format (starts with sk_live_ or sk_test_)
    stripe_key = get_env('STRIPE_SECRET_KEY', '')
    if stripe_key and not stripe_key.startswith(('sk_live_', 'sk_test_', 'rk_live_', 'rk_test_')):
        errors.append("STRIPE_SECRET_KEY must start with sk_live_, sk_test_, rk_live_, or rk_test_")
    
    # Environment validation
    env = get_env('FLASK_ENV', 'development')
    if env not in ['development', 'production', 'testing']:
        errors.append(f"FLASK_ENV must be 'development', 'production', or 'testing', got: {env}")
    
    # In production, require stricter settings
    if env == 'production':
        if get_env('FLASK_DEBUG', '0') == '1':
            errors.append("FLASK_DEBUG must be 0 in production")
        
        if not get_env('ALLOWED_HOSTS', ''):
            errors.append("ALLOWED_HOSTS must be set in production")
    
    if errors:
        error_msg = "Configuration validation failed:\n" + "\n".join(f"  • {e}" for e in errors)
        raise RuntimeError(error_msg)
    
    print(f"✅ Configuration validated for {env} environment")

def check_secrets_not_committed():
    """Check if secret files might have been committed."""
    secret_files = ['.env', 'secrets.json', 'config/prod.key']
    for file in secret_files:
        if os.path.exists(file):
            print(f"⚠️  Found {file}. Ensure it's in .gitignore")