# config/__init__.py
import os

# Import all config classes from settings.py
from .settings import Config, DevConfig, ProdConfig, TestConfig, settings

# Factory function to get config
def get_config(config_name=None):
    """
    Get configuration class based on environment.
    
    Usage in app.py:
        app.config.from_object(config.get_config())
    """
    if config_name:
        # Explicit config requested
        configs = {
            'development': DevConfig,
            'production': ProdConfig,
            'testing': TestConfig,
            'default': Config,
        }
        return configs.get(config_name, Config)
    
    # Auto-detect from environment
    env = os.environ.get('FLASK_ENV', 'development').lower()
    
    if env == 'production':
        return ProdConfig
    elif env == 'testing':
        return TestConfig
    else:  # development
        return DevConfig

# Export validation (if these modules exist)
try:
    from .validation import validate_config, check_secrets_not_committed
except ImportError:
    # Create dummy functions if validation module doesn't exist
    def validate_config():
        pass
    
    def check_secrets_not_committed():
        pass

# Export everything
__all__ = [
    'Config', 
    'DevConfig', 
    'ProdConfig', 
    'TestConfig',
    'settings',
    'get_config',
    'validate_config',
    'check_secrets_not_committed',
]