from .base import BaseConfig
import os

class ProductionConfig(BaseConfig):
    SECRET_KEY = os.environ["SECRET_KEY"]
    DATABASE_URL = os.environ["DATABASE_URL"]
