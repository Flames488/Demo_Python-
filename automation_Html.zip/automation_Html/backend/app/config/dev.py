from .settings import Config
from .env import get_env

class DevConfig(Config):
    """Development configuration."""
    
    DEBUG = True
    ENV = 'development'
    LOG_LEVEL = 'DEBUG'  # Development default
    
    # Development overrides
    SQLALCHEMY_ECHO = True
    SESSION_COOKIE_SECURE = False
    PREFERRED_URL_SCHEME = 'http'
    
    @classmethod
    def validate(cls):
        """Development validation - only basic checks."""
        
        if not get_env('STRIPE_SECRET_KEY', ''):
            print("⚠️  STRIPE_SECRET_KEY not set - using development placeholder")
        
        if not get_env('GOOGLE_CLIENT_ID', ''):
            print("⚠️  GOOGLE_CLIENT_ID not set - OAuth will not work")
        
        if not cls.SQLALCHEMY_DATABASE_URI.startswith(('postgresql://', 'postgres://')):
            raise ValueError(
                f"Invalid DATABASE_URL format. Must start with postgresql://\n"
                f"Got: {cls.SQLALCHEMY_DATABASE_URI[:50]}..."
            )
        
        print("✅ Development configuration validated")
    
    @classmethod
    def init_app(cls, app):
        """Initialize development-specific settings."""
        super().init_app(app)
        
        # Development features
        app.config['TEMPLATES_AUTO_RELOAD'] = True
        
        # Set placeholder values for optional services
        if not app.config.get('STRIPE_SECRET_KEY'):
            app.config['STRIPE_SECRET_KEY'] = 'dev-key-not-for-production'
            app.config['STRIPE_WEBHOOK_SECRET'] = 'dev-webhook-not-for-production'
        
        if not app.config.get('GOOGLE_CLIENT_ID'):
            app.config['GOOGLE_CLIENT_ID'] = 'dev-google-client-id'
            app.config['GOOGLE_CLIENT_SECRET'] = 'dev-google-client-secret'