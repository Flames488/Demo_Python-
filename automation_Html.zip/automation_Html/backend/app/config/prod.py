from .settings import Config
from .env import get_env

class ProdConfig(Config):
    """Production configuration."""
    
    DEBUG = False
    ENV = 'production'
    PROPAGATE_EXCEPTIONS = True
    LOG_LEVEL = 'INFO'  # Production default
    
    # Production security
    SESSION_COOKIE_SECURE = True
    REMEMBER_COOKIE_SECURE = True
    
    # Production-specific settings
    STRIPE_SECRET_KEY = get_env('STRIPE_SECRET_KEY', required=True)
    STRIPE_WEBHOOK_SECRET = get_env('STRIPE_WEBHOOK_SECRET', required=True)
    GOOGLE_CLIENT_ID = get_env('GOOGLE_CLIENT_ID', required=True)
    GOOGLE_CLIENT_SECRET = get_env('GOOGLE_CLIENT_SECRET', required=True)
    
    # New production-only setting
    ALLOWED_HOSTS = get_env('ALLOWED_HOSTS', required=True)
    
    @classmethod
    def validate(cls):
        """Strict production validation."""
        errors = []
        
        if cls.DEBUG:
            errors.append("DEBUG must be False in production")
        
        if len(cls.SECRET_KEY) < 64:
            errors.append("SECRET_KEY must be at least 64 characters in production")
        
        if not cls.STRIPE_SECRET_KEY.startswith(('sk_live_', 'rk_live_')):
            errors.append("STRIPE_SECRET_KEY must start with sk_live_ or rk_live_ in production")
        
        if not cls.SQLALCHEMY_DATABASE_URI.startswith('postgresql://'):
            errors.append("DATABASE_URL must start with postgresql:// in production")
        
        if not cls.SESSION_COOKIE_SECURE:
            errors.append("SESSION_COOKIE_SECURE must be True in production")
        
        if get_env('FLASK_DEBUG', '0') != '0':
            errors.append("FLASK_DEBUG must be 0 in production")
        
        if errors:
            error_msg = "❌ Production configuration failed:\n" + "\n".join(f"  • {e}" for e in errors)
            raise RuntimeError(error_msg)
        
        # Logging is now handled centrally, but we validate LOG_LEVEL
        valid_levels = ['DEBUG', 'INFO', 'WARNING', 'ERROR', 'CRITICAL']
        if cls.LOG_LEVEL not in valid_levels:
            errors.append(f"LOG_LEVEL must be one of {valid_levels}")
        
        print("✅ Production configuration validated")
    
    @classmethod
    def init_app(cls, app):
        """Initialize production-specific settings."""
        super().init_app(app)
        
        # Note: Logging is now centralized in utils/logging.py
        # No need for file handlers in containerized environments