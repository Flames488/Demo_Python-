from flask import g, request
import uuid

def add_request_id(app):
    @app.before_request
    def assign_request_id():
        g.request_id = request.headers.get("X-Request-ID", str(uuid.uuid4()))

    @app.after_request
    def inject_request_id(response):
        response.headers["X-Request-ID"] = getattr(g, "request_id", "")
        return response

    return app