import logging
import json
import uuid
from pythonjsonlogger import jsonlogger

def configure_json_logging():
    logger = logging.getLogger()
    logger.setLevel(logging.INFO)

    log_handler = logging.StreamHandler()

    formatter = jsonlogger.JsonFormatter(
        "%(asctime)s %(levelname)s %(name)s %(message)s %(request_id)s"
    )
    log_handler.setFormatter(formatter)
    logger.handlers = [log_handler]
    return logger


def get_request_id():
    return str(uuid.uuid4())