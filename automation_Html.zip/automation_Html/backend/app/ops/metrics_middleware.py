from prometheus_client import Counter, Histogram, generate_latest
from time import time
from flask import Response

REQUEST_COUNT = Counter("http_requests_total", "Total HTTP Requests", ["method", "endpoint", "status"])
REQUEST_LATENCY = Histogram("http_request_latency_seconds", "Request latency", ["endpoint"])


def add_metrics(app):
    @app.before_request
    def start_timer():
        from flask import g
        g.start_time = time()

    @app.after_request
    def record_metrics(response):
        from flask import request, g
        latency = time() - getattr(g, "start_time", time())
        REQUEST_COUNT.labels(request.method, request.path, response.status_code).inc()
        REQUEST_LATENCY.labels(request.path).observe(latency)
        return response

    @app.route("/metrics")
    def metrics():
        return Response(generate_latest(), mimetype="text/plain")

    return app