from app.services.security.admin import require_admin
from app.models.user import User
from app.db import session


def delete_user(admin_user, user_id: int):
    require_admin(admin_user)  # 🔒 HARD ENFORCEMENT

    user = session.get(User, user_id)
    if not user:
        return False

    session.delete(user)
    session.commit()
    return True
