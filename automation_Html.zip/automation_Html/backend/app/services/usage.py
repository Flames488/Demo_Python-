from app.extensions import db
from datetime import datetime

def record_usage(user_id, feature, amount=1):
    usage = UsageLog(
        user_id=user_id,
        feature=feature,
        amount=amount,
        timestamp=datetime.utcnow()
    )
    db.session.add(usage)
    db.session.commit()
