def log_event(user_id, action, meta=None):
    db.session.add(AuditLog(
        user_id=user_id,
        action=action,
        meta=meta or {}
    ))
    db.session.commit()
