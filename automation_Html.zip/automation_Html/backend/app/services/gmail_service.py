# gmail_service.py
import logging
from typing import List, Dict, Any, Optional
from google.oauth2.credentials import Credentials
from google_auth_oauthlib.flow import Flow
from google.auth.exceptions import GoogleAuthError
from googleapiclient.errors import HttpError
from googleapiclient.discovery import build
import time

from app.utils.errors import ExternalServiceError, AuthError, RateLimitError, ValidationError

logger = logging.getLogger(__name__)


class GmailService:
    def __init__(
        self, 
        client_id: str, 
        client_secret: str, 
        max_retries: int = 3, 
        retry_delay: float = 1.0
    ):
        """
        Initialize GmailService
        
        Args:
            client_id: Google OAuth2 client ID
            client_secret: Google OAuth2 client secret
            max_retries: Maximum number of retry attempts
            retry_delay: Base delay between retries in seconds
        """
        self.client_id = client_id
        self.client_secret = client_secret
        self.max_retries = max_retries
        self.retry_delay = retry_delay
        logger.info("Initializing GmailService")
        self._validate_credentials()
    
    def _validate_credentials(self) -> None:
        """Validate that credentials are provided"""
        logger.debug("Validating Gmail API credentials")
        if not self.client_id or not isinstance(self.client_id, str):
            logger.error("Invalid or missing Gmail API client_id")
            raise ValidationError("Client ID is required and must be a string")
        
        if not self.client_secret or not isinstance(self.client_secret, str):
            logger.error("Invalid or missing Gmail API client_secret")
            raise ValidationError("Client Secret is required and must be a string")
        logger.debug("Gmail API credentials validation successful")
    
    def create_flow(self, redirect_uri: str) -> Flow:
        """
        Create OAuth2 flow with error handling
        
        Args:
            redirect_uri: OAuth2 redirect URI
            
        Returns:
            Flow: Configured OAuth2 flow object
            
        Raises:
            AuthError: If authentication setup fails
            ExternalServiceError: If Google service fails
        """
        try:
            if not redirect_uri or not isinstance(redirect_uri, str):
                raise ValidationError("Invalid redirect URI")
            
            logger.debug(f"Creating OAuth2 flow for redirect URI: {redirect_uri}")
            
            flow = Flow.from_client_config(
                {
                    "web": {
                        "client_id": self.client_id,
                        "client_secret": self.client_secret,
                        "redirect_uris": [redirect_uri],
                        "auth_uri": "https://accounts.google.com/o/oauth2/auth",
                        "token_uri": "https://oauth2.googleapis.com/token"
                    }
                },
                scopes=["https://www.googleapis.com/auth/gmail.readonly"]
            )
            
            # Enable offline access for refresh tokens
            flow.redirect_uri = redirect_uri
            
            logger.info("OAuth2 flow created successfully")
            return flow
            
        except ValueError as e:
            logger.error(f"Invalid configuration for OAuth flow: {str(e)}")
            raise ValidationError(f"Invalid configuration: {str(e)}")
        except GoogleAuthError as e:
            logger.error("Gmail auth failed", exc_info=True)
            raise AuthError(f"Authentication setup failed: {str(e)}")
        except Exception as e:
            logger.exception(f"Unexpected error creating OAuth flow: {str(e)}")
            raise ExternalServiceError(f"Failed to create authentication flow: {str(e)}")
    
    def fetch_emails(
        self, 
        credentials: Credentials, 
        max_results: int = 10,
        label_ids: Optional[List[str]] = None,
        query: Optional[str] = None
    ) -> List[Dict[str, Any]]:
        """
        Fetch emails from Gmail with retry logic
        
        Args:
            credentials: OAuth2 credentials object
            max_results: Maximum number of emails to fetch
            label_ids: Optional list of label IDs to filter by
            query: Optional Gmail search query
            
        Returns:
            list: List of email message objects
            
        Raises:
            AuthError: If authentication fails
            RateLimitError: If rate limited
            ExternalServiceError: If API call fails
        """
        logger.info("Fetching emails from Gmail API")
        
        for attempt in range(self.max_retries):
            try:
                # Build Gmail service with credentials
                service = build('gmail', 'v1', credentials=credentials)
                
                # Prepare request parameters
                request_params = {
                    'userId': 'me',
                    'maxResults': max_results
                }
                
                # Add optional parameters if provided
                if label_ids:
                    request_params['labelIds'] = label_ids
                if query:
                    request_params['q'] = query
                
                # Execute API request
                logger.debug(f"Fetching emails with params: {request_params}")
                results = service.users().messages().list(**request_params).execute()
                
                messages = results.get('messages', [])
                logger.info(f"Successfully fetched {len(messages)} emails")
                return messages
                
            except HttpError as e:
                status_code = e.resp.status if hasattr(e, 'resp') else None
                error_details = str(e)
                
                # Handle rate limiting
                if status_code == 429:
                    wait_time = self.retry_delay * (2 ** attempt)  # Exponential backoff
                    logger.warning(
                        f"Rate limited, attempt {attempt + 1}/{self.max_retries}, "
                        f"waiting {wait_time:.1f}s"
                    )
                    
                    if attempt < self.max_retries - 1:
                        time.sleep(wait_time)
                        continue
                    else:
                        logger.error("Max retries exceeded for rate limiting")
                        raise RateLimitError(f"Gmail API rate limit exceeded: {error_details}")
                
                # Handle authentication errors
                elif status_code in [401, 403]:
                    logger.error("Gmail auth failed", exc_info=True)
                    raise AuthError(f"Gmail authentication failed: {error_details}")
                
                # Handle other HTTP errors
                else:
                    logger.error(f"Gmail API HTTP error (status {status_code}): {error_details}")
                    raise ExternalServiceError(f"Gmail API error (status {status_code}): {error_details}")
                    
            except Exception as e:
                logger.error(f"Unexpected error fetching emails (attempt {attempt + 1}): {str(e)}")
                
                if attempt < self.max_retries - 1:
                    time.sleep(self.retry_delay)
                    continue
                else:
                    logger.exception("Max retries exceeded for email fetch")
                    raise ExternalServiceError(
                        f"Failed to fetch emails after {self.max_retries} attempts: {str(e)}"
                    )
        
        # This should not be reached due to the loop structure, but kept as safety
        raise ExternalServiceError("Failed to fetch emails")
    
    def get_email_details(
        self, 
        credentials: Credentials, 
        message_id: str, 
        format: str = 'metadata'
    ) -> Dict[str, Any]:
        """
        Get detailed information about a specific email
        
        Args:
            credentials: OAuth2 credentials object
            message_id: The Gmail message ID
            format: Format of the message ('full', 'metadata', 'minimal', 'raw')
            
        Returns:
            dict: Detailed message information
            
        Raises:
            ExternalServiceError: If API call fails
        """
        logger.info(f"Fetching email details for message {message_id}")
        try:
            service = build('gmail', 'v1', credentials=credentials)
            message = service.users().messages().get(
                userId='me',
                id=message_id,
                format=format
            ).execute()
            
            logger.debug(f"Successfully retrieved email details for message {message_id}")
            return message
        except HttpError as e:
            logger.error(f"Gmail API HTTP error fetching email details: {str(e)}")
            raise ExternalServiceError(f"Failed to fetch email details: {str(e)}")
        except Exception as e:
            logger.exception(f"Unexpected error fetching email details: {str(e)}")
            raise ExternalServiceError(f"Failed to fetch email details: {str(e)}")