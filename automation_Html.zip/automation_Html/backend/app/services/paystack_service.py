import requests
from flask import current_app

BASE_URL = "https://api.paystack.co"

def initialize_transaction(user, plan):
    res = requests.post(
        f"{BASE_URL}/transaction/initialize",
        headers={
            "Authorization": f"Bearer {current_app.config['PAYSTACK_SECRET_KEY']}"
        },
        json={
            "email": user.email,
            "amount": plan.amount * 100,
            "metadata": {
                "user_id": user.id,
                "plan": plan.code
            }
        }
    )
    return res.json()["data"]["authorization_url"]
