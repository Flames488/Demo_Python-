from app.extensions import db

def process_billing_event(event_id, user_id, plan):
    if BillingEvent.query.get(event_id):
        return  # idempotent

    try:
        with db.session.begin():
            sub = Subscription.activate(user_id, plan)
            db.session.add(BillingEvent(id=event_id))
    except Exception:
        db.session.rollback()
        raise
    
def activate_subscription(user_id, plan_code):
    sub = Subscription.query.filter_by(user_id=user_id).first()

    if not sub:
        sub = Subscription(user_id=user_id)

    sub.plan = plan_code
    sub.status = "active"
    sub.expires_at = calculate_expiry(plan_code)

    db.session.add(sub)
