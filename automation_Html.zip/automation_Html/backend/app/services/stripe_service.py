import stripe
from flask import current_app

stripe.api_key = current_app.config["STRIPE_SECRET_KEY"]

def create_checkout_session(user, plan):
    session = stripe.checkout.Session.create(
        payment_method_types=["card"],
        mode="subscription",
        customer_email=user.email,
        line_items=[{
            "price": plan.stripe_price_id,
            "quantity": 1
        }],
        metadata={
            "user_id": user.id,
            "plan": plan.code
        },
        success_url=current_app.config["FRONTEND_URL"] + "/success",
        cancel_url=current_app.config["FRONTEND_URL"] + "/cancel"
    )
    return session.url
