import logging
from app.extensions import db
from app.models.task import Task
from sqlalchemy.exc import SQLAlchemyError

logger = logging.getLogger(__name__)

class TaskEngineError(Exception):
    """Base exception for Task Engine errors"""
    pass

class TaskCreationError(TaskEngineError):
    """Raised when task creation fails"""
    pass

class DatabaseConnectionError(TaskEngineError):
    """Raised when database connection fails"""
    pass

class TaskEngine:
    @staticmethod
    def create_task(title, summary, source="unknown"):
        """
        Create a new task with error handling
        
        Args:
            title: Task title
            summary: Task summary
            source: Task source
            
        Returns:
            Task: The created task object
            
        Raises:
            TaskCreationError: If task creation fails
        """
        try:
            # Input validation
            if not title or not isinstance(title, str):
                raise ValueError("Invalid task title")
            
            if not summary or not isinstance(summary, str):
                raise ValueError("Invalid task summary")
            
            # Truncate inputs to prevent database errors
            title = title[:200]
            summary = summary[:500]
            
            task = Task(
                title=title, 
                summary=summary, 
                source=source,
                status="pending"
            )
            
            try:
                db.session.add(task)
                db.session.commit()
                logger.info(f"Successfully created task {task.id}")
                return task
                
            except SQLAlchemyError as e:
                db.session.rollback()
                logger.error(f"Database error creating task: {str(e)}")
                raise TaskCreationError(f"Failed to save task to database: {str(e)}")
                
        except ValueError as e:
            logger.error(f"Invalid input for task creation: {str(e)}")
            raise TaskCreationError(f"Invalid task data: {str(e)}")
            
        except Exception as e:
            logger.exception(f"Unexpected error creating task: {str(e)}")
            raise TaskCreationError(f"Failed to create task: {str(e)}")
    
    @staticmethod
    def get_task_count():
        """
        Get total task count with error handling
        
        Returns:
            int: Number of tasks, or -1 if query fails
            
        Note: Returns -1 instead of raising for non-critical queries
        """
        try:
            count = Task.query.count()
            logger.debug(f"Retrieved task count: {count}")
            return count
            
        except SQLAlchemyError as e:
            logger.error(f"Database error getting task count: {str(e)}")
            # Return -1 to indicate error for non-critical operation
            return -1
            
        except Exception as e:
            logger.exception(f"Unexpected error getting task count: {str(e)}")
            return -1
    
    @staticmethod
    def safe_create_task(title, summary, source="unknown"):
        """
        Safe version of create_task that logs but doesn't raise
        
        Args:
            title: Task title
            summary: Task summary
            source: Task source
            
        Returns:
            Task or None: Created task or None if failed
        """
        try:
            return TaskEngine.create_task(title, summary, source)
        except TaskCreationError as e:
            logger.error(f"Failed to create task safely: {str(e)}")
            return None