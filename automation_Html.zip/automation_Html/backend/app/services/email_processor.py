import logging
from app.services.ai_service import summarize, SummarizationError, TextTooShortError

logger = logging.getLogger(__name__)

class EmailProcessingError(Exception):
    """Base exception for email processing errors"""
    pass

class AIDependencyError(EmailProcessingError):
    """Raised when AI service dependency fails"""
    pass

def process_email(subject, body, ai_client, task_repo):
    """
    Process an email and create a task with its summary
    
    Args:
        subject: Email subject
        body: Email body
        ai_client: AI service client interface
        task_repo: Task repository for database operations
        
    Returns:
        Task: The created task object
        
    Raises:
        EmailProcessingError: If processing fails
    """
    task = None
    
    try:
        # Validate inputs
        if not subject or not isinstance(subject, str):
            raise ValueError("Invalid email subject")
        
        if not body or not isinstance(body, str):
            raise ValueError("Invalid email body")
        
        logger.info(f"Processing email with subject: {subject[:50]}...")
        
        # Attempt to generate summary with retry logic
        summary = None
        retry_count = 0
        max_retries = 2
        
        while summary is None and retry_count <= max_retries:
            try:
                # Use the provided AI client instead of direct import
                summary = ai_client.summarize(body)
                break
            except TextTooShortError as e:
                logger.warning(f"Using fallback summary for short text: {str(e)}")
                summary = f"Short message: {body[:50]}..."
                break
            except SummarizationError as e:
                retry_count += 1
                if retry_count > max_retries:
                    logger.error(f"AI service failed after {max_retries} retries: {str(e)}")
                    raise AIDependencyError(f"AI service unavailable: {str(e)}")
                logger.warning(f"Retry {retry_count}/{max_retries} for summarization...")
        
        # Create task object (not saved yet)
        task = task_repo.create_task_object(
            title=subject[:200],  # Limit title length
            summary=summary,
            source="gmail",
            status="pending"
        )
        
        # Save task using repository (handles DB operations)
        try:
            task = task_repo.save(task)
            logger.info(f"Successfully created task {task.id} for email")
            
        except Exception as e:
            logger.error(f"Repository error while saving task: {str(e)}")
            raise EmailProcessingError(f"Failed to save task: {str(e)}")
            
    except (ValueError, AIDependencyError) as e:
        logger.error(f"Email processing failed: {str(e)}")
        raise EmailProcessingError(f"Failed to process email: {str(e)}")
        
    except Exception as e:
        logger.exception(f"Unexpected error during email processing: {str(e)}")
        raise EmailProcessingError(f"Internal processing error: {str(e)}")
    
    return task