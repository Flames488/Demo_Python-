import logging

logger = logging.getLogger(__name__)

class AIServiceError(Exception):
    """Base exception for AI service errors"""
    pass

class TextTooShortError(AIServiceError):
    """Raised when text is too short to summarize"""
    pass

class SummarizationError(AIServiceError):
    """Raised when summarization fails"""
    pass

class AIService:
    """
    AI service for text summarization with explicit configuration.
    
    Args:
        api_key: API key for the AI service (passed explicitly, not from global state)
        api_url: Optional API endpoint URL
        min_length: Minimum text length for summarization
    """
    
    def __init__(self, api_key, api_url=None, min_length=10):
        if not api_key:
            raise ValueError("API key is required")
        
        self.api_key = api_key
        self.api_url = api_url or "https://api.example-ai-service.com/v1/summarize"
        self.min_length = min_length
        
        # Store configuration but don't expose sensitive data in logs
        logger.info("AIService initialized with custom configuration")
    
    def summarize(self, text):
        """
        Summarize the given text with error handling
        
        Args:
            text: The text to summarize
            
        Returns:
            str: Summary of the text
            
        Raises:
            TextTooShortError: If text is too short
            SummarizationError: If summarization fails
        """
        logger.info("Starting text summarization")
        try:
            # Validate input
            if not text or not isinstance(text, str):
                raise ValueError("Invalid text input")
            
            # Check minimum length
            if len(text.strip()) < self.min_length:
                raise TextTooShortError(
                    f"Text must be at least {self.min_length} characters long"
                )
            
            # Simulate API call with explicit API key
            # In real implementation, you would use self.api_key here
            summary = self._call_summarization_api(text)
            
            logger.info("Text summarization completed successfully")
            return summary
            
        except (TextTooShortError, SummarizationError) as e:
            logger.warning(f"Summarization warning: {str(e)}")
            raise
        except ValueError as e:
            logger.error(f"Invalid input for summarization: {str(e)}")
            raise SummarizationError(f"Invalid input: {str(e)}")
        except Exception as e:
            logger.exception(f"Unexpected error during summarization: {str(e)}")
            raise SummarizationError(f"Summarization service unavailable: {str(e)}")
    
    def _call_summarization_api(self, text):
        """
        Internal method to call the AI service API.
        
        Args:
            text: Text to summarize
            
        Returns:
            str: Summary
            
        Raises:
            SummarizationError: If API call fails
        """
        try:
            logger.debug(f"Calling AI summarization API for text of length {len(text)}")
            
            # Simulate potential AI service failure
            if "ERROR" in text.upper():
                raise SummarizationError("AI service failed to process text")
            
            # In a real implementation, you would:
            # 1. Set up headers with self.api_key
            # 2. Make HTTP request to self.api_url
            # 3. Process the response
            
            # Simulated summary
            summary = f"Summary: {text[:100]}"
            
            if len(text) > 100:
                summary += "..."
            
            logger.debug("AI summarization API call successful")    
            return summary
            
        except Exception as e:
            logger.exception("AI summarization API call failed")
            # Convert any API errors to domain-specific errors
            raise SummarizationError(f"AI service API error: {str(e)}")


def summarize(text):
    """
    Legacy function for backward compatibility.
    DEPRECATED: Use AIService class instead with explicit configuration.
    """
    logger.warning("Using deprecated summarize() function. Use AIService class instead.")
    service = AIService(api_key="legacy-default-key")
    return service.summarize(text)