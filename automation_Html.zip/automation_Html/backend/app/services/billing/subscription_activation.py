from sqlalchemy.exc import IntegrityError
from app.db import session
from app.models.subscription import Subscription
from app.models.billing_event import BillingEvent
from datetime import datetime


def activate_subscription(
    *,
    user_id: int,
    plan_id: str,
    provider: str,
    provider_event_id: str,
    period_end: datetime | None = None,
):
    """
    Canonical, idempotent subscription activation.
    Used by Stripe and Paystack.
    """

    with session.begin():
        # 1️⃣ Prevent event replay (idempotency)
        if BillingEvent.exists(provider, provider_event_id):
            return "duplicate"

        BillingEvent.create(
            provider=provider,
            event_id=provider_event_id
        )

        # 2️⃣ Deactivate existing active subscriptions
        session.query(Subscription).filter(
            Subscription.user_id == user_id,
            Subscription.is_active == True
        ).update({"is_active": False})

        # 3️⃣ Activate new subscription
        subscription = Subscription(
            user_id=user_id,
            plan_id=plan_id,
            provider=provider,
            is_active=True,
            current_period_end=period_end,
        )

        session.add(subscription)

    return "activated"
