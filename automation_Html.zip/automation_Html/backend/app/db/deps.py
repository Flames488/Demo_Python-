"""
Advanced database dependency and session management system
Features:
- Automatic transaction management with rollback on exceptions
- Nested transaction support
- Connection pooling configuration
- Health checks and metrics
- Context manager support
- Async-ready architecture
- Logging and monitoring integration
"""

from contextlib import asynccontextmanager, contextmanager
from functools import wraps
from typing import Optional, Callable, Any, Generator, AsyncGenerator, Type, Tuple
import logging
from datetime import datetime
import time
from enum import Enum

from sqlalchemy import create_engine, text, event
from sqlalchemy.engine import Engine
from sqlalchemy.orm import sessionmaker, Session, scoped_session
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.pool import QueuePool, StaticPool
from sqlalchemy.exc import SQLAlchemyError, IntegrityError, OperationalError
import redis
from prometheus_client import Counter, Histogram, Gauge
from pydantic import BaseSettings, Field

# Prometheus metrics
DB_QUERY_COUNT = Counter('db_queries_total', 'Total database queries', ['operation', 'status'])
DB_QUERY_DURATION = Histogram('db_query_duration_seconds', 'Database query duration', ['operation'])
DB_CONNECTIONS = Gauge('db_active_connections', 'Active database connections')
DB_TRANSACTIONS = Counter('db_transactions_total', 'Total database transactions', ['type'])

logger = logging.getLogger(__name__)

class TransactionType(str, Enum):
    READ_ONLY = "read_only"
    READ_WRITE = "read_write"
    NESTED = "nested"
    SERIALIZABLE = "serializable"

class DatabaseSettings(BaseSettings):
    """Database configuration settings with validation"""
    
    DATABASE_URL: str = Field(
        default="postgresql://user:password@localhost/dbname",
        env="DATABASE_URL"
    )
    DATABASE_POOL_SIZE: int = Field(default=20, env="DATABASE_POOL_SIZE")
    DATABASE_MAX_OVERFLOW: int = Field(default=40, env="DATABASE_MAX_OVERFLOW")
    DATABASE_POOL_TIMEOUT: int = Field(default=30, env="DATABASE_POOL_TIMEOUT")
    DATABASE_POOL_RECYCLE: int = Field(default=3600, env="DATABASE_POOL_RECYCLE")
    DATABASE_ECHO: bool = Field(default=False, env="DATABASE_ECHO")
    DATABASE_ISOLATION_LEVEL: str = Field(default="READ COMMITTED", env="DATABASE_ISOLATION_LEVEL")
    DATABASE_STATEMENT_TIMEOUT: int = Field(default=30000, env="DATABASE_STATEMENT_TIMEOUT")
    
    class Config:
        env_file = ".env"
        case_sensitive = False

# Database engine setup
class DatabaseManager:
    """Manages database connections, sessions, and transactions"""
    
    _instance: Optional['DatabaseManager'] = None
    _engine: Optional[Engine] = None
    _session_factory: Optional[Callable] = None
    
    def __new__(cls):
        if cls._instance is None:
            cls._instance = super().__new__(cls)
        return cls._instance
    
    @classmethod
    def init_engine(cls, settings: Optional[DatabaseSettings] = None) -> Engine:
        """Initialize database engine with connection pooling"""
        if cls._engine is not None:
            return cls._engine
        
        settings = settings or DatabaseSettings()
        
        engine_args = {
            "poolclass": QueuePool,
            "pool_size": settings.DATABASE_POOL_SIZE,
            "max_overflow": settings.DATABASE_MAX_OVERFLOW,
            "pool_timeout": settings.DATABASE_POOL_TIMEOUT,
            "pool_recycle": settings.DATABASE_POOL_RECYCLE,
            "echo": settings.DATABASE_ECHO,
            "isolation_level": settings.DATABASE_ISOLATION_LEVEL,
            "executemany_mode": "values",
            "future": True,
        }
        
        if "sqlite" in settings.DATABASE_URL:
            engine_args["connect_args"] = {"check_same_thread": False}
            engine_args["poolclass"] = StaticPool
        
        cls._engine = create_engine(settings.DATABASE_URL, **engine_args)
        
        # Add statement timeout for PostgreSQL
        if "postgresql" in settings.DATABASE_URL:
            @event.listens_for(cls._engine, "connect")
            def connect(dbapi_connection, connection_record):
                cursor = dbapi_connection.cursor()
                cursor.execute(
                    f"SET statement_timeout TO {settings.DATABASE_STATEMENT_TIMEOUT}"
                )
                cursor.close()
        
        cls._setup_health_check()
        logger.info(f"Database engine initialized for {settings.DATABASE_URL}")
        
        return cls._engine
    
    @classmethod
    def get_session_factory(cls) -> Callable:
        """Get thread-safe session factory"""
        if cls._session_factory is None:
            engine = cls.init_engine()
            cls._session_factory = scoped_session(
                sessionmaker(
                    autocommit=False,
                    autoflush=False,
                    bind=engine,
                    expire_on_commit=False,  # Better for web apps
                    class_=Session,
                )
            )
        return cls._session_factory
    
    @classmethod
    def _setup_health_check(cls):
        """Setup database health check"""
        @contextmanager
        def health_check():
            try:
                with cls._engine.connect() as conn:
                    conn.execute(text("SELECT 1"))
                yield True
            except Exception as e:
                logger.error(f"Database health check failed: {e}")
                yield False
        
        cls.health_check = health_check
    
    @classmethod
    def get_engine(cls) -> Engine:
        """Get database engine instance"""
        if cls._engine is None:
            cls.init_engine()
        return cls._engine
    
    @classmethod
    def dispose_pool(cls):
        """Dispose connection pool (for graceful shutdown)"""
        if cls._engine:
            cls._engine.dispose()
            cls._engine = None
            cls._session_factory = None
            logger.info("Database connection pool disposed")

# Create database manager instance
db_manager = DatabaseManager()
SessionLocal = db_manager.get_session_factory()
Base = declarative_base()

class TransactionContext:
    """Context manager for database transactions with automatic rollback"""
    
    def __init__(
        self,
        session: Session,
        transaction_type: TransactionType = TransactionType.READ_WRITE,
        rollback_on: Optional[Tuple[Type[Exception], ...]] = None,
        nested: bool = False
    ):
        self.session = session
        self.transaction_type = transaction_type
        self.rollback_on = rollback_on or (Exception,)
        self.nested = nested
        self.transaction = None
        self.start_time = None
        
    def __enter__(self):
        self.start_time = time.time()
        
        if self.nested:
            self.transaction = self.session.begin_nested()
        else:
            if self.transaction_type == TransactionType.SERIALIZABLE:
                self.session.execute(text("SET TRANSACTION ISOLATION LEVEL SERIALIZABLE"))
            elif self.transaction_type == TransactionType.READ_ONLY:
                self.session.execute(text("SET TRANSACTION READ ONLY"))
            
            self.transaction = self.session.begin()
        
        DB_CONNECTIONS.inc()
        DB_TRANSACTIONS.labels(type=self.transaction_type.value).inc()
        
        logger.debug(
            f"Transaction started: type={self.transaction_type}, "
            f"nested={self.nested}, session={id(self.session)}"
        )
        
        return self
    
    def __exit__(self, exc_type, exc_val, exc_tb):
        duration = time.time() - self.start_time
        
        try:
            if exc_type is not None:
                # Check if this exception should trigger rollback
                if any(issubclass(exc_type, exc_class) for exc_class in self.rollback_on):
                    self.session.rollback()
                    DB_TRANSACTIONS.labels(type="rollback").inc()
                    logger.warning(
                        f"Transaction rolled back due to {exc_type.__name__}: "
                        f"{exc_val}, duration={duration:.3f}s"
                    )
                else:
                    # Exception not in rollback_on list, commit anyway
                    self.session.commit()
                    DB_TRANSACTIONS.labels(type="commit").inc()
                    logger.info(
                        f"Transaction committed despite {exc_type.__name__}, "
                        f"duration={duration:.3f}s"
                    )
            else:
                # No exception, commit transaction
                self.session.commit()
                DB_TRANSACTIONS.labels(type="commit").inc()
                logger.debug(
                    f"Transaction committed successfully, "
                    f"duration={duration:.3f}s"
                )
                
        except SQLAlchemyError as e:
            logger.error(f"Error during transaction finalization: {e}")
            self.session.rollback()
            DB_TRANSACTIONS.labels(type="rollback").inc()
            raise
        finally:
            DB_CONNECTIONS.dec()
            if self.transaction:
                self.transaction.close()
    
    def savepoint(self, name: str = None):
        """Create a savepoint within the transaction"""
        return self.session.begin_nested()

@contextmanager
def get_db(
    transaction_type: TransactionType = TransactionType.READ_WRITE,
    auto_commit: bool = True,
    **kwargs
) -> Generator[Session, None, None]:
    """
    Advanced database session context manager with automatic transaction handling
    
    Args:
        transaction_type: Type of transaction isolation
        auto_commit: Whether to auto-commit on successful completion
        **kwargs: Additional arguments for TransactionContext
        
    Yields:
        Session: SQLAlchemy database session
        
    Raises:
        SQLAlchemyError: For database-related errors
        Exception: For unexpected errors during session management
        
    Example:
        ```python
        with get_db() as db:
            result = db.query(User).filter(User.id == 1).first()
            # Transaction automatically committed on success
            # or rolled back on exception
        ```
    """
    session = SessionLocal()
    DB_CONNECTIONS.inc()
    
    try:
        if auto_commit:
            # Use TransactionContext for robust transaction handling
            with TransactionContext(session, transaction_type, **kwargs):
                yield session
                # TransactionContext automatically handles:
                # - Transaction start/commit/rollback
                # - Metrics collection
                # - Proper exception handling
        else:
            # Manual transaction management mode
            # Useful for scenarios where caller wants full control
            # or needs to manage multiple transactions in one session
            yield session
            
    except SQLAlchemyError as e:
        logger.error(f"Database error: {e}")
        # DEFENSE 4 - Re-raise to trigger retry
        # Note: If using TransactionContext, rollback is already handled
        if not auto_commit and session.is_active:
            session.rollback()
            DB_TRANSACTIONS.labels(type="rollback").inc()
        raise
    except Exception as e:
        logger.error(f"Unexpected error in database session: {e}")
        # DEFENSE 4 - Re-raise to trigger retry
        if not auto_commit and session.is_active:
            session.rollback()
            DB_TRANSACTIONS.labels(type="rollback").inc()
        raise
    finally:
        try:
            session.close()
        except Exception as e:
            logger.warning(f"Error closing session: {e}")
        finally:
            DB_CONNECTIONS.dec()

def transactional(
    transaction_type: TransactionType = TransactionType.READ_WRITE,
    retry_on_deadlock: int = 0,
    retry_on_operational_error: bool = False,
    max_retry_delay: float = 2.0,
    **context_kwargs
):
    """
    Decorator for wrapping functions in a database transaction with retry logic
    
    Args:
        transaction_type: Type of transaction isolation
        retry_on_deadlock: Number of retries on deadlock detection
        retry_on_operational_error: Whether to retry on operational errors
        max_retry_delay: Maximum delay between retries in seconds
        **context_kwargs: Additional arguments for TransactionContext
        
    Returns:
        Callable: Decorated function with transaction handling
        
    Example:
        ```python
        @transactional(retry_on_deadlock=3)
        def create_user(user_data: dict, db: Session):
            user = User(**user_data)
            db.add(user)
            # Auto-retry on deadlock up to 3 times
        ```
    """
    def decorator(func: Callable):
        @wraps(func)
        def wrapper(*args, **kwargs):
            retry_count = 0
            max_retries = retry_on_deadlock
            last_error = None
            
            while retry_count <= max_retries:
                try:
                    with get_db(transaction_type, **context_kwargs) as db:
                        # Inject db session if function expects it
                        if 'db' in func.__code__.co_varnames:
                            kwargs['db'] = db
                        return func(*args, **kwargs)
                        
                except OperationalError as e:
                    # Check for deadlock
                    is_deadlock = "deadlock" in str(e).lower()
                    should_retry = (
                        (is_deadlock and retry_count < max_retries) or
                        (retry_on_operational_error and retry_count < max_retries)
                    )
                    
                    if should_retry:
                        retry_count += 1
                        last_error = e
                        
                        # Calculate exponential backoff with jitter
                        base_delay = min(0.1 * (2 ** retry_count), max_retry_delay)
                        jitter = base_delay * 0.1  # 10% jitter
                        delay = base_delay + (jitter * (1 - 2 * time.time() % 1))
                        
                        logger.warning(
                            f"Database error ({e.__class__.__name__}), "
                            f"retry {retry_count}/{max_retries} in {delay:.3f}s"
                        )
                        time.sleep(delay)
                        continue
                    
                    logger.error(f"Database operational error (no more retries): {e}")
                    raise
                    
                except IntegrityError as e:
                    # Integrity errors (duplicate keys, foreign key violations)
                    # should not be retried as they won't succeed on retry
                    logger.error(f"Database integrity error: {e}")
                    raise
                    
                except SQLAlchemyError as e:
                    # Other SQLAlchemy errors
                    logger.error(f"Database error: {e}")
                    raise
                    
                except Exception as e:
                    if retry_count < max_retries and retry_on_operational_error:
                        retry_count += 1
                        last_error = e
                        
                        delay = min(0.1 * (2 ** retry_count), max_retry_delay)
                        logger.warning(
                            f"Unexpected error, retry {retry_count}/{max_retries} in {delay:.3f}s: {e}"
                        )
                        time.sleep(delay)
                        continue
                    
                    logger.error(f"Unexpected error in transactional function: {e}")
                    raise
            
            if last_error:
                raise last_error
        
        return wrapper
    return decorator

# Async support (if using async database drivers)
@asynccontextmanager
async def get_async_db(
    transaction_type: TransactionType = TransactionType.READ_WRITE,
    auto_commit: bool = True,
    **kwargs
) -> AsyncGenerator[Session, None]:
    """
    Async version of get_db for async/await contexts
    
    Args:
        transaction_type: Type of transaction isolation
        auto_commit: Whether to auto-commit on successful completion
        **kwargs: Additional arguments for TransactionContext
        
    Yields:
        Session: SQLAlchemy database session
        
    Note:
        Requires async database driver (asyncpg, aiomysql, etc.)
        This is a synchronous wrapper for async drivers
    """
    session = SessionLocal()
    DB_CONNECTIONS.inc()
    
    try:
        if auto_commit:
            # Note: For true async support, you'd need async versions of:
            # - create_async_engine
            # - async_sessionmaker
            # - AsyncSession
            # This is a placeholder implementation
            with TransactionContext(session, transaction_type, **kwargs):
                yield session
        else:
            yield session
            
    except SQLAlchemyError as e:
        logger.error(f"Async database error: {e}")
        if not auto_commit and session.is_active:
            session.rollback()
            DB_TRANSACTIONS.labels(type="rollback").inc()
        raise
    except Exception as e:
        logger.error(f"Unexpected error in async database session: {e}")
        if not auto_commit and session.is_active:
            session.rollback()
            DB_TRANSACTIONS.labels(type="rollback").inc()
        raise
    finally:
        try:
            session.close()
        except Exception as e:
            logger.warning(f"Error closing async session: {e}")
        finally:
            DB_CONNECTIONS.dec()

class DatabaseHealth:
    """Database health monitoring and metrics"""
    
    @staticmethod
    def check_health() -> dict:
        """Perform comprehensive database health check"""
        try:
            engine = db_manager.get_engine()
            with engine.connect() as conn:
                # Check connection
                start = time.time()
                result = conn.execute(text("SELECT 1")).scalar()
                latency = time.time() - start
                
                # Get connection pool info
                pool = engine.pool
                
                # Get additional database info
                db_info = {}
                try:
                    # PostgreSQL specific stats
                    if "postgresql" in str(engine.url):
                        db_info.update({
                            "version": conn.execute(text("SELECT version()")).scalar(),
                            "active_connections": conn.execute(
                                text("SELECT count(*) FROM pg_stat_activity WHERE state = 'active'")
                            ).scalar(),
                        })
                except Exception:
                    pass  # Ignore DB-specific info errors
                
                health_status = {
                    "status": "healthy" if result == 1 else "unhealthy",
                    "latency_seconds": round(latency, 4),
                    "pool": {
                        "size": pool.size(),
                        "checked_in": pool.checkedin(),
                        "checked_out": pool.checkedout(),
                        "overflow": pool.overflow(),
                        "connections": pool.checkedin() + pool.checkedout(),
                    },
                    "database": db_info,
                    "timestamp": datetime.utcnow().isoformat(),
                    "metrics": DatabaseHealth.get_metrics()
                }
                
                logger.debug(f"Database health check: {health_status['status']}")
                return health_status
                
        except Exception as e:
            logger.error(f"Health check failed: {e}")
            return {
                "status": "unhealthy",
                "error": str(e),
                "timestamp": datetime.utcnow().isoformat()
            }
    
    @staticmethod
    def get_metrics() -> dict:
        """Get database performance metrics"""
        try:
            metrics = {
                "connections": {
                    "active": DB_CONNECTIONS._value.get() if hasattr(DB_CONNECTIONS, '_value') else 0,
                },
                "transactions": {
                    "total": 0,
                    "by_type": {},
                    "committed": 0,
                    "rolled_back": 0
                },
                "queries": {
                    "total": 0,
                    "by_operation": {}
                }
            }
            
            # Collect transaction metrics
            if hasattr(DB_TRANSACTIONS, '_metrics'):
                for (label, value), metric in DB_TRANSACTIONS._metrics.items():
                    if label == 'type':
                        metrics["transactions"]["by_type"][value] = metric._value.get()
                        metrics["transactions"]["total"] += metric._value.get()
                        
                        if value == 'commit':
                            metrics["transactions"]["committed"] = metric._value.get()
                        elif value == 'rollback':
                            metrics["transactions"]["rolled_back"] = metric._value.get()
            
            # Collect query metrics
            if hasattr(DB_QUERY_COUNT, '_metrics'):
                for (operation, status), metric in DB_QUERY_COUNT._metrics.items():
                    metrics["queries"]["total"] += metric._value.get()
                    if operation not in metrics["queries"]["by_operation"]:
                        metrics["queries"]["by_operation"][operation] = {}
                    metrics["queries"]["by_operation"][operation][status] = metric._value.get()
            
            return metrics
            
        except Exception as e:
            logger.error(f"Error collecting metrics: {e}")
            return {"error": str(e)}

# FastAPI dependency integration
def db_dependency(
    transaction_type: TransactionType = TransactionType.READ_WRITE,
    auto_commit: bool = True,
    **kwargs
) -> Callable:
    """
    FastAPI dependency injection for database sessions
    
    Args:
        transaction_type: Type of transaction isolation
        auto_commit: Whether to auto-commit on successful completion
        **kwargs: Additional arguments passed to get_db
        
    Returns:
        Callable: FastAPI dependency function
        
    Example:
        ```python
        from fastapi import Depends
        
        @app.get("/users")
        async def get_users(db: Session = Depends(db_dependency())):
            return db.query(User).all()
        ```
    """
    def dependency() -> Generator[Session, None, None]:
        with get_db(transaction_type=transaction_type, auto_commit=auto_commit, **kwargs) as session:
            yield session
    
    return dependency

def async_db_dependency(
    transaction_type: TransactionType = TransactionType.READ_WRITE,
    auto_commit: bool = True,
    **kwargs
) -> Callable:
    """
    FastAPI async dependency injection for database sessions
    
    Args:
        transaction_type: Type of transaction isolation
        auto_commit: Whether to auto-commit on successful completion
        **kwargs: Additional arguments passed to get_async_db
        
    Returns:
        Callable: FastAPI async dependency function
    """
    async def dependency() -> AsyncGenerator[Session, None]:
        async with get_async_db(
            transaction_type=transaction_type,
            auto_commit=auto_commit,
            **kwargs
        ) as session:
            yield session
    
    return dependency

# Query instrumentation decorator
def instrument_query(operation: str = "query"):
    """
    Decorator to instrument database queries with metrics
    
    Args:
        operation: Name of the operation for metrics
        
    Returns:
        Callable: Decorated function with query instrumentation
    """
    def decorator(func: Callable):
        @wraps(func)
        def wrapper(*args, **kwargs):
            start_time = time.time()
            status = "success"
            
            try:
                result = func(*args, **kwargs)
                return result
            except Exception as e:
                status = "error"
                raise
            finally:
                duration = time.time() - start_time
                DB_QUERY_COUNT.labels(operation=operation, status=status).inc()
                DB_QUERY_DURATION.labels(operation=operation).observe(duration)
                
                if duration > 1.0:  # Log slow queries
                    logger.warning(
                        f"Slow query detected: {operation} took {duration:.3f}s"
                    )
        
        return wrapper
    return decorator

# Export common items
__all__ = [
    "get_db",
    "get_async_db",
    "transactional",
    "instrument_query",
    "TransactionContext",
    "TransactionType",
    "SessionLocal",
    "Base",
    "db_dependency",
    "async_db_dependency",
    "DatabaseHealth",
    "DatabaseManager",
    "DatabaseSettings",
    "DB_CONNECTIONS",
    "DB_TRANSACTIONS",
    "DB_QUERY_COUNT",
    "DB_QUERY_DURATION"
]