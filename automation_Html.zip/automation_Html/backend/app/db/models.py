# models.py - Updated with advanced WebhookEvent model
from sqlalchemy import Column, String, DateTime, Text, Enum, Boolean, Integer, Index, CheckConstraint
from sqlalchemy.dialects.postgresql import UUID, JSONB
from sqlalchemy.ext.indexable import index_property
from sqlalchemy.sql import func, expression
from sqlalchemy.orm import validates
from sqlalchemy.ext.hybrid import hybrid_property
from sqlalchemy import event
import enum
import uuid
import re
from typing import Optional, Dict, Any
from datetime import datetime, timezone

from app.db.base import Base
from app.core.config import settings


class WebhookSource(enum.Enum):
    """Enumeration of supported webhook sources."""
    STRIPE = "stripe"
    GITHUB = "github"
    SLACK = "slack"
    CUSTOM = "custom"


class ProcessingStatus(enum.Enum):
    """Enumeration of event processing states."""
    PENDING = "pending"
    PROCESSING = "processing"
    SUCCESS = "success"
    FAILED = "failed"
    RETRY = "retry"


class WebhookEvent(Base):
    """
    Advanced webhook event model with support for multiple providers,
    retry mechanisms, and comprehensive event tracking.
    
    Features:
    - Multi-provider support (Stripe, GitHub, Slack, Custom)
    - JSONB payload storage with indexed fields
    - Retry mechanism with exponential backoff
    - Event validation and sanitization
    - Processing state machine
    - Performance optimizations with indexes
    - Event deduplication
    """
    
    __tablename__ = "webhook_events"
    __table_args__ = (
        # Composite index for common query patterns
        Index('ix_webhook_events_source_type_status', 'source', 'type', 'status'),
        
        # Partial index for pending/retry events for faster polling
        Index('ix_webhook_events_pending', 'status', 'next_retry_at', 
              postgresql_where=expression.or_(
                  status == ProcessingStatus.PENDING,
                  status == ProcessingStatus.RETRY
              )),
        
        # Index for event deduplication checks
        Index('ix_webhook_events_dedupe', 'source', 'provider_event_id', 'received_at', 
              unique=True),
        
        # Index for cleanup operations
        Index('ix_webhook_events_created_at', 'created_at'),
        Index('ix_webhook_events_type', 'type'),
        
        # Ensure next_retry_at is in the future when status is RETRY
        CheckConstraint(
            "(status != 'retry') OR (next_retry_at IS NOT NULL AND next_retry_at > created_at)",
            name='ck_retry_timestamp'
        ),
        
        # Ensure retry count is non-negative
        CheckConstraint('retry_count >= 0', name='ck_retry_count_non_negative'),
        
        # Ensure event ID format for Stripe events
        CheckConstraint(
            "(source != 'stripe') OR (provider_event_id ~ '^evt_[a-zA-Z0-9]+$')",
            name='ck_stripe_event_id_format'
        ),
        
        # JSON schema validation for payload
        CheckConstraint(
            "jsonb_typeof(payload) = 'object'",
            name='ck_payload_is_object'
        ),
        
        {'comment': 'Stores webhook events from various providers with processing state tracking'}
    )

    # Primary key using UUID for distributed systems compatibility
    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4,
                comment='Internal unique identifier')
    
    # Provider's original event ID (e.g., Stripe's evt_xxx)
    # This serves as the idempotency key for duplicate detection
    provider_event_id = Column(String(255), nullable=False, unique=True,
                               comment='Original event ID from the provider')
    
    # Event source/provider
    source = Column(Enum(WebhookSource, name='webhook_source_enum'), 
                    nullable=False, index=True, default=WebhookSource.STRIPE,
                    comment='Source system of the webhook')
    
    # Event type (e.g., 'invoice.payment_succeeded', 'issues.opened')
    type = Column(String(255), nullable=False, index=True,
                  comment='Event type as defined by the provider')
    
    # Full event payload stored as JSONB for flexibility and query capabilities
    payload = Column(JSONB, nullable=False,
                     comment='Complete webhook payload in JSON format')
    
    # Processing state
    status = Column(Enum(ProcessingStatus, name='processing_status_enum'),
                    default=ProcessingStatus.PENDING, nullable=False, index=True,
                    comment='Current processing status')
    
    # Retry mechanism fields
    retry_count = Column(Integer, default=0, nullable=False,
                         comment='Number of processing attempts')
    next_retry_at = Column(DateTime(timezone=True),
                           comment='Scheduled time for next retry attempt')
    last_retry_at = Column(DateTime(timezone=True),
                           comment='Timestamp of last retry attempt')
    max_retries = Column(Integer, default=settings.WEBHOOK_MAX_RETRIES,
                         nullable=False,
                         comment='Maximum number of retry attempts')
    
    # Error tracking
    error_message = Column(Text,
                           comment='Error message from last failed processing attempt')
    error_details = Column(JSONB,
                           comment='Detailed error context and stack trace')
    
    # Timestamps with timezone awareness
    created_at = Column(DateTime(timezone=True), server_default=func.now(),
                        nullable=False, index=True,
                        comment='Timestamp when event was received')
    updated_at = Column(DateTime(timezone=True), server_default=func.now(),
                        onupdate=func.now(), nullable=False,
                        comment='Timestamp of last update')
    processed_at = Column(DateTime(timezone=True),
                          comment='Timestamp when event was successfully processed')
    
    # Request metadata
    request_headers = Column(JSONB,
                             comment='HTTP headers from the webhook request')
    remote_ip = Column(String(45),  # Supports IPv6
                       comment='IP address of the webhook sender')
    user_agent = Column(String(512),
                        comment='User agent string from the webhook request')
    
    # Provider-specific metadata
    api_version = Column(String(50),
                         comment='Provider API version (e.g., Stripe API version)')
    livemode = Column(Boolean, default=True,
                      comment='Whether the event is from live or test mode')
    
    # Add received_at for idempotency
    received_at = Column(DateTime(timezone=True), server_default=func.now(),
                         nullable=False, index=True,
                         comment='Timestamp when webhook was received')
    
    # Virtual/calculated columns for common access patterns
    _id = index_property('payload', '_id', default=None)
    _customer_id = index_property('payload', 'data.object.customer', default=None)
    _subscription_id = index_property('payload', 'data.object.subscription', default=None)
    
    @hybrid_property
    def is_test_event(self) -> bool:
        """Check if this is a test/sandbox event."""
        return not self.livemode
    
    @hybrid_property
    def can_retry(self) -> bool:
        """Check if event is eligible for retry."""
        return (self.status in [ProcessingStatus.FAILED, ProcessingStatus.RETRY] and
                self.retry_count < self.max_retries)
    
    @hybrid_property
    def age_seconds(self) -> Optional[int]:
        """Calculate event age in seconds."""
        if self.created_at:
            return (datetime.now(timezone.utc) - self.created_at).total_seconds()
        return None
    
    @validates('provider_event_id')
    def validate_provider_event_id(self, key: str, value: str) -> str:
        """Validate provider event ID based on source."""
        if not value or len(value) > 255:
            raise ValueError('Provider event ID must be between 1 and 255 characters')
        
        if self.source == WebhookSource.STRIPE:
            if not re.match(r'^evt_[a-zA-Z0-9]+$', value):
                raise ValueError('Invalid Stripe event ID format')
        
        return value.strip()
    
    @validates('type')
    def validate_type(self, key: str, value: str) -> str:
        """Validate event type format."""
        if not value or len(value) > 255:
            raise ValueError('Event type must be between 1 and 255 characters')
        
        # Basic validation for common patterns
        if not re.match(r'^[a-z][a-z0-9._-]*$', value.lower()):
            raise ValueError('Event type contains invalid characters')
        
        return value.strip()
    
    @validates('payload')
    def validate_payload(self, key: str, value: Dict[str, Any]) -> Dict[str, Any]:
        """Validate and sanitize payload."""
        if not isinstance(value, dict):
            raise ValueError('Payload must be a JSON object')
        
        if not value:
            raise ValueError('Payload cannot be empty')
        
        # Ensure payload doesn't exceed reasonable size
        import json
        payload_size = len(json.dumps(value))
        if payload_size > settings.MAX_WEBHOOK_PAYLOAD_SIZE:
            raise ValueError(f'Payload size ({payload_size}) exceeds maximum allowed')
        
        return value
    
    def mark_as_processing(self) -> None:
        """Transition event to processing state."""
        self.status = ProcessingStatus.PROCESSING
        self.updated_at = datetime.now(timezone.utc)
    
    def mark_as_success(self) -> None:
        """Mark event as successfully processed."""
        self.status = ProcessingStatus.SUCCESS
        self.processed_at = datetime.now(timezone.utc)
        self.updated_at = self.processed_at
        self.error_message = None
        self.error_details = None
    
    def mark_as_failed(self, error: Exception, retry_delay_minutes: int = 5) -> None:
        """
        Mark event as failed and schedule retry if applicable.
        
        Args:
            error: Exception that caused the failure
            retry_delay_minutes: Base delay for exponential backoff
        """
        from app.utils.error_handling import exception_to_dict
        
        self.status = ProcessingStatus.FAILED
        self.error_message = str(error)
        self.error_details = exception_to_dict(error)
        self.last_retry_at = datetime.now(timezone.utc)
        self.updated_at = self.last_retry_at
        
        if self.can_retry:
            self.schedule_retry(retry_delay_minutes)
    
    def schedule_retry(self, base_delay_minutes: int = 5) -> None:
        """Schedule next retry with exponential backoff."""
        import math
        from datetime import timedelta
        
        if not self.can_retry:
            return
        
        # Exponential backoff: base_delay * 2^retry_count
        delay_minutes = base_delay_minutes * (2 ** self.retry_count)
        delay_minutes = min(delay_minutes, 1440)  # Cap at 24 hours
        
        self.next_retry_at = datetime.now(timezone.utc) + timedelta(minutes=delay_minutes)
        self.status = ProcessingStatus.RETRY
        self.retry_count += 1
    
    def to_dict(self, include_payload: bool = True) -> Dict[str, Any]:
        """Convert model to dictionary for API responses."""
        result = {
            'id': str(self.id),
            'provider_event_id': self.provider_event_id,
            'source': self.source.value,
            'type': self.type,
            'status': self.status.value,
            'retry_count': self.retry_count,
            'max_retries': self.max_retries,
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'updated_at': self.updated_at.isoformat() if self.updated_at else None,
            'processed_at': self.processed_at.isoformat() if self.processed_at else None,
            'received_at': self.received_at.isoformat() if self.received_at else None,
            'is_test_event': self.is_test_event,
            'can_retry': self.can_retry,
            'age_seconds': self.age_seconds,
        }
        
        if include_payload:
            result['payload'] = self.payload
        
        if self.error_message:
            result['error'] = {
                'message': self.error_message,
                'details': self.error_details
            }
        
        return result
    
    def __repr__(self) -> str:
        """String representation for debugging."""
        return (f"<WebhookEvent(id={self.id}, source={self.source}, "
                f"type={self.type}, status={self.status}, "
                f"provider_id={self.provider_event_id})>")


# SQLAlchemy event listeners for additional functionality
@event.listens_for(WebhookEvent, 'before_insert')
def before_insert_listener(mapper, connection, target):
    """
    Pre-insert validation and enrichment.
    """
    # Ensure timestamps are timezone-aware
    if target.created_at and target.created_at.tzinfo is None:
        target.created_at = target.created_at.replace(tzinfo=timezone.utc)
    
    # Extract provider_event_id from payload if not provided
    if not target.provider_event_id and target.payload:
        if target.source == WebhookSource.STRIPE:
            target.provider_event_id = target.payload.get('id', '')
    
    # Extract metadata from payload
    if target.payload:
        if target.source == WebhookSource.STRIPE:
            target.api_version = target.payload.get('api_version')
            target.livemode = target.payload.get('livemode', True)


@event.listens_for(WebhookEvent, 'before_update')
def before_update_listener(mapper, connection, target):
    """
    Pre-update validation and automatic field updates.
    """
    # Ensure updated_at is always refreshed
    target.updated_at = datetime.now(timezone.utc)


# Create a typed dict for better type hints in consuming code
from typing import TypedDict

class WebhookEventDict(TypedDict, total=False):
    """Type definition for WebhookEvent data transfer."""
    id: str
    provider_event_id: str
    source: str
    type: str
    status: str
    payload: Dict[str, Any]
    created_at: str
    updated_at: str
    processed_at: str
    received_at: str
    error: Dict[str, Any]