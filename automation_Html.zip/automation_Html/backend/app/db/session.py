"""
Advanced database session management with automatic transaction handling.
Features:
- Automatic transaction management with rollback on exceptions
- Connection pooling with health checks
- Transaction context managers
- Metrics and observability
- Compatibility with existing Flask-SQLAlchemy setup
"""

from contextlib import contextmanager
from functools import wraps
from typing import Generator, Optional, Any, Callable
import logging
import time
from enum import Enum
from datetime import datetime

from sqlalchemy import create_engine, text, event
from sqlalchemy.orm import sessionmaker, Session
from sqlalchemy.pool import QueuePool, StaticPool
from sqlalchemy.exc import SQLAlchemyError, OperationalError
from prometheus_client import Counter, Histogram, Gauge

from app.core.config import settings

# Prometheus metrics
DB_QUERY_COUNT = Counter('db_queries_total', 'Total database queries', ['operation', 'status'])
DB_QUERY_DURATION = Histogram('db_query_duration_seconds', 'Database query duration', ['operation'])
DB_CONNECTIONS = Gauge('db_active_connections', 'Active database connections')
DB_TRANSACTIONS = Counter('db_transactions_total', 'Total database transactions', ['type', 'status'])

logger = logging.getLogger(__name__)

class TransactionType(str, Enum):
    """Transaction isolation levels and types"""
    READ_ONLY = "read_only"
    READ_WRITE = "read_write"
    NESTED = "nested"
    SERIALIZABLE = "serializable"

class DatabaseManager:
    """Manages database connections and sessions with advanced features"""
    
    def __init__(self):
        self.engine = None
        self.SessionLocal = None
        self._initialized = False
    
    def init_engine(self):
        """Initialize database engine with advanced configuration"""
        if self._initialized:
            return
        
        # Parse database URL for specific configurations
        db_url = settings.DATABASE_URL
        
        # Configure engine based on database type
        engine_kwargs = {
            "poolclass": QueuePool,
            "pool_size": getattr(settings, 'DATABASE_POOL_SIZE', 20),
            "max_overflow": getattr(settings, 'DATABASE_MAX_OVERFLOW', 40),
            "pool_timeout": getattr(settings, 'DATABASE_POOL_TIMEOUT', 30),
            "pool_recycle": getattr(settings, 'DATABASE_POOL_RECYCLE', 3600),
            "pool_pre_ping": getattr(settings, 'DATABASE_POOL_PRE_PING', True),
            "echo": getattr(settings, 'SQLALCHEMY_ECHO', False),
            "future": True,
        }
        
        # SQLite specific configuration
        if "sqlite" in db_url:
            engine_kwargs["connect_args"] = {"check_same_thread": False}
            engine_kwargs["poolclass"] = StaticPool
        
        # PostgreSQL specific configuration
        if "postgresql" in db_url:
            engine_kwargs["isolation_level"] = getattr(
                settings, 'DATABASE_ISOLATION_LEVEL', 'READ COMMITTED'
            )
            
            # Add statement timeout
            statement_timeout = getattr(settings, 'DATABASE_STATEMENT_TIMEOUT', 30000)
            @event.listens_for(self.engine, "connect")
            def set_statement_timeout(dbapi_connection, connection_record):
                cursor = dbapi_connection.cursor()
                cursor.execute(f"SET statement_timeout TO {statement_timeout}")
                cursor.close()
        
        self.engine = create_engine(db_url, **engine_kwargs)
        
        # Create session factory with advanced configuration
        self.SessionLocal = sessionmaker(
            autocommit=False,
            autoflush=False,
            bind=self.engine,
            expire_on_commit=False,  # Better for web applications
            class_=Session,
        )
        
        self._initialized = True
        logger.info(f"Database engine initialized: {db_url}")
        
        # Setup connection health check
        self._setup_health_check()
    
    def _setup_health_check(self):
        """Setup database health check endpoint"""
        @contextmanager
        def health_check():
            try:
                with self.engine.connect() as conn:
                    conn.execute(text("SELECT 1"))
                yield True
            except Exception as e:
                logger.error(f"Database health check failed: {e}")
                yield False
        
        self.health_check = health_check
    
    def get_session(self) -> Session:
        """Get a new database session"""
        if not self._initialized:
            self.init_engine()
        return self.SessionLocal()
    
    def dispose_pool(self):
        """Dispose connection pool (for graceful shutdown)"""
        if self.engine:
            self.engine.dispose()
            logger.info("Database connection pool disposed")

# Create global database manager instance
db_manager = DatabaseManager()

# Export for backward compatibility
engine = None  # Will be initialized when needed
SessionLocal = None  # Will be initialized when needed

def init_database():
    """Initialize database engine and session factory"""
    global engine, SessionLocal
    if engine is None or SessionLocal is None:
        db_manager.init_engine()
        engine = db_manager.engine
        SessionLocal = db_manager.SessionLocal
    return engine, SessionLocal

# Initialize on import
init_database()

class TransactionContext:
    """
    Advanced context manager for database transactions with automatic rollback.
    
    Example:
        with TransactionContext(db.session) as tx:
            # Do database operations
            user = User(name="John")
            db.session.add(user)
            # If an exception occurs here, transaction is rolled back automatically
    """
    
    def __init__(
        self,
        session: Session,
        transaction_type: TransactionType = TransactionType.READ_WRITE,
        rollback_on: Optional[Exception] = None,
        nested: bool = False
    ):
        self.session = session
        self.transaction_type = transaction_type
        self.rollback_on = rollback_on or (Exception, SQLAlchemyError)
        self.nested = nested
        self.transaction = None
        self.start_time = None
        
    def __enter__(self):
        self.start_time = time.time()
        DB_CONNECTIONS.inc()
        
        try:
            if self.nested:
                self.transaction = self.session.begin_nested()
            else:
                # Set transaction isolation level if supported
                if self.transaction_type == TransactionType.SERIALIZABLE:
                    self.session.execute(text("SET TRANSACTION ISOLATION LEVEL SERIALIZABLE"))
                elif self.transaction_type == TransactionType.READ_ONLY:
                    self.session.execute(text("SET TRANSACTION READ ONLY"))
                
                self.transaction = self.session.begin()
            
            DB_TRANSACTIONS.labels(type=self.transaction_type.value, status="started").inc()
            
            logger.debug(
                f"Transaction started: type={self.transaction_type}, "
                f"session_id={id(self.session)}"
            )
            
            return self
            
        except Exception as e:
            logger.error(f"Failed to start transaction: {e}")
            DB_CONNECTIONS.dec()
            raise
    
    def __exit__(self, exc_type, exc_val, exc_tb):
        duration = time.time() - self.start_time
        
        try:
            if exc_type is not None:
                # Check if this exception should trigger rollback
                should_rollback = any(
                    issubclass(exc_type, exc_class) 
                    for exc_class in self.rollback_on
                ) if self.rollback_on else True
                
                if should_rollback:
                    self.session.rollback()
                    DB_TRANSACTIONS.labels(type=self.transaction_type.value, status="rolled_back").inc()
                    logger.warning(
                        f"Transaction rolled back due to {exc_type.__name__}: "
                        f"{exc_val}, duration={duration:.3f}s"
                    )
                else:
                    # Exception not in rollback list, try to commit
                    try:
                        self.session.commit()
                        DB_TRANSACTIONS.labels(type=self.transaction_type.value, status="committed").inc()
                        logger.info(
                            f"Transaction committed despite {exc_type.__name__}, "
                            f"duration={duration:.3f}s"
                        )
                    except Exception as commit_error:
                        logger.error(f"Commit failed after exception: {commit_error}")
                        self.session.rollback()
                        DB_TRANSACTIONS.labels(type=self.transaction_type.value, status="rolled_back").inc()
            else:
                # No exception, commit transaction
                self.session.commit()
                DB_TRANSACTIONS.labels(type=self.transaction_type.value, status="committed").inc()
                logger.debug(
                    f"Transaction committed successfully, duration={duration:.3f}s"
                )
                
        except SQLAlchemyError as e:
            logger.error(f"Error during transaction finalization: {e}")
            try:
                self.session.rollback()
            except:
                pass
            DB_TRANSACTIONS.labels(type=self.transaction_type.value, status="failed").inc()
            raise
        finally:
            DB_CONNECTIONS.dec()
            if self.transaction:
                try:
                    self.transaction.close()
                except:
                    pass
    
    def savepoint(self, name: str = None):
        """Create a savepoint within the transaction"""
        return self.session.begin_nested()

@contextmanager
def get_db_session(
    transaction_type: TransactionType = TransactionType.READ_WRITE,
    auto_commit: bool = True,
    **kwargs
) -> Generator[Session, None, None]:
    """
    Advanced database session context manager with automatic transaction handling.
    
    Args:
        transaction_type: Type of transaction isolation
        auto_commit: Whether to auto-commit on successful completion
        **kwargs: Additional arguments for TransactionContext
    
    Yields:
        SQLAlchemy Session object
    
    Example:
        with get_db_session() as db:
            user = db.query(User).first()
            user.name = "Updated"
            # Auto-committed on successful exit
    """
    session = SessionLocal()
    DB_CONNECTIONS.inc()
    
    try:
        with TransactionContext(session, transaction_type, **kwargs):
            yield session
            
            if auto_commit and session.is_active:
                session.commit()
                
    except SQLAlchemyError as e:
        logger.error(f"Database error: {e}")
        if session.is_active:
            try:
                session.rollback()
            except:
                pass
        DB_TRANSACTIONS.labels(type=transaction_type.value, status="error").inc()
        raise
    except Exception as e:
        logger.error(f"Unexpected error in database session: {e}")
        if session.is_active:
            try:
                session.rollback()
            except:
                pass
        DB_TRANSACTIONS.labels(type=transaction_type.value, status="error").inc()
        raise
    finally:
        try:
            session.close()
        except:
            pass
        DB_CONNECTIONS.dec()

def transactional(
    transaction_type: TransactionType = TransactionType.READ_WRITE,
    retry_on_deadlock: int = 0,
    retry_on_operational_error: bool = False,
    max_retry_delay: float = 5.0,
    **context_kwargs
):
    """
    Decorator for wrapping functions in a database transaction.
    
    Args:
        transaction_type: Type of transaction isolation
        retry_on_deadlock: Number of retries on deadlock detection
        retry_on_operational_error: Whether to retry on operational errors
        max_retry_delay: Maximum delay between retries in seconds
        **context_kwargs: Additional arguments for TransactionContext
    
    Example:
        @transactional(retry_on_deadlock=3)
        def update_user(user_id: int, data: dict, db: Session):
            user = db.query(User).get(user_id)
            # ... update logic
    
    Usage with Flask routes:
        @app.route("/update", methods=["POST"])
        @transactional()
        def update():
            db = g.db  # Session injected by before_request
            # ... update logic
    """
    def decorator(func: Callable):
        @wraps(func)
        def wrapper(*args, **kwargs):
            retry_count = 0
            last_error = None
            max_retries = retry_on_deadlock
            
            if retry_on_operational_error:
                max_retries = max(max_retries, 2)  # At least 2 retries for operational errors
            
            while retry_count <= max_retries:
                try:
                    with get_db_session(transaction_type, **context_kwargs) as db:
                        # Inject db session if function expects it
                        import inspect
                        sig = inspect.signature(func)
                        params = list(sig.parameters.keys())
                        
                        if 'db' in params:
                            kwargs['db'] = db
                        elif 'session' in params:
                            kwargs['session'] = db
                        
                        result = func(*args, **kwargs)
                        return result
                        
                except OperationalError as e:
                    error_str = str(e).lower()
                    
                    # Check for deadlock
                    is_deadlock = "deadlock" in error_str or "dead lock" in error_str
                    is_retryable = is_deadlock or (retry_on_operational_error and "operational" in error_str)
                    
                    if is_retryable and retry_count < max_retries:
                        retry_count += 1
                        last_error = e
                        
                        # Exponential backoff with jitter
                        delay = min(0.1 * (2 ** retry_count), max_retry_delay)
                        jitter = delay * 0.1  # 10% jitter
                        actual_delay = delay + (jitter * (retry_count - 1))
                        
                        logger.warning(
                            f"Database error detected, retry {retry_count}/{max_retries} "
                            f"in {actual_delay:.2f}s: {error_str}"
                        )
                        
                        time.sleep(actual_delay)
                        continue
                    
                    logger.error(f"Database operational error (not retrying): {e}")
                    raise
                    
                except Exception as e:
                    if retry_count < max_retries:
                        retry_count += 1
                        last_error = e
                        
                        delay = min(0.1 * (2 ** retry_count), max_retry_delay)
                        logger.warning(
                            f"Transaction failed, retry {retry_count}/{max_retries} "
                            f"in {delay:.2f}s: {e}"
                        )
                        
                        time.sleep(delay)
                        continue
                    
                    logger.error(f"Transaction failed after {retry_count} retries: {e}")
                    raise
            
            if last_error:
                logger.error(f"All retries failed: {last_error}")
                raise last_error
        
        return wrapper
    return decorator

class DatabaseHealth:
    """Database health monitoring and metrics"""
    
    @staticmethod
    def check_health() -> dict:
        """Perform comprehensive database health check"""
        try:
            start = time.time()
            
            with engine.connect() as conn:
                # Check connection and basic query
                result = conn.execute(text("SELECT 1")).scalar()
                
                # Get database version
                version_result = conn.execute(text("SELECT version()")).scalar()
                
                # Get connection pool stats
                pool = engine.pool
                
                latency = time.time() - start
                
                return {
                    "status": "healthy" if result == 1 else "unhealthy",
                    "latency": round(latency, 4),
                    "database_version": str(version_result) if version_result else "unknown",
                    "pool_size": pool.size() if hasattr(pool, 'size') else None,
                    "checked_in": pool.checkedin() if hasattr(pool, 'checkedin') else None,
                    "checked_out": pool.checkedout() if hasattr(pool, 'checkedout') else None,
                    "overflow": pool.overflow() if hasattr(pool, 'overflow') else None,
                    "timestamp": datetime.utcnow().isoformat()
                }
                
        except Exception as e:
            logger.error(f"Database health check failed: {e}")
            return {
                "status": "unhealthy",
                "error": str(e),
                "timestamp": datetime.utcnow().isoformat()
            }
    
    @staticmethod
    def get_metrics() -> dict:
        """Get database performance metrics"""
        try:
            return {
                "active_connections": DB_CONNECTIONS._value.get() if hasattr(DB_CONNECTIONS, '_value') else 0,
                "total_queries": DB_QUERY_COUNT._value.get() if hasattr(DB_QUERY_COUNT, '_value') else 0,
                "transactions": {
                    "started": DB_TRANSACTIONS._metrics.get(('type', 'read_write', 'status', 'started'), 0),
                    "committed": DB_TRANSACTIONS._metrics.get(('type', 'read_write', 'status', 'committed'), 0),
                    "rolled_back": DB_TRANSACTIONS._metrics.get(('type', 'read_write', 'status', 'rolled_back'), 0),
                }
            }
        except:
            return {}

# Flask-specific integration
def setup_flask_db(app):
    """
    Setup database for Flask application with transaction support.
    Call this in your Flask app factory.
    """
    # Initialize database
    init_database()
    
    @app.before_request
    def setup_db_session():
        """Setup database session for each request"""
        from flask import g
        
        # Create session and store in g
        g.db = SessionLocal()
        
        # Start transaction context
        g.db_transaction = TransactionContext(
            g.db,
            transaction_type=TransactionType.READ_WRITE
        )
        g.db_transaction.__enter__()
        
        logger.debug(f"Database session started for request {g.get('request_id', 'unknown')}")
    
    @app.teardown_request
    def teardown_db_session(exception=None):
        """Teardown database session after each request"""
        from flask import g
        
        if hasattr(g, 'db_transaction'):
            try:
                # Handle transaction based on whether an exception occurred
                if exception:
                    g.db_transaction.rollback_on = (Exception,)
                g.db_transaction.__exit__(
                    type(exception) if exception else None,
                    exception,
                    None
                )
            except Exception as e:
                logger.error(f"Error during transaction teardown: {e}")
            finally:
                delattr(g, 'db_transaction')
        
        if hasattr(g, 'db'):
            try:
                g.db.close()
            except Exception as e:
                logger.error(f"Error closing database session: {e}")
            finally:
                delattr(g, 'db')
        
        logger.debug(f"Database session cleaned up for request {g.get('request_id', 'unknown')}")
    
    # Add health check endpoint
    @app.route('/api/db/health')
    def db_health_check():
        """Database health check endpoint"""
        health_data = DatabaseHealth.check_health()
        status_code = 200 if health_data.get('status') == 'healthy' else 503
        return {
            'database': health_data,
            'service': app.config.get('APP_NAME', 'flask-app'),
            'timestamp': datetime.utcnow().isoformat()
        }, status_code
    
    logger.info("Database transaction management setup complete")
    return app

# Export for backward compatibility and common use
__all__ = [
    "engine",
    "SessionLocal",
    "get_db_session",
    "transactional",
    "TransactionContext",
    "TransactionType",
    "DatabaseHealth",
    "setup_flask_db",
    "db_manager"
]