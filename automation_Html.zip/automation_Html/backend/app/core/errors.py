"""
Advanced Error Handling System
Professional-grade error handling with structured logging and monitoring integration.
"""

import traceback
import sys
import json
import time
from typing import Dict, Any, Optional, Type, Union, Callable
from dataclasses import dataclass, asdict
from enum import Enum
from functools import wraps

from flask import Flask, request, jsonify, Response, g, current_app
from werkzeug.exceptions import HTTPException, default_exceptions
import sentry_sdk
from sentry_sdk import capture_exception, add_breadcrumb

# Error categories for classification
class ErrorCategory(Enum):
    """Categorize errors for better monitoring and handling."""
    VALIDATION = "validation"
    AUTHENTICATION = "authentication"
    AUTHORIZATION = "authorization"
    NOT_FOUND = "not_found"
    RATE_LIMIT = "rate_limit"
    DATABASE = "database"
    EXTERNAL_SERVICE = "external_service"
    INTEGRATION = "integration"
    BUSINESS_LOGIC = "business_logic"
    PAYMENT = "payment"
    CONFIGURATION = "configuration"
    NETWORK = "network"
    SECURITY = "security"
    UNKNOWN = "unknown"
    DEPRECATED = "deprecated"


@dataclass
class ErrorContext:
    """Structured error context for better debugging."""
    request_id: Optional[str] = None
    user_id: Optional[str] = None
    user_role: Optional[str] = None
    ip_address: Optional[str] = None
    user_agent: Optional[str] = None
    endpoint: Optional[str] = None
    method: Optional[str] = None
    params: Optional[Dict[str, Any]] = None
    headers: Optional[Dict[str, str]] = None
    client_version: Optional[str] = None
    environment: Optional[str] = None
    timestamp: float = None
    
    def __post_init__(self):
        if self.timestamp is None:
            self.timestamp = time.time()
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary for serialization."""
        result = asdict(self)
        result['timestamp_iso'] = time.strftime(
            '%Y-%m-%dT%H:%M:%SZ', time.gmtime(self.timestamp)
        )
        return result


class AppError(Exception):
    """Base application error with structured data."""
    
    def __init__(
        self,
        message: str,
        code: str = "INTERNAL_ERROR",
        status_code: int = 500,
        category: ErrorCategory = ErrorCategory.UNKNOWN,
        details: Optional[Dict[str, Any]] = None,
        user_message: Optional[str] = None,
        retryable: bool = False,
        log_level: str = "error",
        context: Optional[ErrorContext] = None
    ):
        super().__init__(message)
        self.message = message
        self.code = code
        self.status_code = status_code
        self.category = category
        self.details = details or {}
        self.user_message = user_message or "An unexpected error occurred"
        self.retryable = retryable
        self.log_level = log_level
        self.context = context or ErrorContext()
        self.timestamp = time.time()
        
        # Capture stack trace
        self.stack_trace = traceback.format_exc()
    
    def to_dict(self, include_debug: bool = False) -> Dict[str, Any]:
        """Convert error to API response dictionary."""
        result = {
            "error": {
                "code": self.code,
                "message": self.user_message if not include_debug else self.message,
                "category": self.category.value,
                "timestamp": self.timestamp,
                "request_id": self.context.request_id,
                "retryable": self.retryable
            }
        }
        
        if include_debug:
            result["error"]["debug"] = {
                "original_message": self.message,
                "stack_trace": self.stack_trace if include_debug else None,
                "details": self.details,
                "context": self.context.to_dict()
            }
        
        return result
    
    def __str__(self) -> str:
        return f"{self.code}: {self.message} [{self.category.value}]"


class ValidationError(AppError):
    """Validation error with field-specific details."""
    
    def __init__(
        self,
        message: str,
        field_errors: Optional[Dict[str, str]] = None,
        **kwargs
    ):
        super().__init__(
            message=message,
            code="VALIDATION_ERROR",
            status_code=400,
            category=ErrorCategory.VALIDATION,
            details={"field_errors": field_errors or {}},
            user_message="Invalid input data",
            **kwargs
        )


class AuthenticationError(AppError):
    """Authentication-related errors."""
    
    def __init__(self, message: str, **kwargs):
        super().__init__(
            message=message,
            code="AUTHENTICATION_FAILED",
            status_code=401,
            category=ErrorCategory.AUTHENTICATION,
            user_message="Authentication required or invalid credentials",
            **kwargs
        )


class AuthorizationError(AppError):
    """Authorization-related errors."""
    
    def __init__(self, message: str, required_permissions=None, **kwargs):
        super().__init__(
            message=message,
            code="PERMISSION_DENIED",
            status_code=403,
            category=ErrorCategory.AUTHORIZATION,
            details={"required_permissions": required_permissions or []},
            user_message="You don't have permission to perform this action",
            **kwargs
        )


class NotFoundError(AppError):
    """Resource not found errors."""
    
    def __init__(self, resource_type: str, resource_id: str, **kwargs):
        super().__init__(
            message=f"{resource_type} with ID '{resource_id}' not found",
            code="RESOURCE_NOT_FOUND",
            status_code=404,
            category=ErrorCategory.NOT_FOUND,
            details={
                "resource_type": resource_type,
                "resource_id": resource_id
            },
            user_message="The requested resource was not found",
            **kwargs
        )


class RateLimitError(AppError):
    """Rate limiting errors."""
    
    def __init__(self, limit: int, window: int, retry_after: int, **kwargs):
        super().__init__(
            message=f"Rate limit exceeded: {limit} requests per {window} seconds",
            code="RATE_LIMIT_EXCEEDED",
            status_code=429,
            category=ErrorCategory.RATE_LIMIT,
            details={
                "limit": limit,
                "window": window,
                "retry_after": retry_after
            },
            user_message="Too many requests. Please try again later.",
            retryable=True,
            **kwargs
        )


class DatabaseError(AppError):
    """Database-related errors."""
    
    def __init__(self, message: str, operation: str, query: Optional[str] = None, **kwargs):
        super().__init__(
            message=message,
            code="DATABASE_ERROR",
            status_code=500,
            category=ErrorCategory.DATABASE,
            details={
                "operation": operation,
                "query": query
            },
            user_message="Database operation failed",
            **kwargs
        )


class ExternalServiceError(AppError):
    """External service integration errors."""
    
    def __init__(
        self,
        service_name: str,
        endpoint: str,
        status_code: int,
        response: Optional[str] = None,
        **kwargs
    ):
        super().__init__(
            message=f"Service {service_name} failed at {endpoint}: {status_code}",
            code="EXTERNAL_SERVICE_ERROR",
            status_code=502 if status_code >= 500 else 424,
            category=ErrorCategory.EXTERNAL_SERVICE,
            details={
                "service_name": service_name,
                "endpoint": endpoint,
                "service_status_code": status_code,
                "response": response[:500] if response else None
            },
            user_message="External service temporarily unavailable",
            retryable=True,
            **kwargs
        )


class PaymentError(AppError):
    """Payment processing errors."""
    
    def __init__(
        self,
        message: str,
        provider: str,
        transaction_id: Optional[str] = None,
        user_action_required: bool = False,
        **kwargs
    ):
        super().__init__(
            message=message,
            code="PAYMENT_ERROR",
            status_code=402,
            category=ErrorCategory.PAYMENT,
            details={
                "provider": provider,
                "transaction_id": transaction_id,
                "user_action_required": user_action_required
            },
            user_message="Payment processing failed",
            **kwargs
        )


class ConfigurationError(AppError):
    """Configuration-related errors."""
    
    def __init__(self, message: str, config_key: Optional[str] = None, **kwargs):
        super().__init__(
            message=message,
            code="CONFIGURATION_ERROR",
            status_code=500,
            category=ErrorCategory.CONFIGURATION,
            details={"config_key": config_key},
            user_message="Configuration error",
            **kwargs
        )


def get_error_context() -> ErrorContext:
    """Extract error context from Flask request context."""
    return ErrorContext(
        request_id=getattr(g, "request_id", None),
        user_id=getattr(g, "user_id", None),
        user_role=getattr(g, "user_role", None),
        ip_address=request.remote_addr if request else None,
        user_agent=request.user_agent.string if request and request.user_agent else None,
        endpoint=request.path if request else None,
        method=request.method if request else None,
        params={
            "query": dict(request.args) if request else {},
            "json": request.get_json(silent=True) if request else None
        } if request else None,
        headers=dict(request.headers) if request else {},
        client_version=request.headers.get("X-Client-Version") if request else None,
        environment=current_app.config.get("ENVIRONMENT") if current_app else None
    )


def create_error_response(
    error: AppError,
    include_debug: bool = False
) -> Response:
    """Create Flask response from AppError."""
    include_debug = include_debug or current_app.config.get("DEBUG", False)
    
    response = jsonify(error.to_dict(include_debug=include_debug))
    response.status_code = error.status_code
    
    # Add helpful headers
    response.headers["X-Error-Code"] = error.code
    response.headers["X-Error-Category"] = error.category.value
    response.headers["X-Retryable"] = str(error.retryable).lower()
    
    if error.retryable and hasattr(error.details, "get"):
        if retry_after := error.details.get("retry_after"):
            response.headers["Retry-After"] = str(retry_after)
    
    return response


def log_error(error: AppError, exc_info: bool = True) -> None:
    """Log error with structured context."""
    logger = current_app.logger if current_app else logging.getLogger(__name__)
    
    log_data = {
        "error_code": error.code,
        "error_message": error.message,
        "error_category": error.category.value,
        "status_code": error.status_code,
        "retryable": error.retryable,
        "request_id": error.context.request_id,
        "user_id": error.context.user_id,
        "endpoint": error.context.endpoint,
        "method": error.context.method,
        "timestamp": error.timestamp,
        "stack_trace": error.stack_trace if exc_info else None,
        "details": error.details
    }
    
    # Send to Sentry
    if current_app and current_app.config.get("SENTRY_DSN"):
        try:
            sentry_sdk.set_context("error", log_data)
            sentry_sdk.set_tag("error_code", error.code)
            sentry_sdk.set_tag("error_category", error.category.value)
            sentry_sdk.set_tag("retryable", error.retryable)
            capture_exception(error)
        except Exception as sentry_error:
            logger.error(f"Failed to send error to Sentry: {sentry_error}")
    
    # Log based on error level
    log_method = getattr(logger, error.log_level, logger.error)
    log_method(f"{error.code}: {error.message}", extra=log_data, exc_info=exc_info)


def handle_http_exception(error: HTTPException) -> Response:
    """Handle Werkzeug HTTP exceptions."""
    app_error = AppError(
        message=error.description or "HTTP Error",
        code=f"HTTP_{error.code}",
        status_code=error.code,
        category=ErrorCategory.UNKNOWN,
        user_message=error.description or "An error occurred",
        context=get_error_context()
    )
    
    log_error(app_error, exc_info=False)
    return create_error_response(app_error)


def handle_app_error(error: AppError) -> Response:
    """Handle custom AppError exceptions."""
    log_error(error)
    return create_error_response(error)


def handle_unhandled_exception(error: Exception) -> Response:
    """Handle unhandled/unexpected exceptions."""
    # Create a generic app error
    app_error = AppError(
        message=str(error) or "Unexpected error",
        code="INTERNAL_SERVER_ERROR",
        status_code=500,
        category=ErrorCategory.UNKNOWN,
        user_message="An unexpected error occurred. Our team has been notified.",
        details={
            "exception_type": type(error).__name__,
            "module": error.__class__.__module__
        },
        context=get_error_context()
    )
    
    # Log with full stack trace
    current_app.logger.critical(
        "unhandled_exception",
        extra={
            "error_message": str(error),
            "exception_type": type(error).__name__,
            "stack_trace": traceback.format_exc(),
            "request_id": app_error.context.request_id,
            "endpoint": app_error.context.endpoint,
            "method": app_error.context.method
        },
        exc_info=True
    )
    
    # Send to Sentry
    if current_app and current_app.config.get("SENTRY_DSN"):
        try:
            capture_exception(error)
        except Exception as sentry_error:
            current_app.logger.error(f"Failed to send error to Sentry: {sentry_error}")
    
    return create_error_response(app_error)


def handle_validation_error(error: ValidationError) -> Response:
    """Handle validation errors with field details."""
    log_error(error, exc_info=False)
    
    # Enhance response with field errors
    response = create_error_response(error)
    
    # Add field errors to response if available
    if error.details.get("field_errors"):
        response_data = response.get_json()
        response_data["error"]["field_errors"] = error.details["field_errors"]
        response.set_data(json.dumps(response_data))
    
    return response


def error_handler_decorator(func: Callable) -> Callable:
    """Decorator to wrap route handlers with error handling."""
    @wraps(func)
    def wrapper(*args, **kwargs):
        try:
            return func(*args, **kwargs)
        except AppError as e:
            # Re-raise AppError to be caught by global handler
            raise
        except HTTPException as e:
            # Convert HTTPException to AppError
            raise AppError(
                message=e.description or "HTTP Error",
                code=f"HTTP_{e.code}",
                status_code=e.code,
                user_message=e.description or "An error occurred",
                context=get_error_context()
            )
        except Exception as e:
            # Wrap unexpected exceptions in AppError
            current_app.logger.error(
                "unexpected_error_in_handler",
                extra={
                    "handler": func.__name__,
                    "error": str(e),
                    "exception_type": type(e).__name__
                },
                exc_info=True
            )
            raise AppError(
                message=str(e),
                code="UNEXPECTED_ERROR",
                status_code=500,
                user_message="An unexpected error occurred",
                context=get_error_context()
            )
    return wrapper


def register_error_handlers(app: Flask) -> None:
    """
    Register all error handlers with the Flask application.
    
    This function should be called in create_app() after app initialization.
    """
    # Register handlers for custom AppError and subclasses
    app.register_error_handler(AppError, handle_app_error)
    app.register_error_handler(ValidationError, handle_validation_error)
    
    # Register handler for all Werkzeug HTTP exceptions
    for code in default_exceptions:
        app.register_error_handler(code, handle_http_exception)
    
    # Register global exception handler for unhandled exceptions
    @app.errorhandler(Exception)
    def handle_generic_exception(error: Exception) -> Response:
        if isinstance(error, HTTPException):
            return handle_http_exception(error)
        elif isinstance(error, AppError):
            return handle_app_error(error)
        else:
            return handle_unhandled_exception(error)
    
    # Middleware to catch unhandled exceptions at WSGI level
    original_wsgi_app = app.wsgi_app
    
    def wsgi_wrapper(environ, start_response):
        try:
            return original_wsgi_app(environ, start_response)
        except Exception as error:
            if not isinstance(error, (HTTPException, AppError)):
                # Log unhandled WSGI-level exception
                app.logger.critical(
                    "wsgi_level_exception",
                    extra={
                        "error": str(error),
                        "exception_type": type(error).__name__,
                        "path": environ.get('PATH_INFO'),
                        "method": environ.get('REQUEST_METHOD')
                    },
                    exc_info=True
                )
                
                # Send to Sentry
                if app.config.get("SENTRY_DSN"):
                    try:
                        capture_exception(error)
                    except:
                        pass
                
                # Return generic error response
                start_response('500 Internal Server Error', [
                    ('Content-Type', 'application/json'),
                    ('X-Error-Code', 'INTERNAL_SERVER_ERROR'),
                    ('X-Error-Category', 'unknown')
                ])
                
                error_response = {
                    "error": {
                        "code": "INTERNAL_SERVER_ERROR",
                        "message": "Internal server error" if not app.debug else str(error),
                        "request_id": environ.get('HTTP_X_REQUEST_ID'),
                        "timestamp": time.time()
                    }
                }
                
                return [json.dumps(error_response).encode()]
            raise
    
    app.wsgi_app = wsgi_wrapper
    
    app.logger.info(
        "error_handlers_registered",
        extra={
            "custom_handlers": True,
            "http_handlers": len(default_exceptions),
            "global_handler": True,
            "wsgi_wrapper": True
        }
    )


# Context manager for error handling in blocks of code
@contextmanager
def error_context(
    operation: str,
    category: ErrorCategory = ErrorCategory.UNKNOWN,
    raise_as: Optional[Type[AppError]] = None,
    **context_kwargs
):
    """
    Context manager for wrapping operations with error handling.
    
    Example:
        with error_context("process_payment", ErrorCategory.PAYMENT):
            process_payment()
    """
    try:
        yield
    except AppError:
        # Re-raise AppError as-is
        raise
    except Exception as e:
        error_context = get_error_context()
        error_context.__dict__.update(context_kwargs)
        
        app_error = AppError(
            message=f"Error in {operation}: {str(e)}",
            code=f"OPERATION_FAILED_{operation.upper()}",
            status_code=500,
            category=category,
            context=error_context,
            details={"operation": operation}
        )
        
        if raise_as:
            raise raise_as(
                message=app_error.message,
                context=app_error.context,
                details=app_error.details
            )
        else:
            raise app_error


# Utility function to create standardized error responses
def create_error(
    message: str,
    code: str = "INTERNAL_ERROR",
    status_code: int = 500,
    category: ErrorCategory = ErrorCategory.UNKNOWN,
    details: Optional[Dict[str, Any]] = None,
    user_message: Optional[str] = None,
    retryable: bool = False,
    log_level: str = "error"
) -> AppError:
    """Helper function to create AppError instances."""
    return AppError(
        message=message,
        code=code,
        status_code=status_code,
        category=category,
        details=details,
        user_message=user_message,
        retryable=retryable,
        log_level=log_level,
        context=get_error_context()
    )