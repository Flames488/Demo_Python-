# In your app factory (e.g., app/__init__.py)
from flask import Flask
from core.logging import init_app

def create_app():
    app = Flask(__name__)
    
    # Configure logging
    init_app(app)
    
    return app