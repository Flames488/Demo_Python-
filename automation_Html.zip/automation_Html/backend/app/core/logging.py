# 📁 core/logging.py
"""
Advanced Structured Logging System
Professional-grade logging with context propagation, structured output, and monitoring integration.
"""

import sys
import json
import time
import logging
import logging.config
import threading
from datetime import datetime
from typing import Dict, Any, Optional, Union, List, Callable
from dataclasses import dataclass, asdict, field
from enum import Enum
from functools import wraps
from pathlib import Path

from flask import Flask, request, g, current_app, has_request_context
import structlog
from structlog import get_logger as structlog_get_logger, configure
from structlog.processors import (
    JSONRenderer,
    TimeStamper,
    add_log_level,
    StackInfoRenderer,
    format_exc_info,
    UnicodeDecoder,
)
from structlog.stdlib import (
    add_logger_name,
    filter_by_level,
    BoundLogger,
    LoggerFactory,
)
from structlog.threadlocal import wrap_dict, tmp_bind

# ==================== FIX: ADD CENTRALIZED CONFIGURATION ====================
# This ensures basic logging works even before Flask app initialization
def setup_basic_logging(level=logging.INFO):
    """Set up basic logging configuration for immediate use."""
    logging.basicConfig(
        level=level,
        format="%(asctime)s | %(levelname)s | %(name)s | %(message)s",
        datefmt="%Y-%m-%d %H:%M:%S",
        handlers=[
            logging.StreamHandler(sys.stdout)
        ]
    )

# Initialize basic logging immediately
setup_basic_logging()

# ==================== END FIX ====================

# Logging levels with numerical values
class LogLevel(Enum):
    DEBUG = 10
    INFO = 20
    WARNING = 30
    ERROR = 40
    CRITICAL = 50

# Log categories for better filtering and analysis
class LogCategory(Enum):
    REQUEST = "request"
    RESPONSE = "response"
    DATABASE = "database"
    SERVICE = "service"
    AUTH = "auth"
    SECURITY = "security"
    BUSINESS = "business"
    PERFORMANCE = "performance"
    AUDIT = "audit"
    SYSTEM = "system"
    ERROR = "error"
    INTEGRATION = "integration"

@dataclass
class LogContext:
    """Centralized logging context with all required metadata."""
    request_id: Optional[str] = None
    user_id: Optional[str] = None
    user_role: Optional[str] = None
    route: Optional[str] = None
    endpoint: Optional[str] = None
    method: Optional[str] = None
    ip_address: Optional[str] = None
    user_agent: Optional[str] = None
    correlation_id: Optional[str] = None
    session_id: Optional[str] = None
    client_version: Optional[str] = None
    environment: Optional[str] = None
    deployment_id: Optional[str] = None
    service_name: Optional[str] = None
    component: Optional[str] = None
    operation: Optional[str] = None
    duration_ms: Optional[float] = None
    timestamp: float = field(default_factory=time.time)
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary with ISO timestamp."""
        result = asdict(self)
        result['timestamp_iso'] = datetime.utcfromtimestamp(self.timestamp).isoformat() + 'Z'
        return {k: v for k, v in result.items() if v is not None}

class StructuredLogger:
    """Advanced structured logger with context management."""
    
    _context = threading.local()
    
    def __init__(self, app: Optional[Flask] = None):
        self.app = app
        self._logger = None
        self._initialized = False
        
        if app:
            self.init_app(app)
        else:
            # Initialize a basic logger for module-level use
            self._initialize_basic()
    
    def _initialize_basic(self):
        """Initialize basic logging for module-level use."""
        self._logger = logging.getLogger(__name__)
        self._initialized = True
    
    def init_app(self, app: Flask):
        """Initialize logging with Flask application."""
        if self._initialized:
            return
        
        self.app = app
        
        # Configuration from app config
        config = {
            'version': 1,
            'disable_existing_loggers': False,
            'formatters': {
                'json': {
                    '()': 'core.logging.JSONFormatter',
                    'format': '%(message)s',
                },
                'console': {
                    'format': '%(asctime)s | %(levelname)s | %(name)s | %(message)s'
                }
            },
            'handlers': {
                'console': {
                    'class': 'logging.StreamHandler',
                    'formatter': 'console' if app.debug else 'json',
                    'stream': sys.stdout,
                },
                'file': {
                    'class': 'logging.handlers.RotatingFileHandler',
                    'filename': app.config.get('LOG_FILE', 'app.log'),
                    'formatter': 'json',
                    'maxBytes': 10485760,  # 10MB
                    'backupCount': 5,
                }
            },
            'loggers': {
                '': {  # Root logger
                    'level': app.config.get('LOG_LEVEL', 'INFO'),
                    'handlers': ['console', 'file'] if app.config.get('LOG_TO_FILE', True) else ['console'],
                    'propagate': False,
                },
                'werkzeug': {
                    'level': 'WARNING',  # Reduce noise from Werkzeug
                    'handlers': ['console'],
                    'propagate': False,
                },
            }
        }
        
        # Apply configuration
        logging.config.dictConfig(config)
        
        # Configure structlog
        processors = [
            filter_by_level,
            add_log_level,
            add_logger_name,
            TimeStamper(fmt="iso", key="timestamp", utc=True),
            StackInfoRenderer(),
            format_exc_info,
            self._add_context_processor,
            UnicodeDecoder(),
        ]
        
        if not app.debug:
            processors.append(JSONRenderer())
        
        configure(
            processors=processors,
            context_class=wrap_dict(dict),
            logger_factory=LoggerFactory(),
            wrapper_class=BoundLogger,
            cache_logger_on_first_use=True,
        )
        
        self._logger = structlog_get_logger(app.name)
        self._initialized = True
        
        # Add request context middleware
        @app.before_request
        def before_request_logging():
            self._start_request_context()
        
        @app.after_request
        def after_request_logging(response):
            self._log_request_completion(response)
            return response
        
        app.logger.info("logging_system_initialized", extra={
            "service": app.name,
            "environment": app.config.get('ENV', 'unknown'),
            "log_level": app.config.get('LOG_LEVEL', 'INFO'),
            "structured": True
        })
    
    def _add_context_processor(self, logger, method_name, event_dict):
        """Add context to all log events."""
        # Add thread-local context
        if hasattr(self._context, 'data'):
            event_dict.update(self._context.data)
        
        # Add Flask request context if available
        if has_request_context():
            context = self._extract_request_context()
            event_dict.update(context)
        
        # Add static context from app config
        event_dict.update({
            "service": self.app.name if self.app else "unknown",
            "environment": self.app.config.get('ENV', 'unknown') if self.app else "unknown",
            "deployment_id": self.app.config.get('DEPLOYMENT_ID') if self.app else None,
        })
        
        return event_dict
    
    def _extract_request_context(self) -> Dict[str, Any]:
        """Extract context from Flask request."""
        if not has_request_context():
            return {}
        
        return {
            "request_id": getattr(g, 'request_id', None),
            "user_id": getattr(g, 'user_id', None),
            "user_role": getattr(g, 'user_role', None),
            "route": request.endpoint,
            "endpoint": request.path,
            "method": request.method,
            "ip_address": request.remote_addr,
            "user_agent": request.user_agent.string if request.user_agent else None,
            "client_version": request.headers.get('X-Client-Version'),
            "correlation_id": request.headers.get('X-Correlation-ID'),
        }
    
    def _start_request_context(self):
        """Initialize context for the current request."""
        if not has_request_context():
            return
        
        # Set basic request context
        self.set_context(
            request_id=getattr(g, 'request_id', None),
            endpoint=request.path,
            method=request.method,
            ip_address=request.remote_addr,
        )
        
        # Log request start
        self.info(
            "request_started",
            category=LogCategory.REQUEST,
            extra={
                "url": request.url,
                "headers": dict(request.headers),
                "query_params": dict(request.args),
            }
        )
    
    def _log_request_completion(self, response):
        """Log request completion with timing."""
        if not has_request_context():
            return
        
        # Get start time if stored
        start_time = getattr(g, 'request_start_time', None)
        duration_ms = None
        
        if start_time:
            duration_ms = (time.time() - start_time) * 1000
        
        self.info(
            "request_completed",
            category=LogCategory.RESPONSE,
            extra={
                "status_code": response.status_code,
                "response_size": response.calculate_content_length(),
                "duration_ms": duration_ms,
                "route": request.endpoint,
            }
        )
    
    def set_context(self, **kwargs):
        """Set thread-local logging context."""
        if not hasattr(self._context, 'data'):
            self._context.data = {}
        self._context.data.update(kwargs)
    
    def clear_context(self):
        """Clear thread-local logging context."""
        if hasattr(self._context, 'data'):
            self._context.data.clear()
    
    def bind_context(self, **kwargs):
        """Return a context manager that temporarily adds to the context."""
        return tmp_bind(self._logger, **kwargs)
    
    def _log(
        self,
        level: LogLevel,
        event: str,
        category: LogCategory,
        error_type: Optional[str] = None,
        extra: Optional[Dict[str, Any]] = None,
        exc_info: bool = False,
        **kwargs
    ):
        """Internal logging method with structured data."""
        if not self._initialized:
            self._fallback_log(level, event, extra)
            return
        
        log_data = {
            "event": event,
            "category": category.value,
            **kwargs
        }
        
        if error_type:
            log_data["error_type"] = error_type
        
        if extra:
            log_data.update(extra)
        
        # Get appropriate logger method
        if hasattr(self._logger, level.name.lower()):
            log_method = getattr(self._logger, level.name.lower())
        else:
            # Fallback to standard logging
            self._fallback_log(level, event, log_data)
            return
        
        # Log with structured data
        try:
            if exc_info and sys.exc_info()[0] is not None:
                log_method(event, **log_data, exc_info=True)
            else:
                log_method(event, **log_data)
        except Exception as e:
            # Fallback to basic logging if structlog fails
            self._fallback_log(level, f"{event} (structlog failed: {str(e)})", log_data)
    
    def _fallback_log(self, level: LogLevel, message: str, extra: Optional[Dict] = None):
        """Fallback logging if structlog is not available."""
        logger = logging.getLogger(self.app.name if self.app else __name__)
        
        log_message = message
        if extra:
            log_message = f"{message} | {json.dumps(extra, default=str)}"
        
        if level == LogLevel.DEBUG:
            logger.debug(log_message)
        elif level == LogLevel.INFO:
            logger.info(log_message)
        elif level == LogLevel.WARNING:
            logger.warning(log_message)
        elif level == LogLevel.ERROR:
            logger.error(log_message)
        elif level == LogLevel.CRITICAL:
            logger.critical(log_message)
    
    # Convenience methods
    def debug(self, event: str, category: LogCategory = LogCategory.SYSTEM, **kwargs):
        self._log(LogLevel.DEBUG, event, category, **kwargs)
    
    def info(self, event: str, category: LogCategory = LogCategory.SYSTEM, **kwargs):
        self._log(LogLevel.INFO, event, category, **kwargs)
    
    def warning(self, event: str, category: LogCategory = LogCategory.SYSTEM, **kwargs):
        self._log(LogLevel.WARNING, event, category, **kwargs)
    
    def error(
        self,
        event: str,
        category: LogCategory = LogCategory.ERROR,
        error_type: Optional[str] = None,
        **kwargs
    ):
        self._log(LogLevel.ERROR, event, category, error_type=error_type, **kwargs)
    
    def critical(
        self,
        event: str,
        category: LogCategory = LogCategory.ERROR,
        error_type: Optional[str] = None,
        **kwargs
    ):
        self._log(LogLevel.CRITICAL, event, category, error_type=error_type, **kwargs)
    
    def log_performance(
        self,
        operation: str,
        duration_ms: float,
        threshold_ms: Optional[float] = None,
        **kwargs
    ):
        """Log performance metrics."""
        extra = {
            "operation": operation,
            "duration_ms": duration_ms,
            "threshold_exceeded": threshold_ms is not None and duration_ms > threshold_ms,
        }
        extra.update(kwargs)
        
        level = LogLevel.WARNING if extra["threshold_exceeded"] else LogLevel.INFO
        self._log(level, "performance_metric", LogCategory.PERFORMANCE, extra=extra)
    
    def log_business_event(
        self,
        event: str,
        entity_type: str,
        entity_id: str,
        action: str,
        user_id: Optional[str] = None,
        changes: Optional[Dict] = None,
        **kwargs
    ):
        """Log business events for auditing."""
        extra = {
            "entity_type": entity_type,
            "entity_id": entity_id,
            "action": action,
            "user_id": user_id or getattr(g, 'user_id', None),
            "changes": changes,
        }
        extra.update(kwargs)
        
        self.info(event, category=LogCategory.BUSINESS, extra=extra)
    
    def log_security_event(
        self,
        event: str,
        severity: str = "medium",
        threat_type: Optional[str] = None,
        **kwargs
    ):
        """Log security-related events."""
        extra = {
            "severity": severity,
            "threat_type": threat_type,
            "ip_address": request.remote_addr if has_request_context() else None,
            "user_agent": request.user_agent.string if has_request_context() and request.user_agent else None,
        }
        extra.update(kwargs)
        
        level = LogLevel.CRITICAL if severity == "critical" else LogLevel.ERROR
        self._log(level, event, LogCategory.SECURITY, extra=extra)

# ==================== FIX: ADD SIMPLE CENTRALIZED INTERFACE ====================
class CentralizedLogger:
    """Simple centralized logger interface for easy adoption."""
    
    @staticmethod
    def get_logger(name: str = None):
        """
        Centralized logging interface.
        
        Usage:
            from app.core.logging import get_logger
            logger = get_logger(__name__)
            
            logger.info("Message")
            logger.error("Error occurred", extra={"user_id": 123})
        """
        if name is None:
            name = __name__
        
        # Return a configured logger with proper formatting
        logger = logging.getLogger(name)
        
        # Ensure the logger has at least one handler
        if not logger.handlers:
            # Add console handler with consistent format
            handler = logging.StreamHandler(sys.stdout)
            formatter = logging.Formatter(
                "%(asctime)s | %(levelname)s | %(name)s | %(message)s",
                datefmt="%Y-%m-%d %H:%M:%S"
            )
            handler.setFormatter(formatter)
            logger.addHandler(handler)
            logger.setLevel(logging.INFO)
            logger.propagate = False
        
        # Add correlation ID support if available
        import functools
        original_methods = {}
        
        for level in ['debug', 'info', 'warning', 'error', 'critical']:
            original = getattr(logger, level)
            
            @functools.wraps(original)
            def wrapped(msg, *args, extra=None, **kwargs):
                # Add correlation ID from thread-local context if available
                try:
                    from flask import g, has_request_context
                    if has_request_context() and hasattr(g, 'correlation_id'):
                        if extra is None:
                            extra = {}
                        extra['correlation_id'] = g.correlation_id
                except ImportError:
                    pass
                
                return original(msg, *args, extra=extra, **kwargs)
            
            setattr(logger, level, wrapped)
        
        return logger

# ==================== END FIX ====================

# Flask extension
class FlaskStructuredLogging:
    """Flask extension for structured logging."""
    
    def __init__(self, app: Optional[Flask] = None):
        self.logger = None
        
        if app:
            self.init_app(app)
    
    def init_app(self, app: Flask):
        """Initialize with Flask app."""
        self.logger = StructuredLogger(app)
        
        # Store logger in app context
        app.extensions['structured_logger'] = self.logger
        
        # Make logger available as property
        @property
        def structured_log(self):
            return self.logger
        
        app.structured_log = structured_log
        
        # Add error logging integration
        self._integrate_with_error_handling(app)
    
    def _integrate_with_error_handling(self, app: Flask):
        """Integrate with the error handling system from errors.py."""
        
        @app.errorhandler(Exception)
        def log_unhandled_exception(error):
            """Log unhandled exceptions."""
            error_type = type(error).__name__
            
            # Extract error details
            error_details = {
                "error_type": error_type,
                "error_message": str(error),
            }
            
            # Add context from error if it's an AppError
            if hasattr(error, 'context'):
                context_dict = error.context.to_dict() if hasattr(error.context, 'to_dict') else vars(error.context)
                error_details.update(context_dict)
            
            # Add request context
            if has_request_context():
                error_details.update({
                    "route": request.endpoint,
                    "method": request.method,
                    "url": request.url,
                })
            
            # Log the error
            self.logger.error(
                "unhandled_exception",
                category=LogCategory.ERROR,
                error_type=error_type,
                extra=error_details,
                exc_info=True
            )
            
            # Let the error propagate to other handlers
            raise error

# JSON Formatter for Python logging
class JSONFormatter(logging.Formatter):
    """Custom JSON formatter for Python's logging module."""
    
    def format(self, record: logging.LogRecord) -> str:
        """Format log record as JSON."""
        log_data = {
            "timestamp": datetime.utcnow().isoformat() + "Z",
            "level": record.levelname,
            "logger": record.name,
            "message": record.getMessage(),
            "module": record.module,
            "function": record.funcName,
            "line": record.lineno,
        }
        
        # Add exception info if present
        if record.exc_info:
            log_data["exception"] = self.formatException(record.exc_info)
        
        # Add extra attributes
        if hasattr(record, 'props'):
            log_data.update(record.props)
        
        # Add structured log attributes from record
        for key in ['event', 'category', 'error_type', 'request_id', 'user_id', 'route']:
            if hasattr(record, key):
                log_data[key] = getattr(record, key)
        
        return json.dumps(log_data, default=str)

# Request logging middleware
def request_logging_middleware(logger: StructuredLogger):
    """Create middleware for request logging."""
    
    def middleware(app):
        @app.before_request
        def log_request_start():
            """Log request start with all context."""
            # Store start time for duration calculation
            g.request_start_time = time.time()
            
            # Extract and log request details
            request_details = {
                "url": request.url,
                "method": request.method,
                "headers": dict(request.headers),
                "query_params": dict(request.args),
                "content_type": request.content_type,
                "content_length": request.content_length,
            }
            
            logger.info(
                "request_received",
                category=LogCategory.REQUEST,
                extra=request_details
            )
        
        @app.after_request
        def log_request_end(response):
            """Log request completion with response details."""
            # Calculate duration
            duration_ms = None
            if hasattr(g, 'request_start_time'):
                duration_ms = (time.time() - g.request_start_time) * 1000
            
            response_details = {
                "status_code": response.status_code,
                "response_size": response.calculate_content_length(),
                "duration_ms": duration_ms,
                "route": request.endpoint,
                "method": request.method,
            }
            
            log_level = LogLevel.ERROR if response.status_code >= 400 else LogLevel.INFO
            event = "request_failed" if response.status_code >= 400 else "request_completed"
            
            logger._log(
                log_level,
                event,
                LogCategory.RESPONSE,
                extra=response_details
            )
            
            return response
        
        return app
    
    return middleware

# Decorator for logging function calls
def log_call(category: LogCategory = LogCategory.SERVICE, log_args: bool = False, log_result: bool = False):
    """Decorator to log function calls with timing."""
    
    def decorator(func):
        @wraps(func)
        def wrapper(*args, **kwargs):
            # Get logger from current app or module
            logger = None
            if current_app and 'structured_logger' in current_app.extensions:
                logger = current_app.extensions['structured_logger']
            else:
                # Fallback to module-level logger
                logger = get_logger(__name__)
            
            # Log call start
            func_name = func.__name__
            module_name = func.__module__
            
            extra = {
                "function": func_name,
                "module": module_name,
            }
            
            if log_args:
                # Be careful with sensitive data - only log non-sensitive args
                args_repr = [repr(arg) for arg in args]
                kwargs_repr = [f"{k}={repr(v)}" for k, v in kwargs.items()]
                extra["arguments"] = f"args={args_repr}, kwargs={kwargs_repr}"
            
            logger.info(
                "function_call_start",
                category=category,
                extra=extra
            )
            
            # Execute function with timing
            start_time = time.time()
            try:
                result = func(*args, **kwargs)
                duration_ms = (time.time() - start_time) * 1000
                
                # Log success
                success_extra = {
                    "function": func_name,
                    "duration_ms": duration_ms,
                    "success": True,
                }
                
                if log_result:
                    success_extra["result"] = repr(result)[:200]  # Limit size
                
                logger.info(
                    "function_call_completed",
                    category=category,
                    extra=success_extra
                )
                
                return result
                
            except Exception as e:
                duration_ms = (time.time() - start_time) * 1000
                error_type = type(e).__name__
                
                # Log failure
                logger.error(
                    "function_call_failed",
                    category=category,
                    error_type=error_type,
                    extra={
                        "function": func_name,
                        "duration_ms": duration_ms,
                        "error_message": str(e),
                        "success": False,
                    },
                    exc_info=True
                )
                
                raise
        
        return wrapper
    
    return decorator

# ==================== FIX: SIMPLIFIED GLOBAL INTERFACE ====================

# Initialize basic logging immediately
setup_basic_logging()

def get_logger(name: str = None):
    """
    Centralized logging function - use this everywhere.
    
    Examples:
        # Basic usage
        from core.logging import get_logger
        logger = get_logger(__name__)
        logger.info("Processing started")
        
        # With extra context
        logger.error("Failed to process", extra={"user_id": 123, "attempt": 3})
        
        # In Flask routes (automatically gets correlation IDs)
        @app.route('/users')
        def get_users():
            logger.info("Fetching users")
            return users
    """
    return CentralizedLogger.get_logger(name)

def init_app(app: Flask):
    """
    Initialize structured logging with Flask app.
    Call this in your app factory.
    
    Example:
        from core.logging import init_app
        
        def create_app():
            app = Flask(__name__)
            init_app(app)
            return app
    """
    # Set up structured logging
    structured_logging = FlaskStructuredLogging(app)
    
    # Add correlation ID middleware
    @app.before_request
    def set_correlation_id():
        """Set correlation ID for request tracing."""
        correlation_id = request.headers.get('X-Correlation-ID') or request.headers.get('X-Request-ID')
        if not correlation_id:
            import uuid
            correlation_id = str(uuid.uuid4())
        
        g.correlation_id = correlation_id
    
    # Initialize the global logger instance
    global _logger_instance
    _logger_instance = structured_logging.logger
    
    return structured_logging.logger

# Global logger instance
_logger_instance: Optional[StructuredLogger] = None

# Convenience functions for common logging scenarios
def log_error_with_context(
    error: Exception,
    category: LogCategory = LogCategory.ERROR,
    operation: Optional[str] = None,
    **context
):
    """Log an error with full context."""
    logger = get_logger()
    
    error_type = type(error).__name__
    error_details = {
        "error_type": error_type,
        "error_message": str(error),
        "operation": operation,
    }
    error_details.update(context)
    
    logger.error(
        "error_occurred",
        category=category,
        error_type=error_type,
        extra=error_details,
        exc_info=True
    )

def log_request_summary(
    status_code: int,
    duration_ms: float,
    route: str,
    method: str,
    user_id: Optional[str] = None,
    **extra
):
    """Log a summary of a request."""
    logger = get_logger()
    
    log_data = {
        "status_code": status_code,
        "duration_ms": duration_ms,
        "route": route,
        "method": method,
        "user_id": user_id,
    }
    log_data.update(extra)
    
    event = "request_failed" if status_code >= 400 else "request_success"
    level = LogLevel.ERROR if status_code >= 400 else LogLevel.INFO
    
    logger._log(
        level,
        event,
        LogCategory.REQUEST,
        extra=log_data
    )

# ==================== ADDITIONAL FIX: BACKWARD COMPATIBILITY ====================
# Ensure the module-level logger works with the old pattern
logger = get_logger(__name__)