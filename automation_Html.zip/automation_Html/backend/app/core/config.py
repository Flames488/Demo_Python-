# backend/core/config.py
"""
Unified Configuration System - Advanced with simplified interface
Combines the robust validation of the advanced system with simple access patterns.
"""
from pydantic_settings import BaseSettings
from pydantic import Field, AnyUrl, EmailStr, SecretStr, PostgresDsn, RedisDsn, validator, field_validator, ValidationError
from typing import Optional, Dict, Any, List, Union, Literal
from enum import Enum
from functools import lru_cache
from datetime import timedelta
import os
import json
import logging
import sys
import boto3
from dataclasses import dataclass

# Set up logging
logger = logging.getLogger(__name__)

# ===== Enums for configuration =====
class Environment(str, Enum):
    DEVELOPMENT = "development"
    TESTING = "testing"
    STAGING = "staging"
    PRODUCTION = "production"

class LogLevel(str, Enum):
    DEBUG = "DEBUG"
    INFO = "INFO"
    WARNING = "WARNING"
    ERROR = "ERROR"
    CRITICAL = "CRITICAL"

class CacheBackend(str, Enum):
    REDIS = "redis"
    MEMORY = "memory"
    NULL = "null"

class PaymentProvider(str, Enum):
    STRIPE = "stripe"
    PAYPAL = "paypal"
    RAZORPAY = "razorpay"

# ===== Nested settings models =====
class DatabaseSettings(BaseSettings):
    URL: Optional[PostgresDsn] = Field(None, description="PostgreSQL connection URL", env="DATABASE_URL")
    POOL_SIZE: int = Field(20, ge=1, le=100)
    MAX_OVERFLOW: int = Field(10, ge=0, le=50)
    POOL_RECYCLE_SECONDS: int = Field(3600, ge=300)
    POOL_PRE_PING: bool = True
    ECHO: bool = False
    
    @field_validator('ECHO')
    def validate_echo(cls, v, info):
        env = info.data.get('ENV', 'production')
        return v if env == Environment.DEVELOPMENT else False
    
    @field_validator('URL')
    def validate_url(cls, v, info):
        if not v and info.data.get('ENV') == Environment.PRODUCTION:
            raise ValueError('DATABASE_URL is required in production')
        return v

class CacheSettings(BaseSettings):
    BACKEND: CacheBackend = CacheBackend.REDIS
    REDIS_URL: Optional[RedisDsn] = None
    DEFAULT_TTL: int = Field(300, ge=1, description="Default cache TTL in seconds")
    MAX_SIZE: int = Field(1000, ge=100, le=10000)
    
    @field_validator('REDIS_URL')
    def validate_redis_url(cls, v, info):
        backend = info.data.get('BACKEND')
        if backend == CacheBackend.REDIS and not v:
            raise ValueError('REDIS_URL is required when BACKEND is redis')
        return v

class SecuritySettings(BaseSettings):
    SECRET_KEY: SecretStr = Field(
        ...,
        min_length=32,
        description="Application secret key for encryption and signing",
        env="SECRET_KEY"
    )
    JWT_SECRET_KEY: SecretStr = Field(
        ...,
        min_length=32,
        env="JWT_SECRET_KEY"
    )
    JWT_ALGORITHM: str = "HS256"
    JWT_ACCESS_TOKEN_EXPIRE_MINUTES: int = Field(30, ge=5, le=1440)
    JWT_REFRESH_TOKEN_EXPIRE_DAYS: int = Field(7, ge=1, le=90)
    JWT_TOKEN_LOCATION: List[str] = ["headers"]
    JWT_HEADER_NAME: str = "Authorization"
    JWT_HEADER_TYPE: str = "Bearer"
    JWT_BLACKLIST_ENABLED: bool = True
    JWT_BLACKLIST_TOKEN_CHECKS: List[str] = ["access", "refresh"]
    
    # CORS settings
    CORS_ORIGINS: List[str] = Field(
        default_factory=lambda: ["http://localhost:3000", "http://localhost:8000"],
        description="Allowed CORS origins"
    )
    CORS_ALLOW_CREDENTIALS: bool = True
    CORS_ALLOW_METHODS: List[str] = ["GET", "POST", "PUT", "DELETE", "PATCH", "OPTIONS"]
    CORS_ALLOW_HEADERS: List[str] = ["*"]
    
    # Rate limiting
    RATE_LIMIT_ENABLED: bool = True
    RATE_LIMIT_PER_MINUTE: int = Field(60, ge=1, le=1000)
    RATE_LIMIT_PER_HOUR: int = Field(1000, ge=10, le=10000)
    RATE_LIMIT_STRATEGY: str = "fixed-window"
    RATE_LIMIT_STORAGE_URI: str = "memory://"
    
    # Cookie security
    SESSION_COOKIE_SECURE: bool = True
    SESSION_COOKIE_HTTPONLY: bool = True
    SESSION_COOKIE_SAMESITE: str = "Lax"
    
    @field_validator('CORS_ORIGINS')
    def validate_cors_origins(cls, v, info):
        env = info.data.get('ENV')
        if env == Environment.PRODUCTION:
            # Ensure production has secure origins
            for origin in v:
                if not origin.startswith('https://'):
                    logger.warning(f"Insecure CORS origin in production: {origin}")
        return v

class StripeSettings(BaseSettings):
    SECRET_KEY: Optional[SecretStr] = Field(
        None,
        description="Stripe secret key for API authentication",
        env="STRIPE_SECRET_KEY"
    )
    PUBLIC_KEY: Optional[str] = Field(None, description="Stripe publishable key for client-side", env="STRIPE_PUBLIC_KEY")
    WEBHOOK_SECRET: Optional[SecretStr] = Field(
        None,
        description="Stripe webhook signing secret for verifying webhook signatures",
        env="STRIPE_WEBHOOK_SECRET"
    )
    # Simple interface compatibility field - maps to the first price ID
    PRICE_ID: Optional[str] = Field(None, description="Stripe price ID for subscription", env="STRIPE_PRICE_ID")
    
    API_VERSION: str = Field("2023-10-16", description="Stripe API version")
    WEBHOOK_TOLERANCE: int = Field(300, description="Stripe webhook signature tolerance in seconds")
    CONNECT_TIMEOUT: int = Field(30, ge=5, le=60, description="Stripe API connection timeout in seconds")
    READ_TIMEOUT: int = Field(30, ge=5, le=60, description="Stripe API read timeout in seconds")
    
    # Webhook processing
    WEBHOOK_IDEMPOTENCY_ENABLED: bool = True
    WEBHOOK_MAX_RETRIES: int = Field(3, ge=1, le=10)
    WEBHOOK_RETRY_DELAY: float = Field(1.0, ge=0.1, le=60.0)
    WEBHOOK_CONCURRENCY: int = Field(5, ge=1, le=20, description="Max concurrent webhook processing")
    WEBHOOK_RATE_LIMIT: str = "10/minute"
    
    # Billing plans configuration
    PRICES: Dict[str, str] = Field(
        default_factory=lambda: {
            "pro_monthly": "price_pro_monthly",
            "pro_yearly": "price_pro_yearly",
            "business_monthly": "price_business_monthly",
            "business_yearly": "price_business_yearly",
            "enterprise_monthly": "price_enterprise_monthly",
            "enterprise_yearly": "price_enterprise_yearly",
        },
        description="Stripe price IDs for different plans and billing periods"
    )
    
    # Tax settings
    TAX_ENABLED: bool = Field(True, description="Enable tax calculation")
    TAX_CODES: Dict[str, str] = Field(
        default_factory=lambda: {
            "digital_goods": "txcd_10000000",
            "saas": "txcd_10000001",
        }
    )
    
    @field_validator('PRICES')
    def validate_prices(cls, v):
        for key, value in v.items():
            if value and not value.startswith('price_'):
                raise ValueError(f"Invalid Stripe price ID format for {key}: {value}")
        return v
    
    @field_validator('PRICE_ID')
    def validate_price_id(cls, v):
        if v and not v.startswith('price_'):
            raise ValueError(f"Invalid Stripe price ID format: {v}")
        return v

class BillingSettings(BaseSettings):
    # Payment provider selection
    PROVIDER: PaymentProvider = PaymentProvider.STRIPE
    
    # URLs for billing flows
    SUCCESS_URL: AnyUrl = Field("https://app.example.com/billing/success")
    CANCEL_URL: AnyUrl = Field("https://app.example.com/billing/cancel")
    PORTAL_RETURN_URL: AnyUrl = Field("https://app.example.com/billing/portal")
    
    # Checkout settings
    CHECKOUT_EXPIRY_MINUTES: int = Field(30, ge=5, le=120)
    CHECKOUT_CACHE_TTL: int = Field(1800, ge=300, le=3600)
    
    # Trial settings
    DEFAULT_TRIAL_DAYS: int = Field(14, ge=0, le=30)
    TRIAL_PLANS: List[str] = Field(["pro", "business"])
    
    # Subscription settings
    GRACE_PERIOD_DAYS: int = Field(7, ge=0, le=30)
    AUTO_CANCEL_AFTER_DAYS: int = Field(90, ge=1, le=365)
    
    # Invoice settings
    INVOICE_PREFIX: str = Field("INV-", max_length=10)
    INVOICE_FOOTER: Optional[str] = Field(None, description="Custom footer text for invoices")
    
    # Currency and locale
    DEFAULT_CURRENCY: str = Field("usd", pattern="^[a-z]{3}$")
    CURRENCY_DECIMALS: Dict[str, int] = Field(
        default_factory=lambda: {
            "usd": 2,
            "eur": 2,
            "jpy": 0,
            "gbp": 2,
        }
    )
    
    # Email notifications
    SEND_PAYMENT_RECEIPTS: bool = True
    SEND_SUBSCRIPTION_REMINDERS: bool = True
    REMINDER_DAYS_BEFORE: List[int] = Field([1, 3, 7])
    
    @field_validator('TRIAL_PLANS')
    def validate_trial_plans(cls, v):
        valid_plans = ["free", "pro", "business", "enterprise"]
        for plan in v:
            if plan not in valid_plans:
                raise ValueError(f"Invalid trial plan: {plan}. Must be one of {valid_plans}")
        return v

class EmailSettings(BaseSettings):
    PROVIDER: str = Field("smtp", pattern="^(smtp|sendgrid|ses|mailgun)$")
    FROM_EMAIL: EmailStr = Field("noreply@example.com")
    FROM_NAME: str = Field("Automation Platform")
    
    # SMTP settings
    SMTP_HOST: Optional[str] = None
    SMTP_PORT: Optional[int] = Field(None, ge=1, le=65535)
    SMTP_USERNAME: Optional[str] = None
    SMTP_PASSWORD: Optional[SecretStr] = None
    SMTP_USE_TLS: bool = True
    SMTP_USE_SSL: bool = False
    
    # Template settings
    TEMPLATE_DIR: str = "email_templates"
    ENABLE_PREVIEW: bool = Field(False, description="Enable email preview in development")
    
    @field_validator('SMTP_PORT')
    def validate_smtp_port(cls, v, info):
        provider = info.data.get('PROVIDER')
        if provider == "smtp" and not v:
            raise ValueError('SMTP_PORT is required when PROVIDER is smtp')
        return v

class LoggingSettings(BaseSettings):
    LEVEL: LogLevel = LogLevel.INFO
    FORMAT: str = "%(asctime)s - %(name)s - %(levelname)s - %(message)s"
    DATE_FORMAT: str = "%Y-%m-%d %H:%M:%S"
    
    # JSON logging
    JSON_LOGS: bool = Field(False)
    JSON_FIELDS: List[str] = Field(["timestamp", "level", "message", "module", "function"])
    
    # File logging
    FILE_ENABLED: bool = Field(False)
    FILE_PATH: str = "logs/app.log"
    FILE_MAX_SIZE: int = Field(10485760, ge=1048576, le=1073741824)  # 10MB max
    FILE_BACKUP_COUNT: int = Field(5, ge=1, le=50)
    
    # Sentry integration
    SENTRY_DSN: Optional[SecretStr] = None
    SENTRY_ENVIRONMENT: Optional[str] = None
    SENTRY_TRACES_SAMPLE_RATE: float = Field(0.1, ge=0.0, le=1.0)
    
    @field_validator('LEVEL')
    def validate_log_level(cls, v, info):
        env = info.data.get('ENV')
        if env == Environment.PRODUCTION and v == LogLevel.DEBUG:
            logger.warning("DEBUG logging enabled in production - consider changing to INFO")
        return v

class MonitoringSettings(BaseSettings):
    # Health checks
    HEALTH_CHECK_ENABLED: bool = True
    HEALTH_CHECK_INTERVAL: int = Field(60, ge=10, description="Health check interval in seconds")
    
    # Metrics
    METRICS_ENABLED: bool = False
    METRICS_PORT: int = Field(9090, ge=1024, le=65535)
    METRICS_PATH: str = "/metrics"
    
    # Performance monitoring
    SLOW_QUERY_THRESHOLD: float = Field(1.0, ge=0.1, description="Slow query threshold in seconds")
    REQUEST_TIMEOUT: float = Field(30.0, ge=1.0, le=300.0)
    
    # Alerting
    ALERT_EMAILS: List[EmailStr] = Field(default_factory=list)
    ALERT_WEBHOOKS: List[AnyUrl] = Field(default_factory=list)

# ===== Environment Validator =====
@dataclass
class RequiredVar:
    name: str
    description: str
    production_required: bool = True
    secret: bool = False
    default: Optional[str] = None
    min_length: Optional[int] = None

class EnvironmentValidator:
    """Strict environment configuration validator"""
    
    # Define ALL required environment variables
    REQUIRED_VARS = [
        RequiredVar("SECRET_KEY", "Application secret key", True, secret=True, min_length=32),
        RequiredVar("JWT_SECRET_KEY", "JWT signing secret", True, secret=True, min_length=32),
        RequiredVar("ENV", "Runtime environment", True),
        RequiredVar("DATABASE_URL", "Database connection URL", True, secret=True),
        RequiredVar("STRIPE_SECRET_KEY", "Stripe secret key", False, secret=True),
        RequiredVar("STRIPE_WEBHOOK_SECRET", "Stripe webhook secret", False, secret=True),
        RequiredVar("STRIPE_PRICE_ID", "Stripe price ID", False),
    ]
    
    # Production-only variables (must be set in production, optional elsewhere)
    PRODUCTION_ONLY_VARS = [
        RequiredVar("AWS_SECRET_NAME", "AWS Secrets Manager secret name", True),
    ]
    
    # Optional variables with defaults
    OPTIONAL_VARS = {
        "LOG_LEVEL": {"default": "INFO", "dev_default": "DEBUG"},
        "JSON_LOGS": {"default": "true", "dev_default": "false"},
        "SERVICE_NAME": {"default": "autobetter-backend"},
        "STRIPE_API_VERSION": {"default": "2023-10-16"},
        "STRIPE_WEBHOOK_TOLERANCE": {"default": "300"},
        "WEBHOOK_IDEMPOTENCY_ENABLED": {"default": "true"},
        "WEBHOOK_MAX_RETRIES": {"default": "3"},
        "WEBHOOK_RETRY_DELAY": {"default": "1.0"},
        "WEBHOOK_RATE_LIMIT": {"default": "10/minute"},
        "APP_NAME": {"default": "Automation Platform"},
        "APP_VERSION": {"default": "1.0.0"},
        "API_V1_STR": {"default": "/api/v1"},
        "HOST": {"default": "0.0.0.0"},
        "PORT": {"default": "8000"},
        "WORKERS": {"default": "1"},
        "DOMAIN": {"default": "localhost:8000"},
        "PROTOCOL": {"default": "http"},
    }
    
    def __init__(self):
        self.env = self._get_environment()
        self._validate()
        self._set_defaults()
        
    def _get_environment(self) -> Environment:
        """Get and validate environment type"""
        env_str = os.getenv("ENV", "development").lower()
        try:
            return Environment(env_str)
        except ValueError:
            valid_envs = [e.value for e in Environment]
            raise SystemExit(
                f"❌ Invalid ENV='{env_str}'. Must be one of: {valid_envs}"
            )
    
    def _validate(self):
        """Strict validation - crashes hard on missing required vars"""
        errors = []
        warnings = []
        
        # Check required variables
        for var in self.REQUIRED_VARS:
            value = os.getenv(var.name)
            
            if value is None:
                if var.production_required and self.env == Environment.PRODUCTION:
                    errors.append(f"❌ REQUIRED in production: {var.name} - {var.description}")
                elif var.default is not None:
                    warnings.append(f"⚠️  Using default for {var.name}: {var.default}")
                else:
                    # Only error if production_required is True
                    if var.production_required:
                        errors.append(f"❌ Missing: {var.name} - {var.description}")
            else:
                # Length validation for secrets
                if var.min_length and len(value) < var.min_length:
                    if self.env == Environment.PRODUCTION:
                        errors.append(f"🚨 {var.name} too short: {len(value)} < {var.min_length} chars")
                    else:
                        warnings.append(f"⚠️  {var.name} may be too short for production: {len(value)} chars")
                
                # Security warnings for production
                if var.secret and self.env == Environment.PRODUCTION:
                    insecure_terms = ["test", "secret", "password", "123", "default", "your_"]
                    if any(term in value.lower() for term in insecure_terms):
                        warnings.append(f"⚠️  {var.name} may contain insecure patterns")
        
        # Check production-only variables
        if self.env == Environment.PRODUCTION:
            for var in self.PRODUCTION_ONLY_VARS:
                value = os.getenv(var.name)
                if not value:
                    errors.append(f"🚨 Production-only variable missing: {var.name} - {var.description}")
        
        # Development environment warnings
        if self.env == Environment.DEVELOPMENT:
            dev_vars = ["DEBUG", "FLASK_DEBUG"]
            for var in dev_vars:
                if os.getenv(var) == "1" or os.getenv(var) == "true":
                    warnings.append(f"⚠️  {var} is enabled - ensure this is disabled in production")
        
        # Print warnings
        if warnings:
            print("\n" + "="*60)
            print("Configuration Warnings:")
            print("="*60)
            for warning in warnings:
                print(warning)
        
        # Crash on errors
        if errors:
            print("\n" + "="*60)
            print("❌ Configuration Failed - Application will not start")
            print("="*60)
            for error in errors:
                print(error)
            print("="*60)
            raise SystemExit(1)
    
    def _set_defaults(self):
        """Apply environment-specific defaults"""
        for var_name, var_config in self.OPTIONAL_VARS.items():
            if os.getenv(var_name) is None:
                # Use dev default for development, regular default otherwise
                if self.env == Environment.DEVELOPMENT and "dev_default" in var_config:
                    os.environ[var_name] = var_config["dev_default"]
                elif "default" in var_config:
                    os.environ[var_name] = var_config["default"]
    
    @property
    def is_production(self) -> bool:
        return self.env == Environment.PRODUCTION
    
    @property
    def is_development(self) -> bool:
        return self.env == Environment.DEVELOPMENT

# ===== AWS Secrets Loader =====
def load_aws_secrets(secret_name: str, region_name: str = "us-east-1") -> dict:
    """
    Fetch secrets from AWS Secrets Manager
    """
    try:
        client = boto3.client("secretsmanager", region_name=region_name)
        response = client.get_secret_value(SecretId=secret_name)
        return json.loads(response["SecretString"])
    except Exception as e:
        logger.error(f"Failed to load AWS secrets: {e}")
        raise

# ===== Main Settings Class with Simple Interface Compatibility =====
class Settings(BaseSettings):
    """
    Unified Configuration Settings with Simple Interface Compatibility
    
    This class integrates both the advanced configuration system and provides
    a simple interface for basic applications.
    """
    
    # ===== SIMPLE INTERFACE FIELDS =====
    # These fields match your simple interface requirements exactly
    SECRET_KEY: SecretStr = Field(..., env="SECRET_KEY")
    STRIPE_SECRET_KEY: Optional[SecretStr] = Field(None, env="STRIPE_SECRET_KEY")
    STRIPE_WEBHOOK_SECRET: Optional[SecretStr] = Field(None, env="STRIPE_WEBHOOK_SECRET")
    STRIPE_PRICE_ID: Optional[str] = Field(None, env="STRIPE_PRICE_ID")
    DATABASE_URL: Optional[PostgresDsn] = Field(None, env="DATABASE_URL")
    
    # ===== ADVANCED CONFIGURATION FIELDS =====
    ENV: Environment = Field(Environment.PRODUCTION)
    APP_NAME: str = Field("Automation Platform", min_length=1, max_length=100)
    APP_VERSION: str = Field("1.0.0", pattern=r"^\d+\.\d+\.\d+(-[a-zA-Z0-9]+)?$")
    DEBUG: bool = Field(False)
    SERVICE_NAME: str = Field("autobetter-backend")
    
    # API settings
    API_V1_STR: str = "/api/v1"
    HOST: str = Field("0.0.0.0", pattern=r"^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$|^localhost$")
    PORT: int = Field(8000, ge=1024, le=65535)
    WORKERS: int = Field(1, ge=1, le=32)
    
    # Domain settings
    DOMAIN: str = Field("localhost:8000")
    PROTOCOL: str = Field("http", pattern="^(http|https)$")
    
    # AWS Secrets Manager (for production)
    AWS_SECRET_NAME: Optional[str] = None
    AWS_REGION: str = "us-east-1"
    
    # Sub-configurations
    DATABASE: DatabaseSettings = Field(default_factory=DatabaseSettings)
    CACHE: CacheSettings = Field(default_factory=CacheSettings)
    SECURITY: SecuritySettings = Field(default_factory=SecuritySettings)
    STRIPE: StripeSettings = Field(default_factory=StripeSettings)
    BILLING: BillingSettings = Field(default_factory=BillingSettings)
    EMAIL: EmailSettings = Field(default_factory=EmailSettings)
    LOGGING: LoggingSettings = Field(default_factory=LoggingSettings)
    MONITORING: MonitoringSettings = Field(default_factory=MonitoringSettings)
    
    # Feature flags
    FEATURE_FLAGS: Dict[str, bool] = Field(
        default_factory=lambda: {
            "billing_enabled": True,
            "multi_tenant": False,
            "api_rate_limiting": True,
            "maintenance_mode": False,
            "experimental_features": False,
            "webhook_retry_enabled": True,
        }
    )
    
    # Application behavior flags
    PROPAGATE_EXCEPTIONS: bool = True
    JSON_LOGS: bool = Field(False)
    
    # ===== PROPERTIES FOR SIMPLE INTERFACE =====
    @property
    def stripe_secret_key(self) -> Optional[str]:
        """Get Stripe secret key as string for simple interface."""
        return self.STRIPE_SECRET_KEY.get_secret_value() if self.STRIPE_SECRET_KEY else None
    
    @property
    def stripe_webhook_secret(self) -> Optional[str]:
        """Get Stripe webhook secret as string for simple interface."""
        return self.STRIPE_WEBHOOK_SECRET.get_secret_value() if self.STRIPE_WEBHOOK_SECRET else None
    
    @property
    def secret_key_str(self) -> str:
        """Get secret key as string for simple interface."""
        return self.SECRET_KEY.get_secret_value()
    
    @property
    def database_url_str(self) -> Optional[str]:
        """Get database URL as string for simple interface."""
        return str(self.DATABASE_URL) if self.DATABASE_URL else None
    
    # ===== PROPERTIES FOR ADVANCED CONFIG =====
    @property
    def is_production(self) -> bool:
        return self.ENV == Environment.PRODUCTION
    
    @property
    def is_development(self) -> bool:
        return self.ENV == Environment.DEVELOPMENT
    
    @property
    def is_staging(self) -> bool:
        return self.ENV == Environment.STAGING
    
    @property
    def is_testing(self) -> bool:
        return self.ENV == Environment.TESTING
    
    @property
    def base_url(self) -> str:
        return f"{self.PROTOCOL}://{self.DOMAIN}"
    
    @property
    def api_url(self) -> str:
        return f"{self.base_url}{self.API_V1_STR}"
    
    @property
    def allowed_origins(self) -> List[str]:
        if self.is_development:
            return ["http://localhost:3000", "http://localhost:8000", "http://localhost:8080"]
        return [self.base_url]
    
    # ===== VALIDATORS =====
    @field_validator('DEBUG')
    def validate_debug(cls, v, info):
        env = info.data.get('ENV')
        if env == Environment.PRODUCTION and v:
            raise ValueError('DEBUG should be False in production')
        return v
    
    @field_validator('DATABASE_URL')
    def validate_database_url(cls, v, info):
        """Compatibility validator for simple interface"""
        env = info.data.get('ENV')
        if env == Environment.PRODUCTION and not v:
            raise ValueError('DATABASE_URL is required in production')
        return v
    
    @field_validator('DOMAIN')
    def validate_domain(cls, v, info):
        env = info.data.get('ENV')
        if env == Environment.PRODUCTION and 'localhost' in v:
            raise ValueError('Domain cannot be localhost in production')
        return v
    
    @field_validator('PROTOCOL')
    def validate_protocol(cls, v, info):
        env = info.data.get('ENV')
        if env == Environment.PRODUCTION and v != 'https':
            logger.warning("Non-HTTPS protocol in production - security risk")
        return v
    
    @field_validator('WORKERS')
    def validate_workers(cls, v, info):
        env = info.data.get('ENV')
        if env == Environment.DEVELOPMENT and v > 1:
            logger.warning("Multiple workers in development may cause issues with hot reload")
        return v
    
    @field_validator('STRIPE_PRICE_ID')
    def validate_stripe_price_id(cls, v, info):
        """Validate Stripe price ID format"""
        if v and not v.startswith('price_'):
            raise ValueError(f"Invalid Stripe price ID format: {v}. Should start with 'price_'")
        return v
    
    # ===== POST-INITIALIZATION =====
    def model_post_init(self, __context):
        """Apply environment-specific settings after initialization"""
        
        # Set DATABASE.URL from top-level DATABASE_URL if not set in nested config
        if not self.DATABASE.URL and self.DATABASE_URL:
            self.DATABASE.URL = self.DATABASE_URL
        
        # Sync simple interface fields with nested configuration
        if self.STRIPE_PRICE_ID and not self.STRIPE.PRICE_ID:
            self.STRIPE.PRICE_ID = self.STRIPE_PRICE_ID
        
        if self.STRIPE_SECRET_KEY and not self.STRIPE.SECRET_KEY:
            self.STRIPE.SECRET_KEY = self.STRIPE_SECRET_KEY
        
        if self.STRIPE_WEBHOOK_SECRET and not self.STRIPE.WEBHOOK_SECRET:
            self.STRIPE.WEBHOOK_SECRET = self.STRIPE_WEBHOOK_SECRET
        
        # Set simple price ID in Stripe PRICES if not present
        if self.STRIPE_PRICE_ID and "default_monthly" not in self.STRIPE.PRICES:
            self.STRIPE.PRICES["default_monthly"] = self.STRIPE_PRICE_ID
        
        # Environment-specific settings
        if self.is_production:
            # Production hardening
            self.DEBUG = False
            self.PROPAGATE_EXCEPTIONS = True
            self.JSON_LOGS = True
            self.LOGGING.JSON_LOGS = True
            self.LOGGING.LEVEL = LogLevel.WARNING
            
            # Security hardening
            self.SECURITY.SESSION_COOKIE_SECURE = True
            self.SECURITY.SESSION_COOKIE_HTTPONLY = True
            self.SECURITY.SESSION_COOKIE_SAMESITE = "Lax"
            
            # Rate limiting in production
            self.SECURITY.RATE_LIMIT_PER_MINUTE = 20
            self.SECURITY.RATE_LIMIT_PER_HOUR = 100
            
            # Ensure no development secrets
            insecure_terms = ["test", "secret", "password", "123", "default"]
            secret_key = self.SECURITY.SECRET_KEY.get_secret_value()
            jwt_key = self.SECURITY.JWT_SECRET_KEY.get_secret_value()
            
            if any(term in secret_key.lower() for term in insecure_terms):
                raise RuntimeError("Insecure SECRET_KEY detected in production")
            
            if any(term in jwt_key.lower() for term in insecure_terms):
                raise RuntimeError("Insecure JWT_SECRET_KEY detected in production")
        
        elif self.is_development:
            # Development settings
            self.DEBUG = True
            self.PROPAGATE_EXCEPTIONS = True
            self.JSON_LOGS = False
            self.LOGGING.JSON_LOGS = False
            self.LOGGING.LEVEL = LogLevel.DEBUG
            
            # More relaxed rate limiting for development
            self.SECURITY.RATE_LIMIT_PER_MINUTE = 100
            self.SECURITY.RATE_LIMIT_PER_HOUR = 1000
        
        elif self.is_testing:
            # Testing settings
            self.DEBUG = False
            self.LOGGING.LEVEL = LogLevel.DEBUG
    
    class Config:
        env_file = ".env"
        env_file_encoding = "utf-8"
        env_nested_delimiter = "__"
        case_sensitive = True
        extra = "ignore"

# ===== Configuration loading with AWS support =====
@lru_cache(maxsize=1)
def get_settings() -> Settings:
    """
    Get cached settings instance with AWS Secrets Manager support.
    This ensures settings are loaded only once and reused.
    """
    try:
        # Initialize environment validator
        validator = EnvironmentValidator()
        env = validator.env
        
        # Load secrets based on environment
        if env == Environment.PRODUCTION:
            # In production, try to load from AWS Secrets Manager
            secret_name = os.getenv("AWS_SECRET_NAME", "my-app-secrets")
            if secret_name:
                try:
                    aws_secrets = load_aws_secrets(secret_name, os.getenv("AWS_REGION", "us-east-1"))
                    # Merge AWS secrets with environment variables
                    for key, value in aws_secrets.items():
                        if key not in os.environ:
                            os.environ[key] = str(value) if not isinstance(value, dict) else json.dumps(value)
                except Exception as e:
                    logger.warning(f"Failed to load AWS secrets, falling back to env vars: {e}")
        
        # Create settings instance
        settings = Settings()
        
        # Log configuration warnings
        if settings.is_production:
            if settings.DEBUG:
                logger.critical("DEBUG mode enabled in production!")
            if settings.PROTOCOL != "https":
                logger.critical("Non-HTTPS protocol in production!")
            
            # Validate production-only requirements
            if not settings.STRIPE.WEBHOOK_SECRET or not settings.STRIPE.WEBHOOK_SECRET.get_secret_value():
                logger.warning("STRIPE_WEBHOOK_SECRET is not set in production (required for billing)")
        
        # Log feature flags
        enabled_features = [k for k, v in settings.FEATURE_FLAGS.items() if v]
        logger.info(f"Environment: {settings.ENV.value}")
        logger.info(f"Enabled feature flags: {', '.join(enabled_features) if enabled_features else 'None'}")
        
        # Log simple interface configuration status
        logger.info(f"Simple interface fields loaded: SECRET_KEY={bool(settings.SECRET_KEY)}, "
                   f"STRIPE_SECRET_KEY={bool(settings.STRIPE_SECRET_KEY)}, "
                   f"STRIPE_WEBHOOK_SECRET={bool(settings.STRIPE_WEBHOOK_SECRET)}, "
                   f"STRIPE_PRICE_ID={bool(settings.STRIPE_PRICE_ID)}, "
                   f"DATABASE_URL={bool(settings.DATABASE_URL)}")
        
        return settings
    except ValidationError as e:
        # Log the specific missing or invalid fields
        logger.critical("Configuration validation failed. Missing or invalid required secrets:")
        for error in e.errors():
            field_name = ".".join(str(loc) for loc in error['loc'])
            error_msg = error['msg']
            logger.critical(f"  - {field_name}: {error_msg}")
        
        # Provide helpful instructions
        logger.critical("\nRequired environment variables:")
        logger.critical("  ENV - Runtime environment (development, testing, staging, production)")
        logger.critical("  SECRET_KEY - Application secret key (min 32 chars)")
        logger.critical("  JWT_SECRET_KEY - JWT signing key (min 32 chars)")
        logger.critical("  DATABASE_URL - PostgreSQL connection URL (required in production)")
        logger.critical("\nOptional for billing features:")
        logger.critical("  STRIPE_SECRET_KEY - Stripe API secret key")
        logger.critical("  STRIPE_PUBLIC_KEY - Stripe publishable key")
        logger.critical("  STRIPE_WEBHOOK_SECRET - Stripe webhook signing secret")
        logger.critical("  STRIPE_PRICE_ID - Stripe price ID (e.g., price_xxxxx)")
        logger.critical("\nSet these in your .env file or as environment variables.")
        
        # Exit with error code to prevent app from starting
        sys.exit(1)

# ===== Global settings instance =====
settings = get_settings()

# ===== Simple compatibility interface =====
def get_simple_settings() -> Settings:
    """
    Simple interface for backward compatibility.
    Returns the same settings instance.
    """
    return settings

# ===== Legacy Simple Interface Functions =====
# These functions provide the exact interface from your simple config
def get_secret_key() -> str:
    """Legacy function to get secret key as string."""
    return settings.secret_key_str

def get_stripe_secret_key() -> Optional[str]:
    """Legacy function to get Stripe secret key."""
    return settings.stripe_secret_key

def get_stripe_webhook_secret() -> Optional[str]:
    """Legacy function to get Stripe webhook secret."""
    return settings.stripe_webhook_secret

def get_stripe_price_id_simple() -> Optional[str]:
    """Legacy function to get Stripe price ID."""
    return settings.STRIPE_PRICE_ID

def get_database_url_simple() -> Optional[str]:
    """Legacy function to get database URL."""
    return settings.database_url_str

# ===== Configuration utility functions =====
def get_database_url() -> str:
    """Get database URL with connection parameters."""
    if not settings.DATABASE.URL:
        raise ValueError("DATABASE_URL is not configured")
    
    url = str(settings.DATABASE.URL)
    if settings.is_production:
        # Add SSL parameters for production
        if "?" in url:
            url += "&sslmode=require"
        else:
            url += "?sslmode=require"
    return url

def get_redis_url() -> Optional[str]:
    """Get Redis URL if cache backend is Redis."""
    if settings.CACHE.BACKEND == CacheBackend.REDIS and settings.CACHE.REDIS_URL:
        return str(settings.CACHE.REDIS_URL)
    return None

def get_stripe_price_id(plan: str, period: str = "monthly") -> Optional[str]:
    """Get Stripe price ID for a plan and billing period."""
    key = f"{plan}_{period}"
    return settings.STRIPE.PRICES.get(key)

def is_feature_enabled(feature: str) -> bool:
    """Check if a feature flag is enabled."""
    return settings.FEATURE_FLAGS.get(feature, False)

def get_jwt_expiration() -> timedelta:
    """Get JWT token expiration as timedelta."""
    return timedelta(minutes=settings.SECURITY.JWT_ACCESS_TOKEN_EXPIRE_MINUTES)

def get_refresh_token_expiration() -> timedelta:
    """Get refresh token expiration as timedelta."""
    return timedelta(days=settings.SECURITY.JWT_REFRESH_TOKEN_EXPIRE_DAYS)

def get_grace_period() -> timedelta:
    """Get subscription grace period as timedelta."""
    return timedelta(days=settings.BILLING.GRACE_PERIOD_DAYS)

def get_config() -> Settings:
    """Alias for get_settings for compatibility with existing code."""
    return settings

def get_rate_limit_default() -> str:
    """Get rate limit default string based on environment."""
    if settings.is_production:
        return "100 per day, 20 per hour"
    else:
        return "1000 per day, 200 per hour"

def get_rate_limit_auth() -> str:
    """Get rate limit for authentication endpoints."""
    if settings.is_production:
        return "5 per minute"
    else:
        return "10 per minute"

# Environment-specific configuration helpers
def get_email_backend_config() -> Dict[str, Any]:
    """Get email backend configuration based on environment."""
    if settings.is_development:
        return {
            "backend": "console",
            "use_tls": False,
            "use_ssl": False,
        }
    
    return {
        "backend": settings.EMAIL.PROVIDER,
        "host": settings.EMAIL.SMTP_HOST,
        "port": settings.EMAIL.SMTP_PORT,
        "username": settings.EMAIL.SMTP_USERNAME,
        "password": settings.EMAIL.SMTP_PASSWORD.get_secret_value() if settings.EMAIL.SMTP_PASSWORD else None,
        "use_tls": settings.EMAIL.SMTP_USE_TLS,
        "use_ssl": settings.EMAIL.SMTP_USE_SSL,
    }

def get_logging_config() -> Dict[str, Any]:
    """Get logging configuration."""
    config = {
        "version": 1,
        "disable_existing_loggers": False,
        "formatters": {
            "standard": {
                "format": settings.LOGGING.FORMAT,
                "datefmt": settings.LOGGING.DATE_FORMAT,
            },
            "json": {
                "()": "pythonjsonlogger.jsonlogger.JsonFormatter",
                "fmt": settings.LOGGING.FORMAT,
                "datefmt": settings.LOGGING.DATE_FORMAT,
            },
        },
        "handlers": {
            "console": {
                "level": settings.LOGGING.LEVEL.value,
                "class": "logging.StreamHandler",
                "formatter": "json" if settings.LOGGING.JSON_LOGS else "standard",
            },
        },
        "loggers": {
            "": {  # Root logger
                "handlers": ["console"],
                "level": settings.LOGGING.LEVEL.value,
                "propagate": True,
            },
            "app.billing": {
                "handlers": ["console"],
                "level": "INFO",
                "propagate": False,
            },
        },
    }
    
    if settings.LOGGING.FILE_ENABLED:
        config["handlers"]["file"] = {
            "level": settings.LOGGING.LEVEL.value,
            "class": "logging.handlers.RotatingFileHandler",
            "filename": settings.LOGGING.FILE_PATH,
            "maxBytes": settings.LOGGING.FILE_MAX_SIZE,
            "backupCount": settings.LOGGING.FILE_BACKUP_COUNT,
            "formatter": "standard",
        }
        config["loggers"][""]["handlers"].append("file")
    
    return config

# ===== Export useful functions and classes =====
__all__ = [
    # Main classes
    "Settings",
    "Environment",
    "LogLevel",
    "CacheBackend",
    "PaymentProvider",
    
    # Settings instances
    "settings",
    "get_settings",
    "get_config",
    "get_simple_settings",  # Simple compatibility interface
    
    # Legacy Simple Interface Functions
    "get_secret_key",
    "get_stripe_secret_key",
    "get_stripe_webhook_secret",
    "get_stripe_price_id_simple",
    "get_database_url_simple",
    
    # Validator
    "EnvironmentValidator",
    "RequiredVar",
    
    # Utility functions
    "get_database_url",
    "get_redis_url",
    "get_stripe_price_id",
    "is_feature_enabled",
    "get_jwt_expiration",
    "get_refresh_token_expiration",
    "get_grace_period",
    "get_rate_limit_default",
    "get_rate_limit_auth",
    "get_email_backend_config",
    "get_logging_config",
    
    # AWS functions
    "load_aws_secrets",
]