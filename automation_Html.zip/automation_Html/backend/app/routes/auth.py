# backend/routes/auth.py - Updated with better rate limiting

from flask import Blueprint, request, jsonify
from flask_jwt_extended import (
    create_access_token,
    create_refresh_token,
    set_refresh_cookies,
    set_access_cookies
)
from app.extensions import limiter
from app.utils.rate_limit import email_rate_limit  # Import the new utility

auth_bp = Blueprint("auth", __name__)

@auth_bp.post("/login")
@limiter.limit("10 per minute", per_method=True)  # General endpoint limit
@email_rate_limit("5 per minute")  # Email-specific limit (prevents targeting specific users)
def login():
    data = request.json
    email = data.get("email")
    password = data.get("password")

    # Add small delay to slow down brute force attempts
    import time
    time.sleep(0.5)  # Half second delay

    user = authenticate_user(email, password)
    if not user:
        return jsonify({"error": "Invalid credentials"}), 401

    access_token = create_access_token(
        identity=user.id,
        additional_claims={
            "role": user.role,
            "plan": user.plan
        }
    )
    refresh_token = create_refresh_token(identity=user.id)

    response = jsonify({
        "access_token": access_token,
        "user": {
            "id": user.id,
            "email": user.email,
            "role": user.role,
            "plan": user.plan
        }
    })

    # 🔒 refresh token in HttpOnly cookie
    set_refresh_cookies(response, refresh_token)

    return response