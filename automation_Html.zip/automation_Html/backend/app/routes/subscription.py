from sqlalchemy.exc import SQLAlchemyError
from fastapi import HTTPException

def create_subscription_and_automation(db, user_id, plan):
    try:
        subscription = Subscription(user_id=user_id, plan=plan)
        automation = Automation(user_id=user_id)

        db.add(subscription)
        db.add(automation)

        db.flush()  # validates DB constraints
        return subscription

    except SQLAlchemyError:
        raise HTTPException(
            status_code=500,
            detail="Transaction failed"
        )
