# 📁 routes/health.py (root level - for global health checks)
from flask import Blueprint, jsonify, current_app
from datetime import datetime
import psutil
import os

health_bp = Blueprint("global_health", __name__)

@health_bp.route("/health")
def global_health():
    """Global health check (not versioned) for infrastructure monitoring."""
    logger = current_app.logger
    
    return jsonify({
        "status": "ok",
        "service": "backend-api",
        "timestamp": datetime.utcnow().isoformat(),
        "environment": os.getenv("FLASK_ENV", "development"),
        "endpoints": {
            "v1_health": "/v1/health",
            "v1_readiness": "/v1/health/readiness",
            "v1_liveness": "/v1/health/liveness"
        }
    }), 200


@health_bp.route("/")
def root():
    """Root endpoint with service information."""
    return jsonify({
        "service": "Backend API",
        "version": os.getenv("APP_VERSION", "1.0.0"),
        "status": "operational",
        "documentation": "/docs",  # If you have API docs
        "health": "/health",
        "api_v1": "/v1"
    }), 200