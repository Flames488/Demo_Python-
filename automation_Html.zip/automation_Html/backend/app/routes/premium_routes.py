from flask import Blueprint, jsonify, current_app
from backend.middleware.subscription import subscription_required
from backend.errors import ForbiddenError, NotFoundError
from datetime import datetime

premium_bp = Blueprint("premium", __name__)

@premium_bp.route("/premium-data")
@subscription_required("premium")
def get_premium_data():
    logger = current_app.logger
    
    try:
        # Your business logic here
        premium_content = fetch_premium_content()
        
        if not premium_content:
            logger.warning("premium_content_not_found")
            raise NotFoundError("Premium content not found")
        
        logger.info(
            "premium_data_accessed",
            extra={
                "user_id": current_user.id if current_user.is_authenticated else None
            }
        )
        return jsonify({
            "data": "This is premium content only!",
            "accessed_at": datetime.utcnow().isoformat()
        })
        
    except Exception as e:
        logger.error(
            "premium_data_error",
            extra={
                "error": str(e),
                "exception_type": type(e).__name__
            },
            exc_info=True
        )
        raise