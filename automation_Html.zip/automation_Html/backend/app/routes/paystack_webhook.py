import hashlib
from flask import request, jsonify
from app.models import BillingEvent
from app.services.billing import activate_subscription
from app.extensions import db

@api.route("/webhooks/paystack", methods=["POST"])
def paystack_webhook():
    signature = request.headers.get("X-Paystack-Signature")
    computed = hashlib.sha512(
        request.data + current_app.config["PAYSTACK_WEBHOOK_SECRET"].encode()
    ).hexdigest()

    if signature != computed:
        return jsonify({"error": "Invalid signature"}), 400

    event = request.json

    if BillingEvent.query.get(event["event"]):
        return jsonify({"status": "duplicate"}), 200

    if event["event"] == "charge.success":
        data = event["data"]
        meta = data["metadata"]

        with db.session.begin():
            activate_subscription(meta["user_id"], meta["plan"])
            db.session.add(BillingEvent(id=data["reference"]))

    return jsonify({"status": "ok"}), 200
