from flask import Blueprint, request, jsonify, current_app
import hmac
import hashlib
from datetime import datetime, timedelta
from models import User
from billing.plans import PLAN_MAP
from extensions import db
import os
from backend.errors import BusinessError, NotFoundError

webhook_bp = Blueprint("webhook", __name__)

WEBHOOK_SECRET = os.getenv("PAYMENT_WEBHOOK_SECRET")

def verify_signature(payload, signature):
    """Verify the HMAC signature of the webhook payload."""
    if not WEBHOOK_SECRET:
        current_app.logger.error("webhook_secret_missing")
        return False
        
    computed = hmac.new(
        WEBHOOK_SECRET.encode(),
        payload,
        hashlib.sha256
    ).hexdigest()
    return hmac.compare_digest(computed, signature)

def handle_payment_success(event):
    """Handle successful payment events."""
    logger = current_app.logger
    
    try:
        email = event.get("customer", {}).get("email")
        plan = event.get("metadata", {}).get("plan")
        
        if not email:
            logger.error("missing_email_in_webhook")
            raise BusinessError("Missing customer email in webhook", "MISSING_EMAIL")
        if not plan:
            logger.error("missing_plan_in_webhook")
            raise BusinessError("Missing plan in webhook metadata", "MISSING_PLAN")
            
        if plan not in PLAN_MAP:
            logger.error("invalid_plan_in_webhook", extra={"plan": plan})
            raise BusinessError(f"Invalid plan '{plan}' in webhook", "INVALID_PLAN")

        user = User.query.filter_by(email=email).first()
        if not user:
            logger.warning("user_not_found_for_webhook", extra={"email": email})
            raise NotFoundError(f"User with email {email} not found", "USER_NOT_FOUND")

        duration = PLAN_MAP[plan]["duration_days"]

        if user.plan_expires_at and user.plan_expires_at > datetime.utcnow():
            user.plan_expires_at += timedelta(days=duration)
        else:
            user.plan_expires_at = datetime.utcnow() + timedelta(days=duration)

        user.plan = plan

        db.session.commit()
        
        logger.info(
            "user_upgraded",
            extra={
                "user_id": user.id,
                "plan": plan,
                "expires_at": user.plan_expires_at.isoformat()
            }
        )
        
        return jsonify({
            "status": "upgraded",
            "user_id": user.id,
            "plan": plan,
            "expires_at": user.plan_expires_at.isoformat()
        })
        
    except Exception as e:
        logger.error(
            "payment_webhook_error",
            extra={
                "error": str(e),
                "exception_type": type(e).__name__,
                "event_type": "payment.success"
            },
            exc_info=True
        )
        db.session.rollback()
        raise

def handle_subscription_cancel(event):
    """Handle subscription cancellation events."""
    logger = current_app.logger
    
    try:
        logger.info(
            "subscription_cancelled",
            extra={"event_data": str(event)[:500]}  # Limit log size
        )
        return jsonify({
            "status": "cancellation_handled",
            "message": "Cancellation processed"
        })
        
    except Exception as e:
        logger.error(
            "subscription_cancel_error",
            extra={
                "error": str(e),
                "exception_type": type(e).__name__,
                "event_type": "subscription.cancelled"
            },
            exc_info=True
        )
        raise

@webhook_bp.post("/payment")
def payment_webhook():
    """Main webhook endpoint for payment events."""
    logger = current_app.logger
    
    try:
        payload = request.data
        signature = request.headers.get("X-Payment-Signature")

        if not signature:
            logger.warning("missing_signature_header")
            raise BusinessError("Missing signature header", "MISSING_SIGNATURE")
            
        if not verify_signature(payload, signature):
            logger.warning(
                "invalid_webhook_signature",
                extra={"remote_addr": request.remote_addr}
            )
            raise BusinessError("Invalid signature", "INVALID_SIGNATURE")

        event = request.json
        if not event:
            logger.warning("invalid_json_payload")
            raise BusinessError("Invalid JSON payload", "INVALID_PAYLOAD")
            
        event_type = event.get("event")
        if not event_type:
            logger.warning("missing_event_type")
            raise BusinessError("Missing event type", "MISSING_EVENT_TYPE")

        logger.info("processing_webhook_event", extra={"event_type": event_type})

        if event_type == "payment.success":
            return handle_payment_success(event)

        if event_type == "subscription.cancelled":
            return handle_subscription_cancel(event)

        logger.warning(
            "unhandled_webhook_event",
            extra={"event_type": event_type}
        )
        return jsonify({
            "status": "ignored",
            "message": f"Event type '{event_type}' not handled"
        }), 200

    except BusinessError as e:
        logger.warning(
            "business_error_in_webhook",
            extra={
                "error": str(e),
                "error_code": getattr(e, "code", "UNKNOWN")
            }
        )
        raise e
    except Exception as e:
        logger.error(
            "unexpected_webhook_error",
            extra={
                "error": str(e),
                "exception_type": type(e).__name__
            },
            exc_info=True
        )
        raise