# billing.py - Flask version optimized for Railway/Render deployment
import stripe
import logging
from datetime import datetime
from flask import Blueprint, request, jsonify, current_app
from sqlalchemy.exc import IntegrityError
from functools import wraps
import os

from core.config import settings
from models.user import User
from models.stripe_event import StripeEvent
from app.extensions import db

# Import or define your service layer
try:
    from services.billing_service import BillingService
except ImportError:
    # Fallback: define a basic BillingService if not available
    class BillingService:
        def __init__(self, db_session):
            self.db = db_session
        
        def create_checkout_session(self, user, plan, success_url, cancel_url, 
                                   promotion_code=None, trial_days=None):
            # This should be implemented in your service layer
            raise NotImplementedError("BillingService.create_checkout_session not implemented")
        
        def process_webhook_event(self, event_type, event_id, data):
            # This should be implemented in your service layer
            raise NotImplementedError("BillingService.process_webhook_event not implemented")
        
        def cancel_subscription(self, user_id):
            # This should be implemented in your service layer
            raise NotImplementedError("BillingService.cancel_subscription not implemented")

logger = logging.getLogger(__name__)

# Configure Stripe - use environment variable if available
stripe_api_key = os.environ.get('STRIPE_SECRET_KEY', settings.STRIPE_SECRET_KEY)
stripe.api_key = stripe_api_key

# Get webhook secret from environment or settings
stripe_webhook_secret = os.environ.get('STRIPE_WEBHOOK_SECRET', settings.STRIPE_WEBHOOK_SECRET)

bp = Blueprint("billing", __name__, url_prefix="/billing")

# Helper decorator for authentication
def auth_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        # Implement your authentication logic here
        # This is a placeholder - replace with your actual auth logic
        auth_header = request.headers.get('Authorization')
        if not auth_header:
            return jsonify({"error": "Missing authorization header"}), 401
        
        # Extract and validate token
        # For now, we'll use a mock user
        # Replace with actual user lookup from token
        mock_user = User(id=1, email="user@example.com")
        return f(current_user=mock_user, *args, **kwargs)
    return decorated_function

# Helper function for error responses
def error_response(message, status_code=400, code=None):
    response = {"error": message}
    if code:
        response["code"] = code
    return jsonify(response), status_code

# Helper to get base URL for webhooks
def get_base_url():
    """Get the base URL for the application dynamically"""
    # Check for Railway/Render environment variables
    railway_public_url = os.environ.get('RAILWAY_PUBLIC_DOMAIN')
    render_url = os.environ.get('RENDER_EXTERNAL_URL')
    
    if railway_public_url:
        return f"https://{railway_public_url}"
    elif render_url:
        return render_url
    else:
        # For local development
        return request.host_url.rstrip('/')

# Enums and Pydantic-like validation
PLAN_TYPES = ["pro", "business", "enterprise"]

# Request validation helper
def validate_checkout_request(data):
    required_fields = ["plan"]
    for field in required_fields:
        if field not in data:
            return False, f"Missing required field: {field}"
    
    if data["plan"] not in PLAN_TYPES:
        return False, "Invalid plan type"
    
    # Validate URLs if provided
    for url_field in ["success_url", "cancel_url"]:
        if url_field in data and data[url_field]:
            if not data[url_field].startswith(('http://', 'https://')):
                return False, f"{url_field} must be a valid HTTP/HTTPS URL"
    
    # Validate trial_days
    if "trial_days" in data and data["trial_days"] is not None:
        try:
            trial_days = int(data["trial_days"])
            if not 0 <= trial_days <= 30:
                return False, "trial_days must be between 0 and 30"
        except (ValueError, TypeError):
            return False, "trial_days must be an integer"
    
    return True, ""

# Webhook handlers
def handle_checkout_completed(event):
    """Handle successful checkout completion"""
    session = event["data"]["object"]
    
    customer_id = session["customer"]
    subscription_id = session["subscription"]
    
    user = User.query.filter_by(stripe_customer_id=customer_id).first()
    if not user:
        return
    
    user.stripe_subscription_id = subscription_id
    user.subscription_status = "active"
    user.plan = "pro"
    
    # Add user to session for saving
    db.session.add(user)
    
    logger.info(f"Updated user {user.id} subscription to active (customer: {customer_id}, subscription: {subscription_id})")

def handle_subscription_canceled(event):
    """Handle subscription cancellation"""
    subscription = event["data"]["object"]
    
    user = User.query.filter_by(
        stripe_subscription_id=subscription["id"]
    ).first()
    
    if not user:
        return
    
    user.subscription_status = "canceled"
    user.plan = "free"
    
    # Add user to session for saving
    db.session.add(user)
    
    logger.info(f"Updated user {user.id} subscription to canceled (subscription: {subscription['id']})")

@bp.route("/checkout", methods=["POST"])
@auth_required
def create_checkout(current_user):
    """
    Create a checkout session for subscription purchase.
    
    Expected JSON payload:
    {
        "plan": "pro|business|enterprise",
        "success_url": "https://example.com/success",
        "cancel_url": "https://example.com/cancel",
        "promotion_code": "optional_code",
        "trial_days": 14
    }
    """
    try:
        data = request.get_json()
        if not data:
            return error_response("No JSON data provided", 400)
        
        # Validate request
        is_valid, error_msg = validate_checkout_request(data)
        if not is_valid:
            return error_response(error_msg, 400, "VALIDATION_ERROR")
        
        billing_service = BillingService(db.session)
        
        # Use provided URLs or generate defaults
        success_url = data.get("success_url") or f"{get_base_url()}/success"
        cancel_url = data.get("cancel_url") or f"{get_base_url()}/cancel"
        
        # Call service layer for business logic
        session_data = billing_service.create_checkout_session(
            user=current_user,
            plan=data["plan"],
            success_url=success_url,
            cancel_url=cancel_url,
            promotion_code=data.get("promotion_code"),
            trial_days=data.get("trial_days")
        )
        
        response = {
            "checkout_url": session_data["url"],
            "session_id": session_data["id"],
            "plan": data["plan"],
            "expires_in": "30 minutes",
            "amount_total": session_data.get("amount_total", 0),
            "currency": session_data.get("currency", "usd"),
            "expires_at": datetime.fromtimestamp(session_data["expires_at"]).isoformat(),
            "debug": {
                "base_url": get_base_url(),
                "environment": "production" if os.environ.get('RAILWAY_ENVIRONMENT') or os.environ.get('RENDER') else "development"
            }
        }
        
        return jsonify(response), 200
        
    except ValueError as e:
        return error_response(str(e), 400, "VALIDATION_ERROR")
    except NotImplementedError as e:
        logger.error(f"Billing service not implemented: {str(e)}")
        return error_response("Service not implemented", 501)
    except Exception as e:
        logger.error(f"Error in checkout: {str(e)}", exc_info=True)
        return error_response("Internal server error", 500, "INTERNAL_ERROR")

@bp.route("/webhooks/stripe", methods=["POST"])
def stripe_webhook():
    """
    Handle Stripe webhook events.
    This endpoint works with Railway/Render deployments.
    """
    try:
        # Verify webhook signature
        payload = request.get_data()
        sig_header = request.headers.get("Stripe-Signature")
        
        if not sig_header:
            logger.error("Missing Stripe signature header")
            return error_response("Missing Stripe signature", 400)
        
        if not stripe_webhook_secret:
            logger.error("Stripe webhook secret not configured")
            return error_response("Webhook not configured", 500)
        
        try:
            event = stripe.Webhook.construct_event(
                payload, sig_header, stripe_webhook_secret
            )
        except ValueError as e:
            logger.error(f"Invalid payload: {str(e)}")
            return error_response("Invalid payload", 400)
        except stripe.error.SignatureVerificationError as e:
            logger.error(f"Invalid signature: {str(e)}")
            return error_response("Invalid signature", 401)
        
        # Convert event to dictionary for easy access
        event_dict = event.to_dict()
        event_id = event_dict["id"]
        event_type = event_dict["type"]
        
        # Log the received event (without sensitive data)
        logger.info(f"Received Stripe webhook: {event_type} (ID: {event_id})")
        
        try:
            with db.session.begin():
                # Save event first (locks idempotency)
                db.session.add(StripeEvent(stripe_event_id=event_id, event_type=event_type))

                if event_type == "checkout.session.completed":
                    handle_checkout_completed(event_dict)

                elif event_type == "customer.subscription.deleted":
                    handle_subscription_canceled(event_dict)

            return "Success", 200

        except IntegrityError:
            # Duplicate insert race condition
            db.session.rollback()
            logger.info(f"Event {event_id} already processed - idempotent response")
            return "Duplicate", 200

        except Exception as e:
            db.session.rollback()
            logger.error(f"Failed to process webhook {event_id}: {str(e)}", exc_info=True)
            raise e  # Stripe WILL retry
        
    except Exception as e:
        logger.error(f"Unexpected error in webhook handler: {str(e)}", exc_info=True)
        return error_response("Internal server error", 500)

@bp.route("/stripe/webhook", methods=["POST"])
def stripe_webhook_legacy():
    """
    Legacy webhook endpoint for backward compatibility.
    Redirects to the main webhook endpoint.
    """
    logger.info("Legacy /stripe/webhook endpoint called - forwarding to main webhook")
    return stripe_webhook()

@bp.route("/subscription/cancel", methods=["POST"])
@auth_required
def cancel_subscription(current_user):
    """Cancel current subscription at period end"""
    try:
        billing_service = BillingService(db.session)
        billing_service.cancel_subscription(user_id=str(current_user.id))
        
        return jsonify({
            "message": "Subscription will be canceled at period end"
        }), 200
        
    except ValueError as e:
        return error_response(str(e), 404)
    except stripe.error.StripeError as e:
        return error_response(f"Failed to cancel subscription: {str(e)}", 400)
    except NotImplementedError as e:
        logger.error(f"Billing service not implemented: {str(e)}")
        return error_response("Service not implemented", 501)
    except Exception as e:
        logger.error(f"Error canceling subscription: {str(e)}", exc_info=True)
        return error_response("Internal server error", 500)

@bp.route("/webhook-test", methods=["GET", "POST"])
def webhook_test():
    """
    Test endpoint to verify webhook URL is accessible.
    Useful for Railway/Render to check if endpoint is live.
    """
    if request.method == "GET":
        return jsonify({
            "status": "webhook_endpoint_ready",
            "service": "stripe_webhooks",
            "environment": os.environ.get('RAILWAY_ENVIRONMENT') or os.environ.get('RENDER_SERVICE_NAME') or 'development',
            "url": f"{get_base_url()}/billing/webhooks/stripe",
            "instructions": "Configure this URL in Stripe Dashboard > Developers > Webhooks"
        })
    
    # POST - simulate a webhook for testing
    test_data = {
        "id": "evt_test_" + datetime.utcnow().strftime("%Y%m%d%H%M%S"),
        "type": "checkout.session.completed",
        "data": {
            "object": {
                "id": "cs_test_" + datetime.utcnow().strftime("%Y%m%d%H%M%S"),
                "customer": "cus_test123",
                "subscription": "sub_test123"
            }
        }
    }
    
    return jsonify({
        "test_webhook_received": True,
        "simulated_event": test_data,
        "message": "Webhook endpoint is working. Use the URL above in Stripe Dashboard."
    })

@bp.route("/health", methods=["GET"])
def billing_health():
    """Health check for billing service"""
    try:
        # Test Stripe connection
        stripe.Balance.retrieve()
        
        # Check environment
        env_info = {
            "railway": bool(os.environ.get('RAILWAY_ENVIRONMENT')),
            "render": bool(os.environ.get('RENDER')),
            "webhook_secret_configured": bool(stripe_webhook_secret),
            "base_url": get_base_url()
        }
        
        return jsonify({
            "status": "healthy",
            "timestamp": datetime.utcnow().isoformat(),
            "service": "billing",
            "environment": env_info,
            "webhook_url": f"{get_base_url()}/billing/webhooks/stripe"
        }), 200
        
    except Exception as e:
        logger.error(f"Billing health check failed: {str(e)}")
        return error_response("Billing service unavailable", 503)

@bp.route("/deploy-info", methods=["GET"])
def deploy_info():
    """
    Get deployment information for Railway/Render.
    Useful for debugging deployment issues.
    """
    env_vars = {
        key: "***SET***" if any(secret in key.lower() for secret in ['key', 'secret', 'password', 'token']) else value
        for key, value in os.environ.items()
        if any(platform in key.lower() for platform in ['railway', 'render', 'stripe', 'database', 'db'])
    }
    
    return jsonify({
        "platform": "railway" if os.environ.get('RAILWAY_ENVIRONMENT') else "render" if os.environ.get('RENDER') else "local",
        "public_url": get_base_url(),
        "relevant_env_vars": env_vars,
        "stripe_configured": bool(stripe_api_key),
        "webhook_secret_configured": bool(stripe_webhook_secret)
    })

# Middleware-like functionality for Flask
@bp.before_request
def log_request():
    if current_app.debug or os.environ.get('RAILWAY_ENVIRONMENT') or os.environ.get('RENDER'):
        logger.info(f"Billing API: {request.method} {request.path} from {request.remote_addr}")