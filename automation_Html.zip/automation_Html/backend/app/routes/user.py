from backend.errors import NotFoundError, AuthError  # Add this import
import logging

logger = logging.getLogger(__name__)

@user_bp.get("/me")
@jwt_required()
def me():
    try:
        user_id = get_jwt_identity()
        if not user_id:
            raise AuthError("Invalid token", "INVALID_TOKEN")

        user = User.query.get(user_id)
        if not user:
            raise NotFoundError("User not found", "USER_NOT_FOUND")

        # Check if user is active
        if not user.is_active:
            raise BusinessError("Account is deactivated", "ACCOUNT_DEACTIVATED")

        logger.info(f"User profile accessed: {user.id}")
        return jsonify({
            "id": user.id,
            "email": user.email,
            "role": user.role,
            "plan": user.plan,
            "expires_at": user.plan_expires_at.isoformat() if user.plan_expires_at else None,
            "is_active": user.is_active
        })
        
    except Exception as e:
        logger.error(f"Error in /me endpoint: {str(e)}")
        raise