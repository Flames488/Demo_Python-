# 📁 v1/health.py: 🧪 PHASE 4 — HEALTH, SAFETY & STABILITY
from flask import Blueprint, jsonify, current_app
from datetime import datetime
import psutil
import os
from models import db  # Assuming you have SQLAlchemy setup
from sqlalchemy import text

bp = Blueprint("health", __name__)

@bp.route("/health")
def health():
    """Comprehensive health check endpoint for monitoring and deployment validation.
    Maintains backward compatibility with existing simple response."""
    
    # For backward compatibility with existing consumers
    simple_response = request.args.get('simple', '').lower() == 'true'
    
    if simple_response:
        return jsonify({"status": "ok"})
    
    logger = current_app.logger
    
    try:
        # Basic status
        status = "ok"
        timestamp = datetime.utcnow().isoformat()
        
        # Collect health metrics
        health_info = {
            "status": status,
            "timestamp": timestamp,
            "service": "backend-api",
            "version": os.getenv("APP_VERSION", "1.0.0"),
            "api_version": "v1",
            "environment": os.getenv("FLASK_ENV", "development"),
            "checks": {}
        }
        
        # 1. Database connectivity check
        try:
            # Simple query to verify database connection
            db.session.execute(text("SELECT 1"))
            health_info["checks"]["database"] = {
                "status": "healthy",
                "message": "Database connection established"
            }
        except Exception as db_error:
            status = "degraded"
            health_info["checks"]["database"] = {
                "status": "unhealthy",
                "message": str(db_error),
                "error_type": type(db_error).__name__
            }
        
        # 2. System resource monitoring (optional)
        try:
            cpu_percent = psutil.cpu_percent(interval=0.1)
            memory = psutil.virtual_memory()
            
            health_info["checks"]["system_resources"] = {
                "status": "healthy",
                "cpu_percent": cpu_percent,
                "memory": {
                    "total": memory.total,
                    "available": memory.available,
                    "percent": memory.percent
                }
            }
            
            if cpu_percent > 90 or memory.percent > 90:
                logger.warning("High resource usage detected", extra={
                    "cpu_percent": cpu_percent,
                    "memory_percent": memory.percent
                })
                
        except Exception as sys_error:
            # Don't fail health check if system metrics fail
            health_info["checks"]["system_resources"] = {
                "status": "unavailable",
                "message": f"Could not fetch system metrics: {str(sys_error)}"
            }
        
        # 3. Configuration checks
        try:
            webhook_secret = os.getenv("PAYMENT_WEBHOOK_SECRET")
            health_info["checks"]["configuration"] = {
                "status": "healthy" if webhook_secret else "warning",
                "webhook_secret_configured": bool(webhook_secret),
                "jwt_secret_configured": bool(os.getenv("JWT_SECRET_KEY"))
            }
            
        except Exception as config_error:
            health_info["checks"]["configuration"] = {
                "status": "error",
                "message": str(config_error)
            }
        
        # Log health check
        logger.info(
            "health_check_v1",
            extra={
                "status": status,
                "timestamp": timestamp,
                "checks_performed": list(health_info["checks"].keys())
            }
        )
        
        # Determine HTTP status code
        http_status = 200 if status == "ok" else 503
        
        return jsonify(health_info), http_status
        
    except Exception as e:
        # Critical failure in health check itself
        logger.error(
            "health_check_v1_failed",
            extra={
                "error": str(e),
                "exception_type": type(e).__name__
            },
            exc_info=True
        )
        
        # Still return simple response on critical failure for backward compatibility
        return jsonify({
            "status": "error",
            "error": "Health check failed",
            "details": str(e)
        }), 500


@bp.route("/health/readiness")
def readiness():
    """Kubernetes-style readiness probe."""
    try:
        # Check database connectivity
        db.session.execute(text("SELECT 1"))
        
        return jsonify({
            "status": "ready",
            "timestamp": datetime.utcnow().isoformat(),
            "api_version": "v1"
        }), 200
        
    except Exception as e:
        current_app.logger.warning(f"Readiness probe failed: {str(e)}")
        return jsonify({
            "status": "not_ready",
            "timestamp": datetime.utcnow().isoformat(),
            "reason": str(e),
            "api_version": "v1"
        }), 503


@bp.route("/health/liveness")
def liveness():
    """Kubernetes-style liveness probe."""
    return jsonify({
        "status": "alive",
        "timestamp": datetime.utcnow().isoformat(),
        "pid": os.getpid(),
        "api_version": "v1"
    }), 200


@bp.route("/health/ping")
def ping():
    """Ultra-simple endpoint for basic connectivity checks."""
    return jsonify({"status": "pong"}), 200