def register_v1(app):
    from .health import bp
    app.register_blueprint(bp, url_prefix="/api/v1")