import stripe
from flask import request, jsonify
from app.models import BillingEvent
from app.services.billing import activate_subscription
from app.extensions import db

@api.route("/webhooks/stripe", methods=["POST"])
def stripe_webhook():
    payload = request.data
    sig = request.headers.get("Stripe-Signature")

    try:
        event = stripe.Webhook.construct_event(
            payload,
            sig,
            current_app.config["STRIPE_WEBHOOK_SECRET"]
        )
    except Exception:
        return jsonify({"error": "Invalid signature"}), 400

    if BillingEvent.query.get(event["id"]):
        return jsonify({"status": "duplicate"}), 200

    if event["type"] == "checkout.session.completed":
        session = event["data"]["object"]
        user_id = session["metadata"]["user_id"]
        plan = session["metadata"]["plan"]

        with db.session.begin():
            activate_subscription(user_id, plan)
            db.session.add(BillingEvent(id=event["id"]))

    return jsonify({"status": "ok"}), 200
