from fastapi import APIRouter, Depends, HTTPException, Request, Response, status
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from typing import Optional, Dict, Any
from datetime import datetime, timedelta
import re
import logging
from jose import JWTError, jwt
from passlib.context import CryptContext
from pydantic import BaseModel, EmailStr, validator
from app.infrastructure.rate_limiter import limiter
from app.models.user import User
from app.database import get_db, SessionLocal
from sqlalchemy.orm import Session
from sqlalchemy import or_

# Create router
router = APIRouter(prefix="/auth", tags=["authentication"])

# Configure logging
logger = logging.getLogger(__name__)

# JWT Configuration
SECRET_KEY = "your-secret-key-here-change-in-production"  # Change this!
ALGORITHM = "HS256"
ACCESS_TOKEN_EXPIRE_MINUTES = 60  # 1 hour
REFRESH_TOKEN_EXPIRE_DAYS = 7

# Password hashing
pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")

# Token blocklist (use Redis in production)
token_blocklist = set()

# Security
security = HTTPBearer()

# Pydantic models
class LoginRequest(BaseModel):
    username: Optional[str] = None
    email: Optional[EmailStr] = None
    password: str
    remember: bool = False
    use_cookies: bool = False
    
    @validator('username')
    def validate_username(cls, v):
        if v and len(v) > 100:
            raise ValueError('Username/Email too long')
        return v

class Token(BaseModel):
    access_token: str
    refresh_token: str
    token_type: str = "bearer"
    expires_in: int = 3600

class TokenData(BaseModel):
    user_id: str
    username: str
    email: str
    role: str
    plan: Optional[str] = None

class UserResponse(BaseModel):
    id: int
    username: str
    email: str
    role: str
    first_name: Optional[str] = None
    last_name: Optional[str] = None
    plan: Optional[str] = None
    
    class Config:
        from_attributes = True

# Utility functions
def validate_email(email: str) -> bool:
    """Validate email format"""
    pattern = r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$'
    return re.match(pattern, email) is not None

def validate_username(username: str) -> bool:
    """Validate username format"""
    pattern = r'^[a-zA-Z0-9_]{3,30}$'
    return re.match(pattern, username) is not None

def validate_password(password: str) -> tuple[bool, str]:
    """Validate password strength"""
    if len(password) < 8:
        return False, "Password must be at least 8 characters"
    if not any(char.isdigit() for char in password):
        return False, "Password must contain at least one number"
    if not any(char.isupper() for char in password):
        return False, "Password must contain at least one uppercase letter"
    if not any(char.islower() for char in password):
        return False, "Password must contain at least one lowercase letter"
    return True, "Password is valid"

def verify_password(plain_password: str, hashed_password: str) -> bool:
    """Verify password against hash"""
    return pwd_context.verify(plain_password, hashed_password)

def get_password_hash(password: str) -> str:
    """Generate password hash"""
    return pwd_context.hash(password)

def create_access_token(data: dict, expires_delta: Optional[timedelta] = None):
    """Create JWT access token"""
    to_encode = data.copy()
    if expires_delta:
        expire = datetime.utcnow() + expires_delta
    else:
        expire = datetime.utcnow() + timedelta(minutes=ACCESS_TOKEN_EXPIRE_MINUTES)
    
    to_encode.update({"exp": expire, "type": "access"})
    encoded_jwt = jwt.encode(to_encode, SECRET_KEY, algorithm=ALGORITHM)
    return encoded_jwt

def create_refresh_token(data: dict, expires_delta: Optional[timedelta] = None):
    """Create JWT refresh token"""
    to_encode = data.copy()
    if expires_delta:
        expire = datetime.utcnow() + expires_delta
    else:
        expire = datetime.utcnow() + timedelta(days=REFRESH_TOKEN_EXPIRE_DAYS)
    
    to_encode.update({"exp": expire, "type": "refresh"})
    encoded_jwt = jwt.encode(to_encode, SECRET_KEY, algorithm=ALGORITHM)
    return encoded_jwt

def decode_token(token: str) -> Dict[str, Any]:
    """Decode and validate JWT token"""
    try:
        payload = jwt.decode(token, SECRET_KEY, algorithms=[ALGORITHM])
        return payload
    except JWTError as e:
        logger.error(f"Token decode error: {str(e)}")
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid token",
            headers={"WWW-Authenticate": "Bearer"},
        )

async def get_current_user(
    credentials: HTTPAuthorizationCredentials = Depends(security),
    db: Session = Depends(get_db)
) -> User:
    """Get current user from JWT token"""
    token = credentials.credentials
    
    # Check if token is in blocklist
    if token in token_blocklist:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Token has been revoked"
        )
    
    try:
        payload = decode_token(token)
        user_id: str = payload.get("sub")
        token_type: str = payload.get("type")
        
        if user_id is None or token_type != "access":
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="Invalid token"
            )
        
        user = db.query(User).filter(User.id == user_id).first()
        if not user:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="User not found"
            )
        
        if not user.is_active:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="Account is disabled"
            )
        
        if hasattr(user, 'is_locked') and user.is_locked:
            raise HTTPException(
                status_code=status.HTTP_423_LOCKED,
                detail="Account is locked"
            )
        
        return user
    except JWTError:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid authentication credentials",
            headers={"WWW-Authenticate": "Bearer"},
        )

async def get_current_user_optional(
    request: Request,
    db: Session = Depends(get_db)
) -> Optional[User]:
    """Get current user if token exists (optional)"""
    auth_header = request.headers.get("Authorization")
    if not auth_header:
        return None
    
    try:
        scheme, token = auth_header.split()
        if scheme.lower() != "bearer":
            return None
        
        if token in token_blocklist:
            return None
        
        payload = decode_token(token)
        user_id: str = payload.get("sub")
        token_type: str = payload.get("type")
        
        if not user_id or token_type != "access":
            return None
        
        user = db.query(User).filter(User.id == user_id).first()
        if not user or not user.is_active:
            return None
        
        if hasattr(user, 'is_locked') and user.is_locked:
            return None
        
        return user
    except Exception:
        return None

# Routes
@router.post("/login")
@limiter.limit("5/minute")
async def login(
    request: Request,
    login_data: LoginRequest,
    response: Response,
    db: Session = Depends(get_db)
):
    """Login endpoint with proper validation and security"""
    # Determine identifier
    identifier = login_data.email if login_data.email else login_data.username
    
    if not identifier or not login_data.password:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Username/Email and password required"
        )
    
    if len(identifier) > 100:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Invalid username or email"
        )
    
    try:
        # Find user by username or email
        user = db.query(User).filter(
            or_(User.username == identifier, User.email == identifier)
        ).first()
        
        if user and verify_password(login_data.password, user.password_hash):
            # Verify user is active
            if not user.is_active:
                logger.warning(f"Disabled account login attempt: {identifier}")
                raise HTTPException(
                    status_code=status.HTTP_403_FORBIDDEN,
                    detail="Account is disabled"
                )
            
            # Check if account is locked
            if hasattr(user, 'is_locked') and user.is_locked:
                logger.warning(f"Locked account login attempt: {identifier}")
                raise HTTPException(
                    status_code=status.HTTP_423_LOCKED,
                    detail="Account is locked"
                )
            
            # Prepare token data
            token_data = {
                "sub": str(user.id),
                "username": user.username,
                "email": user.email,
                "role": user.role,
            }
            
            # Add plan claim if user has plan attribute
            if hasattr(user, 'plan'):
                token_data["plan"] = user.plan
            
            # Create tokens
            access_token = create_access_token(
                token_data,
                expires_delta=timedelta(hours=1)
            )
            
            refresh_token = create_refresh_token(
                token_data,
                expires_delta=timedelta(days=7)
            )
            
            # Update last login timestamp if field exists
            if hasattr(user, 'last_login_at'):
                user.last_login_at = datetime.utcnow()
                db.commit()
            
            # Log successful login
            user_agent = request.headers.get('User-Agent', 'Unknown')
            client_host = request.client.host if request.client else "Unknown"
            
            logger.info(
                f"User {user.username} (ID: {user.id}) logged in successfully from IP: {client_host}. "
                f"User-Agent: {user_agent[:100]}"
            )
            
            # Reset failed login attempts on successful login
            if hasattr(user, 'failed_login_attempts'):
                user.failed_login_attempts = 0
                db.commit()
            
            # Prepare user data
            user_data = {
                "id": user.id,
                "username": user.username,
                "email": user.email,
                "role": user.role,
                "first_name": getattr(user, 'first_name', ''),
                "last_name": getattr(user, 'last_name', '')
            }
            
            # Add plan to user data if exists
            if hasattr(user, 'plan'):
                user_data["plan"] = user.plan
            
            # Set cookies if requested
            if login_data.use_cookies:
                response.set_cookie(
                    key="refresh_token",
                    value=refresh_token,
                    httponly=True,
                    secure=True,  # Set to True in production with HTTPS
                    samesite="lax",
                    max_age=7*24*60*60  # 7 days
                )
                response.set_cookie(
                    key="access_token",
                    value=access_token,
                    httponly=True,
                    secure=True,
                    samesite="lax",
                    max_age=60*60  # 1 hour
                )
            
            return {
                "status": "success",
                "message": "Login successful",
                "access_token": access_token,
                "user": user_data,
                "tokens": {
                    "access_token": access_token,
                    "refresh_token": refresh_token,
                    "expires_in": 3600
                }
            }
        
        else:
            # Log failed login attempt
            client_host = request.client.host if request.client else "Unknown"
            logger.warning(
                f"Failed login attempt for identifier: {identifier} from IP: {client_host}"
            )
            
            if user and hasattr(user, 'failed_login_attempts'):
                user.failed_login_attempts = getattr(user, 'failed_login_attempts', 0) + 1
                if user.failed_login_attempts >= 5:
                    if hasattr(user, 'is_locked'):
                        user.is_locked = True
                        logger.warning(f"Account {identifier} locked due to too many failed attempts")
                db.commit()
            
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="Invalid username/email or password"
            )
    
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Login error for identifier {identifier}: {str(e)}", exc_info=True)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Internal server error"
        )

@router.post("/logout")
async def logout(
    request: Request,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """Logout endpoint - invalidates JWT tokens"""
    try:
        auth_header = request.headers.get("Authorization")
        if auth_header:
            scheme, token = auth_header.split()
            if scheme.lower() == "bearer":
                token_blocklist.add(token)
        
        # Also check for token in cookies
        access_token = request.cookies.get("access_token")
        if access_token:
            token_blocklist.add(access_token)
        
        # Log logout event
        client_host = request.client.host if request.client else "Unknown"
        logger.info(f"User {current_user.username} (ID: {current_user.id}) logged out from IP: {client_host}")
        
        response = {
            "status": "success",
            "message": "Logged out successfully"
        }
        
        return response
    
    except Exception as e:
        logger.error(f"Logout error: {str(e)}", exc_info=True)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Internal server error"
        )

@router.post("/refresh")
async def refresh_token(
    request: Request,
    db: Session = Depends(get_db)
):
    """Refresh access token using refresh token"""
    try:
        # Get refresh token from cookies or Authorization header
        refresh_token = None
        
        # Check cookies first
        refresh_token = request.cookies.get("refresh_token")
        
        # If not in cookies, check Authorization header
        if not refresh_token:
            auth_header = request.headers.get("Authorization")
            if auth_header:
                scheme, token = auth_header.split()
                if scheme.lower() == "bearer":
                    # We need to decode to check token type
                    try:
                        payload = decode_token(token)
                        if payload.get("type") == "refresh":
                            refresh_token = token
                    except:
                        pass
        
        if not refresh_token:
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="Refresh token required"
            )
        
        # Check if refresh token is revoked
        if refresh_token in token_blocklist:
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="Refresh token has been revoked"
            )
        
        # Decode refresh token
        payload = decode_token(refresh_token)
        
        if payload.get("type") != "refresh":
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="Invalid token type"
            )
        
        user_id = payload.get("sub")
        user = db.query(User).filter(User.id == user_id).first()
        
        if not user or not user.is_active:
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="User not found or inactive"
            )
        
        # Create new access token
        token_data = {
            "sub": str(user.id),
            "username": user.username,
            "email": user.email,
            "role": user.role,
        }
        
        if hasattr(user, 'plan'):
            token_data["plan"] = user.plan
        
        access_token = create_access_token(
            token_data,
            expires_delta=timedelta(hours=1)
        )
        
        logger.info(f"Token refreshed for user: {user.username} (ID: {user.id})")
        
        return {
            "status": "success",
            "message": "Token refreshed",
            "access_token": access_token,
            "expires_in": 3600
        }
    
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Token refresh error: {str(e)}", exc_info=True)
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid refresh token"
        )

@router.get("/protected")
async def protected_endpoint(
    current_user: User = Depends(get_current_user)
):
    """Example protected endpoint using JWT"""
    try:
        user_data = {
            "id": current_user.id,
            "username": current_user.username,
            "email": current_user.email,
            "role": current_user.role
        }
        
        if hasattr(current_user, 'plan'):
            user_data["plan"] = current_user.plan
        
        return {
            "status": "success",
            "message": f"Hello {current_user.username}!",
            "user_data": user_data
        }
    
    except Exception as e:
        logger.error(f"Protected endpoint error: {str(e)}", exc_info=True)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Internal server error"
        )

@router.get("/session/jwt-check")
async def jwt_check_session(
    current_user: Optional[User] = Depends(get_current_user_optional)
):
    """Check if user is authenticated via JWT"""
    if current_user:
        user_data = {
            "id": current_user.id,
            "username": current_user.username,
            "email": current_user.email,
            "role": current_user.role
        }
        
        if hasattr(current_user, 'plan'):
            user_data["plan"] = current_user.plan
        
        return {
            "authenticated": True,
            "user": user_data
        }
    
    return {"authenticated": False}

@router.get("/user/profile")
async def get_profile(
    current_user: User = Depends(get_current_user)
):
    """Get current user's profile"""
    try:
        user_data = {
            "id": current_user.id,
            "username": current_user.username,
            "email": current_user.email,
            "role": current_user.role,
            "first_name": getattr(current_user, 'first_name', ''),
            "last_name": getattr(current_user, 'last_name', ''),
            "is_active": current_user.is_active,
            "created_at": current_user.created_at.isoformat() if hasattr(current_user, 'created_at') and current_user.created_at else None
        }
        
        if hasattr(current_user, 'plan'):
            user_data["plan"] = current_user.plan
        
        return {
            "status": "success",
            "user": user_data
        }
    except Exception as e:
        logger.error(f"Get profile error: {str(e)}", exc_info=True)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Internal server error"
        )

# Add token validation endpoint
@router.post("/validate-token")
async def validate_token(
    credentials: HTTPAuthorizationCredentials = Depends(security)
):
    """Validate JWT token"""
    try:
        token = credentials.credentials
        
        if token in token_blocklist:
            return {"valid": False, "reason": "Token revoked"}
        
        payload = decode_token(token)
        
        if payload.get("type") != "access":
            return {"valid": False, "reason": "Invalid token type"}
        
        return {
            "valid": True,
            "user_id": payload.get("sub"),
            "username": payload.get("username"),
            "email": payload.get("email"),
            "role": payload.get("role"),
            "plan": payload.get("plan"),
            "expires": payload.get("exp")
        }
    
    except HTTPException:
        return {"valid": False, "reason": "Invalid token"}
    except Exception as e:
        logger.error(f"Token validation error: {str(e)}")
        return {"valid": False, "reason": "Validation error"}