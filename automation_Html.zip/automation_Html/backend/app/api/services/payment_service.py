"""
Example service showing the power-user upgrade scenario with proper transaction handling
"""

from typing import Dict, Any
from sqlalchemy.orm import Session
from sqlalchemy.exc import IntegrityError

from app.db.deps import transactional, TransactionType
from app.models.user import User
from app.models.payment import Payment
from app.exceptions import PaymentFailedError, UserNotFoundError

class PaymentService:
    """Service handling user payments and upgrades with transaction safety"""
    
    @transactional(
        transaction_type=TransactionType.SERIALIZABLE,
        retry_on_deadlock=3,
        rollback_on=(PaymentFailedError, IntegrityError)
    )
    def upgrade_user_with_payment(
        self,
        db: Session,
        user_id: int,
        payment_details: Dict[str, Any]
    ) -> Dict[str, Any]:
        """
        Atomic operation: charge user AND upgrade their account
        Both succeed or both fail
        """
        start_time = time.time()
        
        try:
            # 1. Get user
            user = db.query(User).filter(User.id == user_id).with_for_update().first()
            if not user:
                raise UserNotFoundError(f"User {user_id} not found")
            
            # 2. Process payment (external API call)
            payment_result = self._process_payment(payment_details)
            
            if not payment_result["success"]:
                raise PaymentFailedError(f"Payment failed: {payment_result['error']}")
            
            # 3. Create payment record
            payment = Payment(
                user_id=user_id,
                amount=payment_result["amount"],
                transaction_id=payment_result["transaction_id"],
                status="completed"
            )
            db.add(payment)
            db.flush()  # Flush to get payment ID
            
            # 4. Upgrade user
            user.premium = True
            user.upgraded_at = datetime.utcnow()
            user.last_payment_id = payment.id
            
            # 5. Send welcome email (outside transaction for reliability)
            # This happens after transaction commits
            self._send_upgrade_email(user.email)
            
            duration = time.time() - start_time
            logger.info(f"User {user_id} upgraded successfully in {duration:.3f}s")
            
            return {
                "success": True,
                "user_id": user_id,
                "payment_id": payment.id,
                "transaction_id": payment_result["transaction_id"]
            }
            
        except Exception as e:
            duration = time.time() - start_time
            logger.error(f"Upgrade failed for user {user_id} after {duration:.3f}s: {e}")
            
            # The @transactional decorator will automatically rollback
            # if the exception is in rollback_on list
            
            # Optionally, refund payment if it went through but upgrade failed
            if "payment_result" in locals() and payment_result.get("success"):
                self._refund_payment(payment_result["transaction_id"])
            
            raise
    
    def _process_payment(self, payment_details: Dict[str, Any]) -> Dict[str, Any]:
        """Mock payment processing"""
        # In reality, this would call Stripe/PayPal/etc.
        return {"success": True, "amount": 99.99, "transaction_id": "txn_123"}
    
    def _send_upgrade_email(self, email: str):
        """Send email notification (outside transaction)"""
        # This should be in a background task
        pass
    
    def _refund_payment(self, transaction_id: str):
        """Refund payment if upgrade failed"""
        logger.info(f"Refunding payment {transaction_id}")