from fastapi import APIRouter, Depends, Request
from sqlalchemy.orm import Session
from sqlalchemy.exc import SQLAlchemyError

from app.db.session import get_db
from app.billing.service import BillingService
from app.billing.idempotency import IdempotencyService

router = APIRouter()


@router.post("/stripe/webhook")
async def stripe_webhook(
    request: Request,
    db: Session = Depends(get_db),
):
    payload = await request.json()
    stripe_event_id = payload["id"]
    event_type = payload["type"]

    idempotency = IdempotencyService(db)

    if idempotency.already_processed(stripe_event_id):
        return {"status": "duplicate"}

    try:
        with db.begin():  # 🔒 ATOMIC TRANSACTION
            service = BillingService(db)
            service.handle_event(payload)

            idempotency.mark_processed(
                stripe_event_id=stripe_event_id,
                event_type=event_type,
                payload=payload,
            )

        return {"status": "processed"}

    except SQLAlchemyError:
        db.rollback()
        raise
