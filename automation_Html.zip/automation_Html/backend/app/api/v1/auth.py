from . import bp
from flask import jsonify, request
from flask_jwt_extended import create_access_token
from app.middleware.auth import exclude_from_auth

@bp.route('/login', methods=['POST'])
@exclude_from_auth  # Exclude from global auth middleware
def login():
    """Login endpoint (excluded from global auth)"""
    # Authentication logic
    username = request.json.get('username')
    password = request.json.get('password')
    
    # Validate credentials
    if username == 'admin' and password == 'password':
        access_token = create_access_token(
            identity=username,
            additional_claims={"role": "admin"}
        )
        return jsonify(access_token=access_token), 200
    
    return jsonify({"error": "Invalid credentials"}), 401