from flask import Blueprint
from app.middleware.rate_limit import rate_limit

bp = Blueprint('v1', __name__)

# Apply version-specific middleware
@bp.before_request
def v1_middleware():
    """V1 specific middleware"""
    # Add version-specific logic here
    pass

# Import routes
from . import auth, users, admin