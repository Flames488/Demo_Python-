# app/api/v1/webhooks.py
from flask import Blueprint, request, jsonify, current_app, g
import hmac
import hashlib
import json
import time
from datetime import datetime

# Remove the orphaned code that was at the top:
# db.add(WebhookEvent(...)) - This doesn't belong here!

bp = Blueprint('webhooks', __name__)

def verify_webhook_signature(payload: bytes, signature: str, secret: str) -> bool:
    """Verify webhook signature."""
    expected_signature = hmac.new(
        secret.encode(), 
        payload, 
        hashlib.sha256
    ).hexdigest()
    return hmac.compare_digest(signature, expected_signature)

@bp.route('/stripe', methods=['POST'])
def stripe_webhook():
    """Handle Stripe webhooks with idempotency protection."""
    try:
        # Get the signature from headers
        signature = request.headers.get('Stripe-Signature')
        if not signature:
            current_app.logger.warning("stripe_webhook_missing_signature")
            return jsonify({'error': 'Missing signature'}), 400
        
        # Get the webhook secret from config
        secret = current_app.config.get('STRIPE_WEBHOOK_SECRET')
        if not secret:
            current_app.logger.error("stripe_webhook_secret_not_configured")
            return jsonify({'error': 'Webhook not configured'}), 500
        
        # Verify signature
        if not verify_webhook_signature(request.data, signature, secret):
            current_app.logger.warning("stripe_webhook_invalid_signature")
            return jsonify({'error': 'Invalid signature'}), 401
        
        # Parse the event
        event_data = request.get_json()
        event_type = event_data.get('type')
        event_id = event_data.get('id')
        
        if not event_id:
            current_app.logger.warning("stripe_webhook_missing_event_id")
            return jsonify({'error': 'Missing event ID'}), 400
        
        current_app.logger.info(
            "stripe_webhook_received",
            extra={
                "event_type": event_type,
                "event_id": event_id,
                "webhook_id": event_data.get('id'),
                "request_id": getattr(g, 'request_id', None)
            }
        )
        
        # Get database session
        # Note: This assumes you're using Flask-SQLAlchemy with standard setup
        from flask_sqlalchemy import SQLAlchemy
        db = current_app.extensions['sqlalchemy'].db.session
        
        # Import WebhookEvent model - FIXED import path
        from app.db.models.webhook_event import WebhookEvent
        
        # ✅ IDEMPOTENCY CHECK: Check if we've already processed this event
        existing = db.query(WebhookEvent).filter(
            WebhookEvent.stripe_event_id == event_id
        ).first()
        
        if existing:
            current_app.logger.info(
                "stripe_webhook_duplicate_event",
                extra={
                    "event_id": event_id,
                    "event_type": event_type,
                    "already_processed_at": existing.processed_at.isoformat() if existing.processed_at else None,
                    "request_id": getattr(g, 'request_id', None)
                }
            )
            return jsonify({'status': 'already_processed'}), 200
        
        # ✅ Create webhook event record BEFORE processing
        webhook_event = WebhookEvent(
            stripe_event_id=event_id,
            event_type=event_type,
            payload=json.dumps(event_data),
            received_at=datetime.utcnow(),  # Use datetime instead of time.time()
            status='received'
        )
        db.add(webhook_event)
        db.flush()  # Save immediately to prevent race conditions
        
        # Handle different event types
        try:
            if event_type == 'checkout.session.completed':
                # Handle successful checkout
                session = event_data.get('data', {}).get('object', {})
                customer_id = session.get('customer')
                subscription_id = session.get('subscription')
                session_id = session.get('id')
                
                current_app.logger.info(
                    "stripe_checkout_completed",
                    extra={
                        "customer_id": customer_id,
                        "subscription_id": subscription_id,
                        "session_id": session_id,
                        "webhook_event_id": webhook_event.id,
                        "request_id": getattr(g, 'request_id', None)
                    }
                )
                
                # Update webhook event with processing details
                webhook_event.status = 'processing'
                webhook_event.customer_id = customer_id
                webhook_event.subscription_id = subscription_id
                webhook_event.session_id = session_id
                db.flush()
                
                # Process the checkout completion
                # Your business logic here
                # Example:
                # from app.services.stripe_service import handle_checkout_completed
                # handle_checkout_completed(customer_id, subscription_id, session_id)
                
                webhook_event.status = 'processed'
                webhook_event.processed_at = datetime.utcnow()  # Fixed: use datetime
                db.commit()
                
                return jsonify({'status': 'processed'}), 200
                
            elif event_type == 'customer.subscription.updated':
                # Handle subscription updates
                subscription = event_data.get('data', {}).get('object', {})
                customer_id = subscription.get('customer')
                subscription_id = subscription.get('id')
                status = subscription.get('status')
                
                current_app.logger.info(
                    "stripe_subscription_updated",
                    extra={
                        "customer_id": customer_id,
                        "subscription_id": subscription_id,
                        "status": status,
                        "webhook_event_id": webhook_event.id,
                        "request_id": getattr(g, 'request_id', None)
                    }
                )
                
                webhook_event.status = 'processing'
                webhook_event.customer_id = customer_id
                webhook_event.subscription_id = subscription_id
                db.flush()
                
                # Process subscription update
                # Your business logic here
                
                webhook_event.status = 'processed'
                webhook_event.processed_at = datetime.utcnow()  # Fixed: use datetime
                db.commit()
                
                return jsonify({'status': 'processed'}), 200
                
            elif event_type == 'customer.subscription.deleted':
                # Handle subscription cancellation
                subscription = event_data.get('data', {}).get('object', {})
                customer_id = subscription.get('customer')
                subscription_id = subscription.get('id')
                
                current_app.logger.info(
                    "stripe_subscription_cancelled",
                    extra={
                        "customer_id": customer_id,
                        "subscription_id": subscription_id,
                        "webhook_event_id": webhook_event.id,
                        "request_id": getattr(g, 'request_id', None)
                    }
                )
                
                webhook_event.status = 'processing'
                webhook_event.customer_id = customer_id
                webhook_event.subscription_id = subscription_id
                db.flush()
                
                # Process subscription cancellation
                # Your business logic here
                
                webhook_event.status = 'processed'
                webhook_event.processed_at = datetime.utcnow()  # Fixed: use datetime
                db.commit()
                
                return jsonify({'status': 'processed'}), 200
                
            elif event_type == 'invoice.payment_failed':
                # Handle failed payments
                invoice = event_data.get('data', {}).get('object', {})
                customer_id = invoice.get('customer')
                invoice_id = invoice.get('id')
                
                current_app.logger.info(
                    "stripe_payment_failed",
                    extra={
                        "customer_id": customer_id,
                        "invoice_id": invoice_id,
                        "webhook_event_id": webhook_event.id,
                        "request_id": getattr(g, 'request_id', None)
                    }
                )
                
                webhook_event.status = 'processing'
                webhook_event.customer_id = customer_id
                webhook_event.invoice_id = invoice_id
                db.flush()
                
                # Handle failed payment
                # Your business logic here
                
                webhook_event.status = 'processed'
                webhook_event.processed_at = datetime.utcnow()  # Fixed: use datetime
                db.commit()
                
                return jsonify({'status': 'processed'}), 200
            
            else:
                # For other/unsupported event types
                current_app.logger.info(
                    "stripe_webhook_unhandled_event",
                    extra={
                        "event_type": event_type,
                        "event_id": event_id,
                        "webhook_event_id": webhook_event.id,
                        "request_id": getattr(g, 'request_id', None)
                    }
                )
                
                webhook_event.status = 'unhandled'
                webhook_event.processed_at = datetime.utcnow()  # Fixed: use datetime
                db.commit()
                
                # Still return 200 to acknowledge receipt
                return jsonify({'status': 'acknowledged'}), 200
                
        except Exception as processing_error:
            # Log processing error and update webhook event status
            current_app.logger.error(
                "stripe_webhook_processing_error",
                extra={
                    "event_id": event_id,
                    "event_type": event_type,
                    "webhook_event_id": webhook_event.id,
                    "error": str(processing_error),
                    "request_id": getattr(g, 'request_id', None)
                },
                exc_info=True
            )
            
            webhook_event.status = 'error'
            webhook_event.error_message = str(processing_error)
            webhook_event.processed_at = datetime.utcnow()  # Fixed: use datetime
            db.commit()
            
            # Still return 200 to prevent Stripe from retrying too aggressively
            # (Stripe will retry failed webhooks, but we want to control retry logic)
            return jsonify({'status': 'processing_error'}), 200
        
    except Exception as e:
        current_app.logger.error(
            "stripe_webhook_error",
            extra={
                "error": str(e),
                "exception_type": type(e).__name__,
                "request_id": getattr(g, 'request_id', None)
            },
            exc_info=True
        )
        return jsonify({'error': 'Internal server error'}), 500

@bp.route('/github', methods=['POST'])
def github_webhook():
    """Handle GitHub webhooks."""
    try:
        # Verify GitHub signature
        signature = request.headers.get('X-Hub-Signature-256')
        if not signature:
            current_app.logger.warning("github_webhook_missing_signature")
            return jsonify({'error': 'Missing signature'}), 400
        
        secret = current_app.config.get('GITHUB_WEBHOOK_SECRET')
        if not secret:
            current_app.logger.error("github_webhook_secret_not_configured")
            return jsonify({'error': 'Webhook not configured'}), 500
        
        # GitHub signature includes 'sha256='
        if not signature.startswith('sha256='):
            current_app.logger.warning("github_webhook_invalid_signature_format")
            return jsonify({'error': 'Invalid signature format'}), 401
        
        signature = signature[7:]  # Remove 'sha256='
        
        expected_signature = hmac.new(
            secret.encode(),
            request.data,
            hashlib.sha256
        ).hexdigest()
        
        if not hmac.compare_digest(signature, expected_signature):
            current_app.logger.warning("github_webhook_invalid_signature")
            return jsonify({'error': 'Invalid signature'}), 401
        
        # Parse GitHub event
        event_type = request.headers.get('X-GitHub-Event')
        payload = request.get_json()
        delivery_id = request.headers.get('X-GitHub-Delivery')
        
        if delivery_id:
            # Get database session
            from flask_sqlalchemy import SQLAlchemy
            db = current_app.extensions['sqlalchemy'].db.session
            
            # Check for duplicate GitHub webhook events
            # Note: Make sure your WebhookEvent model has a github_delivery_id field
            from app.db.models.webhook_event import WebhookEvent
            
            existing = db.query(WebhookEvent).filter(
                WebhookEvent.github_delivery_id == delivery_id
            ).first()
            
            if existing:
                current_app.logger.info(
                    "github_webhook_duplicate_event",
                    extra={
                        "delivery_id": delivery_id,
                        "event_type": event_type,
                        "request_id": getattr(g, 'request_id', None)
                    }
                )
                return jsonify({'status': 'already_processed'}), 200
        
        current_app.logger.info(
            "github_webhook_received",
            extra={
                "event_type": event_type,
                "delivery_id": delivery_id,
                "repository": payload.get('repository', {}).get('full_name'),
                "request_id": getattr(g, 'request_id', None)
            }
        )
        
        # Handle different GitHub events
        if event_type == 'push':
            # Handle push events
            ref = payload.get('ref', '')
            commits = payload.get('commits', [])
            
            current_app.logger.info(
                "github_push_received",
                extra={
                    "branch": ref,
                    "commit_count": len(commits),
                    "request_id": getattr(g, 'request_id', None)
                }
            )
            
            # Process push event
            # Your business logic here
            
        elif event_type == 'pull_request':
            # Handle pull request events
            action = payload.get('action')
            pr_number = payload.get('number')
            
            current_app.logger.info(
                "github_pull_request_received",
                extra={
                    "action": action,
                    "pr_number": pr_number,
                    "request_id": getattr(g, 'request_id', None)
                }
            )
            
            # Process pull request event
            # Your business logic here
        
        return jsonify({'status': 'processed'}), 200
        
    except Exception as e:
        current_app.logger.error(
            "github_webhook_error",
            extra={
                "error": str(e),
                "exception_type": type(e).__name__,
                "request_id": getattr(g, 'request_id', None)
            },
            exc_info=True
        )
        return jsonify({'error': 'Internal server error'}), 500

@bp.route('/custom', methods=['POST'])
def custom_webhook():
    """Handle custom webhooks."""
    try:
        data = request.get_json()
        
        current_app.logger.info(
            "custom_webhook_received",
            extra={
                "data": data,
                "request_id": getattr(g, 'request_id', None)
            }
        )
        
        # Add your custom webhook logic here
        # Verify custom signatures, process data, etc.
        
        return jsonify({'status': 'received'}), 200
        
    except Exception as e:
        current_app.logger.error(
            "custom_webhook_error",
            extra={
                "error": str(e),
                "exception_type": type(e).__name__,
                "request_id": getattr(g, 'request_id', None)
            },
            exc_info=True
        )
        return jsonify({'error': 'Invalid request'}), 400

# Remove the orphaned try/except block at the bottom:
# try:
#     db.add(WebhookEvent(stripe_event_id=event.id))
#     db.commit()
#     except IntegrityError:
#     db.rollback()
#     return  # another worker already handled it