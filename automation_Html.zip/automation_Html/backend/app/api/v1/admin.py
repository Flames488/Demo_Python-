from . import bp
from flask import jsonify
from flask_jwt_extended import get_jwt
from app.middleware.permissions import role_required, permission_required
from app.middleware.subscription_guard import subscription_required
from app.middleware.rate_limit import rate_limit

@bp.route('/admin/delete-user/<user_id>', methods=['DELETE'])
@rate_limit(limit=10, window=60)  # 10 requests per minute
@subscription_required(tier='pro')  # Requires pro subscription
@permission_required('admin:write')  # Requires specific permission
@role_required('admin')  # Requires admin role
def delete_user(user_id):
    """Delete user endpoint with multiple middleware layers"""
    # Logic only executes if all middleware passes
    
    return jsonify({
        "message": f"User {user_id} deleted",
        "deleted_by": get_jwt().get('sub')
    }), 200