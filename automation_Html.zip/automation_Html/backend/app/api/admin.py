from flask import Blueprint, render_template
from app.utils.permissions import require_role

bp = Blueprint("admin", __name__, url_prefix="/admin")

@bp.route("/dashboard")
@require_role("admin")
def dashboard():
    return render_template("admin/dashboard.html")

@bp.route("/users")
@require_role("admin")
def user_management():
    return render_template("admin/users.html")