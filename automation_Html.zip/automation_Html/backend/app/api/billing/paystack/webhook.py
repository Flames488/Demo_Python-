from fastapi import APIRouter, Request, HTTPException

from app.api.billing.paystack.security import verify_paystack
from app.services.billing.subscription_activation import activate_subscription

router = APIRouter()


@router.post("/paystack/webhook")
async def paystack_webhook(request: Request):
    payload = await request.body()
    signature = request.headers.get("x-paystack-signature")

    if not signature or not verify_paystack(signature, payload):
        raise HTTPException(status_code=400, detail="Invalid Paystack signature")

    event = await request.json()

    if event["event"] == "charge.success":
        data = event["data"]
        metadata = data["metadata"]

        activate_subscription(
            user_id=int(metadata["user_id"]),
            plan_id=metadata["plan_id"],
            provider="paystack",
            provider_event_id=str(data["id"]),
            period_end=None,
        )

    return {"status": "success"}
