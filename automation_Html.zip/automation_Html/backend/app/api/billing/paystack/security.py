# security.py - Enhanced version with additional safeguards
import hmac
import hashlib
from app.config import settings
from typing import Optional


def verify_paystack(signature: str, payload: bytes) -> bool:
    """
    Verify Paystack webhook signature with additional safety checks.
    
    Args:
        signature: The x-paystack-signature header value
        payload: Raw request body as bytes
    
    Returns:
        bool: True if signature is valid
    """
    # 1. Validate inputs
    if not signature or not payload:
        return False
    
    # 2. Check secret is configured
    if not settings.PAYSTACK_SECRET:
        raise ValueError("PAYSTACK_SECRET is not configured")
    
    # 3. Compute HMAC
    computed = hmac.new(
        settings.PAYSTACK_SECRET.encode("utf-8"),
        payload,
        hashlib.sha512
    ).hexdigest()
    
    # 4. Constant-time comparison
    return hmac.compare_digest(signature, computed)


# webhook.py - Enhanced version with logging and idempotency
import logging
from datetime import datetime
from fastapi import Request, HTTPException, BackgroundTasks

logger = logging.getLogger(__name__)

@router.post("/paystack/webhook")
async def paystack_webhook(request: Request, background_tasks: BackgroundTasks):
    """Handle Paystack webhooks with security and reliability."""
    
    # 1. Get raw payload BEFORE parsing
    payload = await request.body()
    signature = request.headers.get("x-paystack-signature")
    
    # 2. Log incoming webhook (for debugging)
    logger.info(f"Paystack webhook received: {datetime.utcnow().isoformat()}")
    
    # 3. Verify signature
    if not signature:
        logger.warning("Missing Paystack signature header")
        raise HTTPException(status_code=400, detail="Missing signature")
    
    if not verify_paystack(signature, payload):
        logger.warning("Invalid Paystack signature")
        raise HTTPException(status_code=400, detail="Invalid signature")
    
    try:
        # 4. Parse JSON after verification
        event = await request.json()
        
        # 5. Verify required fields exist
        if "event" not in event or "data" not in event:
            logger.error("Invalid Paystack event structure")
            raise HTTPException(status_code=400, detail="Invalid event structure")
        
        # 6. Process in background to prevent timeout
        background_tasks.add_task(handle_paystack_event, event)
        
        logger.info(f"Processing Paystack event: {event.get('event')}")
        
        return {"status": "success", "message": "Webhook accepted"}
        
    except Exception as e:
        logger.error(f"Error processing webhook: {str(e)}")
        raise HTTPException(status_code=500, detail="Internal server error")