from flask import Blueprint
from app.utils.permissions import role_required

bp = Blueprint("billing", __name__, url_prefix="/billing")

# Add billing routes here with proper permissions
# Example:
# @bp.route("/invoice")
# @role_required("user", "admin")
# def view_invoice():
#     return "Invoice page"