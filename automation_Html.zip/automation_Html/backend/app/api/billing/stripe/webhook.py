from fastapi import APIRouter, Request, HTTPException
import stripe

from app.config import settings
from app.services.billing.subscription_activation import activate_subscription

router = APIRouter()

stripe.api_key = settings.STRIPE_SECRET_KEY


@router.post("/stripe/webhook")
async def stripe_webhook(request: Request):
    payload = await request.body()
    sig = request.headers.get("stripe-signature")

    try:
        event = stripe.Webhook.construct_event(
            payload,
            sig,
            settings.STRIPE_WEBHOOK_SECRET
        )
    except Exception:
        raise HTTPException(status_code=400, detail="Invalid Stripe signature")

    # ✅ Payment successful
    if event["type"] == "checkout.session.completed":
        session_data = event["data"]["object"]

        activate_subscription(
            user_id=int(session_data["metadata"]["user_id"]),
            plan_id=session_data["metadata"]["plan_id"],
            provider="stripe",
            provider_event_id=event["id"],
            period_end=None,
        )

    return {"status": "success"}
