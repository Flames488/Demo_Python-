import stripe
from fastapi import Request, HTTPException
from app.config import settings
from app.db import session

stripe.api_key = settings.STRIPE_SECRET_KEY

@router.post("/webhook")
async def stripe_webhook(request: Request):
    payload = await request.body()
    sig_header = request.headers.get("stripe-signature")

    try:
        event = stripe.Webhook.construct_event(
            payload,
            sig_header,
            settings.STRIPE_WEBHOOK_SECRET
        )
    except Exception:
        raise HTTPException(status_code=400)

    with session.begin():
        if WebhookEvent.exists(event.id):
            return {"status": "duplicate"}

        WebhookEvent.create(event.id, event.type)

        handle_event(event)

    return {"status": "success"}
