from contextlib import asynccontextmanager
from datetime import datetime, timedelta
from typing import Optional, Dict, Any, Callable, Union
from functools import wraps
from dataclasses import dataclass
import asyncio
import hashlib
import json

from fastapi import Request, HTTPException, status, Depends
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from redis.asyncio import Redis
from pydantic import BaseModel, validator
from prometheus_client import Counter, Histogram

from app.models.subscription import Subscription
from app.models.user import User
from app.core.config import settings
from app.core.exceptions import (
    SubscriptionRequiredError,
    RateLimitExceededError,
    SubscriptionFeatureUnavailableError
)
from app.core.cache import redis_client
from app.core.metrics import subscription_metrics


# ==================== MODELS & TYPES ====================

class SubscriptionTier(BaseModel):
    """Subscription tier configuration"""
    name: str
    level: int
    features: Dict[str, Any]
    rate_limits: Dict[str, int]
    metadata: Optional[Dict[str, Any]] = None


class SubscriptionContext(BaseModel):
    """Context object containing subscription info"""
    user_id: str
    subscription: Optional[Subscription]
    tier: Optional[SubscriptionTier]
    features: Dict[str, Any]
    remaining_limits: Dict[str, int]


class FeatureFlag:
    """Feature flag configuration"""
    def __init__(self, name: str, min_tier: int = 0, custom_check: Optional[Callable] = None):
        self.name = name
        self.min_tier = min_tier
        self.custom_check = custom_check


# ==================== METRICS ====================

class SubscriptionMetrics:
    """Metrics collection for subscription usage"""
    
    def __init__(self):
        self.request_counter = Counter(
            'subscription_requests_total',
            'Total subscription checks',
            ['endpoint', 'tier', 'result']
        )
        self.feature_usage = Counter(
            'subscription_feature_usage',
            'Feature usage by tier',
            ['feature', 'tier']
        )
        self.limit_exceeded = Counter(
            'subscription_limits_exceeded',
            'Rate limit exceeded events',
            ['limit_type', 'tier']
        )
        self.check_latency = Histogram(
            'subscription_check_duration_seconds',
            'Subscription check latency'
        )
    
    def record_check(self, endpoint: str, tier: Optional[str], success: bool):
        tier_name = tier or 'none'
        result = 'success' if success else 'blocked'
        self.request_counter.labels(endpoint, tier_name, result).inc()
    
    def record_feature_usage(self, feature: str, tier: Optional[str]):
        self.feature_usage.labels(feature, tier or 'none').inc()
    
    def record_limit_exceeded(self, limit_type: str, tier: Optional[str]):
        self.limit_exceeded.labels(limit_type, tier or 'none').inc()


# ==================== RATE LIMITER ====================

class DistributedRateLimiter:
    """Distributed rate limiter using Redis"""
    
    def __init__(self, redis: Redis, prefix: str = "rate_limit"):
        self.redis = redis
        self.prefix = prefix
    
    async def check_rate_limit(
        self,
        user_id: str,
        limit_name: str,
        max_requests: int,
        window_seconds: int
    ) -> bool:
        """Check if request is within rate limits"""
        key = f"{self.prefix}:{user_id}:{limit_name}"
        current_time = datetime.utcnow().timestamp()
        window_start = current_time - window_seconds
        
        # Remove old entries
        await self.redis.zremrangebyscore(key, 0, window_start)
        
        # Count requests in current window
        request_count = await self.redis.zcard(key)
        
        if request_count >= max_requests:
            return False
        
        # Add current request
        await self.redis.zadd(key, {str(current_time): current_time})
        await self.redis.expire(key, window_seconds)
        
        return True
    
    async def get_remaining_requests(
        self,
        user_id: str,
        limit_name: str,
        max_requests: int,
        window_seconds: int
    ) -> int:
        """Get remaining requests in current window"""
        key = f"{self.prefix}:{user_id}:{limit_name}"
        current_time = datetime.utcnow().timestamp()
        window_start = current_time - window_seconds
        
        await self.redis.zremrangebyscore(key, 0, window_start)
        request_count = await self.redis.zcard(key)
        
        return max(0, max_requests - request_count)


# ==================== SUBSCRIPTION MANAGER ====================

class SubscriptionManager:
    """Advanced subscription management with caching, tier system, and feature flags"""
    
    def __init__(
        self,
        redis_client: Redis,
        metrics: SubscriptionMetrics,
        tier_config: Dict[str, SubscriptionTier]
    ):
        self.redis = redis_client
        self.metrics = metrics
        self.tier_config = tier_config
        self.rate_limiter = DistributedRateLimiter(redis_client)
        self.cache_ttl = 300  # 5 minutes
    
    async def get_subscription_context(
        self,
        user_id: str,
        endpoint: str = None
    ) -> SubscriptionContext:
        """Get comprehensive subscription context for user"""
        cache_key = f"subscription:context:{user_id}"
        
        # Try cache first
        cached = await self.redis.get(cache_key)
        if cached:
            data = json.loads(cached)
            return SubscriptionContext(**data)
        
        # Get subscription from database
        subscription = await Subscription.get_active_for_user(user_id)
        tier = self._get_tier_for_subscription(subscription)
        features = tier.features if tier else {}
        
        # Check rate limits
        remaining_limits = {}
        if tier and tier.rate_limits:
            for limit_name, limit_value in tier.rate_limits.items():
                remaining = await self.rate_limiter.get_remaining_requests(
                    user_id, limit_name, limit_value, 3600
                )
                remaining_limits[limit_name] = remaining
        
        context = SubscriptionContext(
            user_id=user_id,
            subscription=subscription,
            tier=tier,
            features=features,
            remaining_limits=remaining_limits
        )
        
        # Cache the context
        await self.redis.setex(
            cache_key,
            self.cache_ttl,
            json.dumps(context.dict())
        )
        
        if endpoint:
            self.metrics.record_check(
                endpoint,
                tier.name if tier else None,
                bool(tier and subscription)
            )
        
        return context
    
    def _get_tier_for_subscription(self, subscription: Optional[Subscription]) -> Optional[SubscriptionTier]:
        """Map subscription to tier configuration"""
        if not subscription:
            return None
        
        # Customize based on your subscription model
        tier_name = subscription.tier or "free"
        return self.tier_config.get(tier_name)
    
    async def check_feature_access(
        self,
        user_id: str,
        feature: Union[str, FeatureFlag],
        endpoint: str = None
    ) -> bool:
        """Check if user has access to a specific feature"""
        if isinstance(feature, str):
            feature = FeatureFlag(name=feature)
        
        context = await self.get_subscription_context(user_id, endpoint)
        
        if not context.tier:
            return False
        
        # Check tier level
        if context.tier.level < feature.min_tier:
            return False
        
        # Check custom validator if provided
        if feature.custom_check and not feature.custom_check(context):
            return False
        
        # Check specific feature in tier
        if feature.name not in context.features:
            return False
        
        # Check rate limits for this feature
        if feature.name in context.tier.rate_limits:
            max_requests = context.tier.rate_limits[feature.name]
            has_limit = await self.rate_limiter.check_rate_limit(
                user_id, feature.name, max_requests, 3600
            )
            if not has_limit:
                self.metrics.record_limit_exceeded(feature.name, context.tier.name)
                return False
        
        self.metrics.record_feature_usage(feature.name, context.tier.name)
        return True
    
    async def invalidate_cache(self, user_id: str):
        """Invalidate cached subscription data"""
        cache_key = f"subscription:context:{user_id}"
        await self.redis.delete(cache_key)


# ==================== DEPENDENCY INJECTION ====================

# Initialize singleton instances
subscription_metrics = SubscriptionMetrics()

# Tier configuration (move to settings or database)
TIER_CONFIG = {
    "free": SubscriptionTier(
        name="free",
        level=0,
        features={
            "api_access": True,
            "basic_features": True,
            "rate_limited": True
        },
        rate_limits={
            "api_requests": 100,
            "feature_a": 10
        }
    ),
    "pro": SubscriptionTier(
        name="pro",
        level=1,
        features={
            "api_access": True,
            "basic_features": True,
            "advanced_features": True,
            "premium_support": True
        },
        rate_limits={
            "api_requests": 1000,
            "feature_a": 100,
            "feature_b": 50
        }
    ),
    "enterprise": SubscriptionTier(
        name="enterprise",
        level=2,
        features={
            "api_access": True,
            "basic_features": True,
            "advanced_features": True,
            "premium_support": True,
            "custom_integrations": True,
            "dedicated_instance": True
        },
        rate_limits={
            "api_requests": 10000,
            "feature_a": 1000,
            "feature_b": 500,
            "feature_c": 200
        }
    )
}

subscription_manager = SubscriptionManager(
    redis_client=redis_client,
    metrics=subscription_metrics,
    tier_config=TIER_CONFIG
)


# ==================== DECORATORS & DEPENDENCIES ====================

def require_subscription(
    min_tier: Optional[str] = None,
    feature: Optional[Union[str, FeatureFlag]] = None
):
    """Decorator for endpoints requiring subscription"""
    def decorator(func):
        @wraps(func)
        async def wrapper(*args, **kwargs):
            request = kwargs.get('request') or next(
                (arg for arg in args if isinstance(arg, Request)), None
            )
            
            if not request:
                raise HTTPException(500, detail="Request object not found")
            
            user = request.state.user
            if not user:
                raise HTTPException(401, detail="Unauthorized")
            
            context = await subscription_manager.get_subscription_context(
                user.id,
                endpoint=request.url.path
            )
            
            if not context.subscription or not context.subscription.is_active:
                raise SubscriptionRequiredError()
            
            if min_tier and context.tier and context.tier.level < TIER_CONFIG[min_tier].level:
                raise HTTPException(
                    status_code=403,
                    detail=f"Subscription tier '{min_tier}' or higher required"
                )
            
            if feature:
                has_access = await subscription_manager.check_feature_access(
                    user.id,
                    feature,
                    endpoint=request.url.path
                )
                if not has_access:
                    raise SubscriptionFeatureUnavailableError(feature)
            
            # Add context to request for use in route
            request.state.subscription_context = context
            
            return await func(*args, **kwargs)
        return wrapper
    return decorator


async def get_subscription_context(request: Request) -> SubscriptionContext:
    """Dependency to get subscription context"""
    user = getattr(request.state, 'user', None)
    if not user:
        raise HTTPException(401, detail="Unauthorized")
    
    return await subscription_manager.get_subscription_context(
        user.id,
        endpoint=request.url.path
    )


async def enforce_active_subscription(request: Request):
    """Original function upgraded with new system (backward compatibility)"""
    user = request.state.user
    
    if not user:
        raise HTTPException(status_code=401, detail="Unauthorized")
    
    context = await subscription_manager.get_subscription_context(
        user.id,
        endpoint=request.url.path
    )
    
    if not context.subscription or not context.subscription.is_active:
        raise SubscriptionRequiredError()
    
    # Store context for potential use in route
    request.state.subscription_context = context
    
    return context


@asynccontextmanager
async def subscription_required(
    user_id: str,
    feature: Optional[str] = None,
    endpoint: Optional[str] = None
):
    """Context manager for subscription checks in non-HTTP contexts"""
    try:
        context = await subscription_manager.get_subscription_context(
            user_id,
            endpoint=endpoint
        )
        
        if not context.subscription or not context.subscription.is_active:
            raise SubscriptionRequiredError()
        
        if feature:
            has_access = await subscription_manager.check_feature_access(
                user_id,
                feature,
                endpoint=endpoint
            )
            if not has_access:
                raise SubscriptionFeatureUnavailableError(feature)
        
        yield context
        
    finally:
        # Cleanup if needed
        pass


# ==================== FASTAPI DEPENDENCIES ====================

async def require_pro_subscription(request: Request):
    """Dependency for Pro tier endpoints"""
    return await require_subscription(min_tier="pro")(lambda: None)(request=request)


async def require_enterprise_subscription(request: Request):
    """Dependency for Enterprise tier endpoints"""
    return await require_subscription(min_tier="enterprise")(lambda: None)(request=request)


async def require_feature(feature_name: str):
    """Factory for feature-specific dependencies"""
    async def dependency(request: Request):
        user = request.state.user
        if not user:
            raise HTTPException(401, detail="Unauthorized")
        
        has_access = await subscription_manager.check_feature_access(
            user.id,
            feature_name,
            endpoint=request.url.path
        )
        
        if not has_access:
            raise SubscriptionFeatureUnavailableError(feature_name)
        
        return True
    
    return dependency


# ==================== WEBHOOK HANDLER ====================

class WebhookHandler:
    """Handle subscription webhooks (Stripe, PayPal, etc.)"""
    
    @staticmethod
    async def handle_subscription_updated(user_id: str, event_data: Dict[str, Any]):
        """Handle subscription update events"""
        # Invalidate cache
        await subscription_manager.invalidate_cache(user_id)
        
        # Log event
        subscription_metrics.request_counter.labels(
            endpoint='webhook',
            tier='updated',
            result='success'
        ).inc()
        
        # Trigger additional actions (email, notifications, etc.)
        # ...


# ==================== USAGE EXAMPLES ====================

"""
# In FastAPI routes:

from app.dependencies.subscription import (
    require_subscription,
    get_subscription_context,
    require_pro_subscription,
    require_feature,
    FeatureFlag
)

# Basic subscription check
@app.get("/premium-data")
@require_subscription()
async def get_premium_data(request: Request):
    context = request.state.subscription_context
    return {"data": "premium", "tier": context.tier.name}

# Tier-specific endpoint
@app.get("/pro-features")
@require_subscription(min_tier="pro")
async def get_pro_features(request: Request):
    return {"features": ["advanced_analytics", "priority_support"]}

# Feature-specific endpoint
@app.get("/custom-reports")
@require_subscription(feature="custom_reports")
async def get_custom_reports():
    return {"reports": [...]}

# Using dependency injection
@app.get("/usage-stats")
async def get_usage_stats(
    context: SubscriptionContext = Depends(get_subscription_context)
):
    return {
        "remaining_requests": context.remaining_limits,
        "features": context.features
    }

# Using dependency in path operation
@app.get("/enterprise-data", dependencies=[Depends(require_enterprise_subscription)])
async def get_enterprise_data():
    return {"data": "enterprise_only"}

# Feature flag with custom validation
advanced_ai = FeatureFlag(
    name="advanced_ai",
    min_tier=1,
    custom_check=lambda ctx: ctx.user_id not in BANNED_USERS
)

@app.get("/ai-analysis")
@require_subscription(feature=advanced_ai)
async def analyze_with_ai():
    return {"analysis": "..."}

# Non-HTTP context usage
async def process_batch(user_id: str):
    async with subscription_required(user_id, feature="batch_processing") as context:
        # Process with subscription context
        return await process_data(context)
"""

# ==================== MIDDLEWARE INTEGRATION ====================

class SubscriptionMiddleware:
    """Middleware for global subscription tracking"""
    
    async def __call__(self, request: Request, call_next):
        # Skip for public endpoints
        if request.url.path.startswith("/public/"):
            return await call_next(request)
        
        # Check if endpoint requires subscription
        # (Could be determined by route metadata)
        
        response = await call_next(request)
        
        # Add subscription headers if available
        if hasattr(request.state, 'subscription_context'):
            context = request.state.subscription_context
            response.headers["X-Subscription-Tier"] = context.tier.name if context.tier else "none"
            response.headers["X-RateLimit-Remaining"] = str(
                context.remaining_limits.get("api_requests", "unlimited")
            )
        
        return response