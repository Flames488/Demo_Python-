from functools import wraps
from flask import abort
from flask_login import current_user

def gmail_access_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if not current_user.is_authenticated:
            abort(401)
        # Add additional Gmail-specific permission checks
        return f(*args, **kwargs)
    return decorated_function