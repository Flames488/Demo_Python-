from flask import Blueprint, redirect, session, url_for, request, jsonify
from app.config.settings import Config
from app.models.gmail_token import GmailToken
from app.utils.permissions import role_required
from app.services.gmail_service import GmailService
import requests

bp = Blueprint("gmail", __name__, url_prefix="/gmail")

@bp.route("/connect")
@role_required("user", "admin")  # Both users and admins can connect Gmail
def connect():
    """Initiate Gmail OAuth connection"""
    # Store state for security
    state = "random_state_string"  # In production, generate a secure random string
    session['oauth_state'] = state
    
    # Build OAuth URL with proper parameters
    auth_url = (
        "https://accounts.google.com/o/oauth2/v2/auth"
        "?response_type=code"
        "&client_id=YOUR_CLIENT_ID"  # Should come from config
        "&redirect_uri=http://localhost:5000/gmail/callback"  # Your callback URL
        "&scope=https://www.googleapis.com/auth/gmail.readonly"
        "&state=" + state
        "&access_type=offline"
        "&prompt=consent"
    )
    return redirect(auth_url)

@bp.route("/callback")
@role_required("user", "admin")
def callback():
    """Handle OAuth callback"""
    # Verify state parameter
    state = request.args.get('state')
    if state != session.get('oauth_state'):
        return "Invalid state parameter", 400
    
    code = request.args.get('code')
    if not code:
        return "No authorization code", 400
    
    # Exchange code for tokens
    # This would be implemented in gmail_service.py
    # ...
    
    return redirect(url_for('dashboard.index'))  # Redirect to dashboard

@bp.route("/sync")
@role_required("user", "admin")
def sync_emails():
    """Manually trigger email sync"""
    # Implementation
    return jsonify({"status": "sync initiated"}), 202