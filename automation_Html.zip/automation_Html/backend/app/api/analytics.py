# Update analytics.py
from flask import Blueprint, jsonify
from app.models.task import Task
from app.utils.permissions import require_role

bp = Blueprint("analytics", __name__, url_prefix="/admin/analytics")

@bp.route("/stats")
@require_role("admin")  # Only admins can access analytics
def stats():
    return jsonify({"tasks": Task.query.count()})