from .routes import bp

__all__ = ['bp']