from flask import Blueprint, jsonify
from app.models.task import Task
from app.models.user import User
from app.extensions import db
from app.utils.permissions import role_required

bp = Blueprint("admin", __name__, url_prefix="/admin")

# Admin-only route
@bp.route("/analytics/stats")
@role_required("admin")  # Only admins can access
def stats():
    """Get task statistics - ADMIN ONLY"""
    return jsonify({
        "tasks": Task.query.count(),
        "status": "success"
    })

# Additional admin routes
@bp.route("/users")
@role_required("admin")
def list_users():
    """List all users - ADMIN ONLY"""
    users = User.query.all()
    return jsonify({
        "users": [
            {
                "id": user.id,
                "email": user.email,
                "role": user.role,
                "created_at": user.created_at.isoformat() if hasattr(user, 'created_at') else None
            }
            for user in users
        ],
        "count": len(users)
    })

@bp.route("/tasks")
@role_required("admin")
def list_all_tasks():
    """List all tasks in the system - ADMIN ONLY"""
    tasks = Task.query.all()
    return jsonify({
        "tasks": [
            {
                "id": task.id,
                "title": task.title,
                "source": task.source,
                "summary": task.summary[:100] + "..." if task.summary and len(task.summary) > 100 else task.summary
            }
            for task in tasks
        ],
        "count": len(tasks)
    })

@bp.route("/users/<int:user_id>/promote", methods=["POST"])
@role_required("admin")
def promote_user(user_id):
    """Promote a user to admin - ADMIN ONLY"""
    user = User.query.get_or_404(user_id)
    
    if user.role == "admin":
        return jsonify({"message": "User is already an admin"}), 400
    
    user.role = "admin"
    db.session.commit()
    
    return jsonify({
        "message": f"User {user.email} promoted to admin",
        "user": {
            "id": user.id,
            "email": user.email,
            "role": user.role
        }
    })

# Remove the old permission decorators since we're using role_required now
# The function can_view_analytics might still be useful elsewhere
def can_view_analytics(user):
    """Check if user can view analytics"""
    return user.role in ["admin", "analyst"]