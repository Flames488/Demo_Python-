from app.utils.permissions import require_role

# Specific admin permission decorators
admin_required = require_role("admin")
super_admin_required = require_role("super_admin")  # If you have super admin role

def can_view_analytics(user):
    """Check if user can view analytics"""
    return user.role in ["admin", "analyst"]  # Example: multiple roles can view