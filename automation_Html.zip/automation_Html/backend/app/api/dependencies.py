"""
Example dependencies for FastAPI endpoints
"""

from typing import Generator
from fastapi import Depends, HTTPException, status
from sqlalchemy.orm import Session

from app.db.deps import get_db, transactional, TransactionType
from app.db.deps import db_dependency as db_dep


from app.api.middleware.subscription import enforce_active_subscription

def paid_user():
    return Depends(enforce_active_subscription)


# Simple dependency
def get_database() -> Generator[Session, None, None]:
    """Dependency for database sessions"""
    with get_db() as db:
        yield db

# Advanced dependency with transaction type
def get_write_db() -> Generator[Session, None, None]:
    """Dependency for write operations with READ COMMITTED isolation"""
    with get_db(transaction_type=TransactionType.READ_WRITE) as db:
        yield db

def get_serializable_db() -> Generator[Session, None, None]:
    """Dependency for critical operations with SERIALIZABLE isolation"""
    with get_db(transaction_type=TransactionType.SERIALIZABLE) as db:
        yield db

# Usage in FastAPI
def get_current_user(
    db: Session = Depends(get_write_db),
    token: str = Depends(oauth2_scheme)
):
    """Get current user with write database session"""
    # Implementation...
    pass