"""
Central permissions module - Single source of truth for authentication and authorization.

This module provides decorators and utilities for controlling access to routes
based on authentication status and user roles.

IMPORTANT:
- All route protection MUST use decorators from this file
- Never check roles or authentication manually in route functions
- Always use the appropriate decorator for access control
"""

from functools import wraps
from flask import abort, jsonify, request
from flask_login import current_user
import functools


# ============================================================================
# CORE PERMISSION DECORATORS
# ============================================================================

def login_required(fn=None, *, json_response=True):
    """
    Decorator to require authentication.
    
    Args:
        fn: The function to decorate (can be used with or without parentheses)
        json_response: Whether to return JSON response for API routes
    
    Usage:
        @login_required
        def my_route():
            pass
            
        @login_required(json_response=False)
        def my_web_route():
            pass
    """
    def decorator(fn):
        @wraps(fn)
        def wrapper(*args, **kwargs):
            if not current_user.is_authenticated:
                # Return JSON response for API routes if enabled
                if json_response and request.path.startswith('/api/'):
                    return jsonify({
                        "error": "Unauthorized",
                        "message": "Authentication required"
                    }), 401
                abort(401)
            return fn(*args, **kwargs)
        return wrapper
    
    # Handle both @login_required and @login_required()
    if fn is None:
        return decorator
    return decorator(fn)


def role_required(*roles, json_response=True):
    """
    Decorator to require specific role(s) for access.
    
    Args:
        *roles: One or more role names required for access
        json_response: Whether to return JSON response for API routes
    
    Usage:
        @role_required('admin')
        def admin_only():
            pass
            
        @role_required('editor', 'publisher')
        def content_management():
            pass
    """
    def decorator(fn):
        @wraps(fn)
        def wrapper(*args, **kwargs):
            # Check authentication first
            if not current_user.is_authenticated:
                if json_response and request.path.startswith('/api/'):
                    return jsonify({
                        "error": "Unauthorized",
                        "message": "Authentication required"
                    }), 401
                abort(401)
            
            # Check role authorization
            if current_user.role not in roles:
                if json_response and request.path.startswith('/api/'):
                    role_list = ", ".join(roles)
                    return jsonify({
                        "error": "Forbidden",
                        "message": f"Requires one of these roles: {role_list}"
                    }), 403
                abort(403)
            
            return fn(*args, **kwargs)
        return wrapper
    return decorator


# ============================================================================
# COMMON ROLE SHORTCUTS
# ============================================================================

def admin_required(fn=None, *, json_response=True):
    """
    Decorator specifically for admin-only access.
    
    Usage:
        @admin_required
        def admin_dashboard():
            pass
    """
    def decorator(fn):
        @wraps(fn)
        @functools.lru_cache(maxsize=1)
        def wrapper(*args, **kwargs):
            return role_required('admin', json_response=json_response)(fn)(*args, **kwargs)
        return wrapper
    
    if fn is None:
        return decorator
    return decorator(fn)


def staff_required(fn=None, *, json_response=True):
    """
    Decorator for staff roles (admin, manager, supervisor).
    
    Usage:
        @staff_required
        def staff_area():
            pass
    """
    def decorator(fn):
        @wraps(fn)
        def wrapper(*args, **kwargs):
            return role_required('admin', 'manager', 'supervisor', 
                               json_response=json_response)(fn)(*args, **kwargs)
        return wrapper
    
    if fn is None:
        return decorator
    return decorator(fn)


# ============================================================================
# PERMISSION CHECK FUNCTIONS (for use in templates or conditional logic)
# ============================================================================

def has_role(role_name):
    """
    Check if current user has a specific role.
    
    Args:
        role_name (str): Role to check for
    
    Returns:
        bool: True if user has the role, False otherwise
    
    Usage:
        if has_role('admin'):
            # show admin controls
    """
    if not current_user.is_authenticated:
        return False
    return current_user.role == role_name


def has_any_role(*roles):
    """
    Check if current user has any of the specified roles.
    
    Args:
        *roles: One or more role names
    
    Returns:
        bool: True if user has any of the roles, False otherwise
    
    Usage:
        if has_any_role('admin', 'editor'):
            # show editing controls
    """
    if not current_user.is_authenticated:
        return False
    return current_user.role in roles


def is_admin():
    """Check if current user is an admin."""
    return has_role('admin')


def is_staff():
    """Check if current user is staff (admin, manager, supervisor)."""
    return has_any_role('admin', 'manager', 'supervisor')


# ============================================================================
# PERMISSION CLASSES (for more complex permission logic)
# ============================================================================

class Permission:
    """Base permission class for custom permission logic."""
    
    @staticmethod
    def check():
        """Check if permission is granted. Must be overridden by subclasses."""
        raise NotImplementedError("Subclasses must implement check()")
    
    def __call__(self, fn):
        """Allow using Permission classes as decorators."""
        @wraps(fn)
        def wrapper(*args, **kwargs):
            if not self.check():
                abort(403)
            return fn(*args, **kwargs)
        return wrapper


class OwnerPermission(Permission):
    """
    Permission that grants access only to the owner of a resource.
    
    Usage:
        @OwnerPermission(get_owner_id_func)
        def edit_resource(resource_id):
            pass
    """
    
    def __init__(self, get_owner_func):
        """
        Args:
            get_owner_func: Function that returns the owner ID of a resource
        """
        self.get_owner_func = get_owner_func
    
    def check(self, resource_id):
        """Check if current user owns the resource."""
        if not current_user.is_authenticated:
            return False
        return current_user.id == self.get_owner_func(resource_id)


class RoleOrOwnerPermission(Permission):
    """
    Permission that grants access to specific roles OR the owner.
    
    Usage:
        @RoleOrOwnerPermission(['admin', 'manager'], get_owner_id_func)
        def edit_resource(resource_id):
            pass
    """
    
    def __init__(self, allowed_roles, get_owner_func):
        """
        Args:
            allowed_roles: List of roles that have access
            get_owner_func: Function that returns the owner ID of a resource
        """
        self.allowed_roles = allowed_roles
        self.get_owner_func = get_owner_func
    
    def check(self, resource_id):
        """Check if user has allowed role OR owns the resource."""
        if not current_user.is_authenticated:
            return False
        
        # Check role permission
        if current_user.role in self.allowed_roles:
            return True
        
        # Check ownership
        return current_user.id == self.get_owner_func(resource_id)


# ============================================================================
# EXPORT ALL DECORATORS AND FUNCTIONS
# ============================================================================

__all__ = [
    # Core decorators
    'login_required',
    'role_required',
    
    # Shortcut decorators
    'admin_required',
    'staff_required',
    
    # Permission check functions
    'has_role',
    'has_any_role',
    'is_admin',
    'is_staff',
    
    # Permission classes
    'Permission',
    'OwnerPermission',
    'RoleOrOwnerPermission',
]


# ============================================================================
# USAGE EXAMPLES (not executed, just for documentation)
# ============================================================================
"""
EXAMPLE USAGE:

# Basic authentication
@app.route('/profile')
@login_required
def profile():
    return render_template('profile.html')

# Admin-only route
@app.route('/admin/dashboard')
@admin_required
def admin_dashboard():
    return render_template('admin/dashboard.html')

# Multiple roles allowed
@app.route('/content/edit')
@role_required('editor', 'publisher', 'admin')
def edit_content():
    return render_template('content/edit.html')

# Web route (non-API) with different error handling
@app.route('/web/admin')
@admin_required(json_response=False)
def web_admin():
    return render_template('admin/web.html')

# In templates
{% if is_admin() %}
    <a href="/admin">Admin Panel</a>
{% endif %}

{% if has_any_role('editor', 'publisher') %}
    <button>Edit Content</button>
{% endif %}

# Complex permission with ownership
def get_post_owner(post_id):
    post = Post.query.get_or_404(post_id)
    return post.author_id

@app.route('/post/<int:post_id>/edit')
@login_required
@RoleOrOwnerPermission(['admin', 'editor'], get_post_owner)
def edit_post(post_id):
    # Only reaches here if user is admin, editor, OR post owner
    return render_template('post/edit.html', post_id=post_id)
"""