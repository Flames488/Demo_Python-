# backend/app/utils/rate_limit.py
from functools import wraps
from flask import request, jsonify
from app.extensions import limiter

def rate_limit_by_key(limit_value, key_func=None):
    """
    Decorator to apply rate limiting with custom key function.
    
    Usage:
        @rate_limit_by_key("10 per minute", key_func=lambda: request.json.get('email'))
    """
    def decorator(f):
        @wraps(f)
        def decorated_function(*args, **kwargs):
            if key_func:
                key = key_func()
                if key:
                    # Apply rate limit per key (e.g., per email for login)
                    limiter.limit(limit_value, key_func=lambda: f"endpoint:{request.endpoint}:key:{key}")(f)
                else:
                    # Apply default rate limit
                    limiter.limit(limit_value)(f)
            else:
                limiter.limit(limit_value)(f)
            return f(*args, **kwargs)
        return decorated_function
    return decorator

# For email-specific rate limiting on auth endpoints
def email_rate_limit(limit_value):
    """Rate limit based on email from request body."""
    return rate_limit_by_key(
        limit_value,
        key_func=lambda: request.json.get('email') if request.is_json else None
    )