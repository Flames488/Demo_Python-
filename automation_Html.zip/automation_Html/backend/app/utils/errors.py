from flask import jsonify, request
from werkzeug.exceptions import HTTPException
import traceback
import logging

logger = logging.getLogger(__name__)

# Base application error class
class AppError(Exception):
    """Base application error"""
    status_code = 500
    message = "Application error"
    
    def __init__(self, message=None, **kwargs):
        super().__init__()
        if message is not None:
            self.message = message
        self.kwargs = kwargs

class ValidationError(AppError):
    """Custom validation error"""
    status_code = 400
    message = "Validation error"
    
    def __init__(self, message=None, field=None, **kwargs):
        super().__init__(message)
        self.field = field
        if field:
            self.kwargs['field'] = field

class AuthError(AppError):
    """Authentication error"""
    status_code = 401
    message = "Authentication failed"

class PermissionError(AppError):
    """Permission/Authorization error"""
    status_code = 403
    message = "Forbidden"

class NotFoundError(AppError):
    """Resource not found error"""
    status_code = 404
    message = "Resource not found"

class MethodNotAllowedError(AppError):
    """HTTP method not allowed"""
    status_code = 405
    message = "Method not allowed"

class ExternalServiceError(AppError):
    """External service failure"""
    status_code = 502
    message = "External service failure"

class RateLimitError(AppError):
    """Rate limiting error"""
    status_code = 429
    message = "Too many requests"

# Backward compatibility aliases (optional - you can remove these if not needed)
class AuthenticationError(AuthError):
    """Legacy alias for AuthError"""
    pass

class AuthorizationError(PermissionError):
    """Legacy alias for PermissionError"""
    pass

class ServiceError(AppError):
    """Service layer error - legacy support"""
    status_code = 500
    message = "Service Error"

def register_error_handlers(app):
    """Register all error handlers for the application"""
    
    # Handle AppError and its subclasses
    @app.errorhandler(AppError)
    def handle_app_error(error):
        """Handle all AppError subclasses"""
        response = {
            "error": error.__class__.__name__,
            "message": error.message
        }
        
        # Add field for ValidationError
        if hasattr(error, 'field') and error.field:
            response["field"] = error.field
            
        # Add any additional kwargs
        if error.kwargs:
            response.update(error.kwargs)
        
        # Log service errors
        if error.status_code >= 500:
            logger.error(f"{error.__class__.__name__}: {error.message}")
            if app.config.get('DEBUG'):
                logger.error(traceback.format_exc())
        
        return jsonify(response), error.status_code
    
    # Keep legacy handlers for backward compatibility
    @app.errorhandler(AuthenticationError)
    def handle_auth_error(error):
        """Handle custom authentication errors"""
        return jsonify({
            "error": "Unauthorized",
            "message": error.message
        }), 401
    
    @app.errorhandler(AuthorizationError)
    def handle_authorization_error(error):
        """Handle custom authorization errors"""
        return jsonify({
            "error": "Forbidden",
            "message": error.message
        }), 403
    
    @app.errorhandler(ValidationError)
    def handle_validation_error(error):
        """Handle custom validation errors"""
        response = {
            "error": "Validation Error",
            "message": error.message
        }
        if error.field:
            response["field"] = error.field
        return jsonify(response), 400
    
    @app.errorhandler(ServiceError)
    def handle_service_error(error):
        """Handle service layer errors"""
        logger.error(f"Service error: {str(error)}")
        return jsonify({
            "error": "Service Error",
            "message": "An internal service error occurred."
        }), 500
    
    # Keep the HTTP status code handlers as fallbacks
    @app.errorhandler(401)
    def unauthorized(error):
        """Handle 401 Unauthorized errors"""
        return jsonify({
            "error": "Unauthorized",
            "message": "Authentication is required to access this resource."
        }), 401
    
    @app.errorhandler(403)
    def forbidden(error):
        """Handle 403 Forbidden errors"""
        return jsonify({
            "error": "Forbidden",
            "message": "You don't have permission to access this resource."
        }), 403
    
    @app.errorhandler(404)
    def not_found(error):
        """Handle 404 Not Found errors"""
        return jsonify({
            "error": "Not Found",
            "message": "The requested resource was not found."
        }), 404
    
    @app.errorhandler(405)
    def method_not_allowed(error):
        """Handle 405 Method Not Allowed errors"""
        return jsonify({
            "error": "Method Not Allowed",
            "message": f"The {request.method} method is not allowed for this endpoint."
        }), 405
    
    @app.errorhandler(Exception)
    def handle_unexpected_error(error):
        """Handle all unexpected errors"""
        # Check if it's already an AppError (should be caught by previous handler)
        if isinstance(error, AppError):
            return handle_app_error(error)
            
        # Log the full error with traceback
        logger.error(f"Unexpected error: {str(error)}")
        logger.error(traceback.format_exc())
        
        # Don't expose internal details in production
        if app.config.get('DEBUG'):
            message = str(error)
        else:
            message = "An unexpected error occurred. Please try again later."
        
        return jsonify({
            "error": "Internal Server Error",
            "message": message
        }), 500