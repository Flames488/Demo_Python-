from functools import wraps
from flask import jsonify, request
import time
import logging

logger = logging.getLogger(__name__)

def validate_json(schema=None):
    """Decorator to validate JSON request data.
    
    Args:
        schema (marshmallow.Schema, optional): Schema to validate against
    
    Returns:
        function: Decorated function with validated data
    """
    def decorator(fn):
        @wraps(fn)
        def wrapper(*args, **kwargs):
            if not request.is_json:
                return jsonify({
                    "error": "Bad Request",
                    "message": "Content-Type must be application/json"
                }), 400
            
            data = request.get_json()
            if data is None:
                return jsonify({
                    "error": "Bad Request",
                    "message": "Invalid JSON data"
                }), 400
            
            # If schema is provided, validate against it
            if schema:
                try:
                    validated_data = schema.load(data)
                    # Pass validated data as keyword argument
                    return fn(*args, validated_data=validated_data, **kwargs)
                except Exception as e:
                    return jsonify({
                        "error": "Validation Error",
                        "message": str(e)
                    }), 400
            
            return fn(*args, **kwargs)
        return wrapper
    return decorator

def rate_limit(max_requests, window_seconds):
    """Simple rate limiting decorator.
    
    Note: For production, use a proper rate limiting solution like Flask-Limiter
    
    Args:
        max_requests (int): Maximum requests allowed in the time window
        window_seconds (int): Time window in seconds
    """
    # In-memory store (not suitable for production with multiple workers)
    request_counts = {}
    
    def decorator(fn):
        @wraps(fn)
        def wrapper(*args, **kwargs):
            client_ip = request.remote_addr
            current_time = time.time()
            
            # Clean up old entries
            expired = [ip for ip, (count, timestamp) in request_counts.items() 
                      if current_time - timestamp > window_seconds]
            for ip in expired:
                del request_counts[ip]
            
            # Check rate limit
            if client_ip in request_counts:
                count, timestamp = request_counts[client_ip]
                if current_time - timestamp < window_seconds:
                    if count >= max_requests:
                        return jsonify({
                            "error": "Too Many Requests",
                            "message": f"Rate limit exceeded. Try again in {window_seconds} seconds."
                        }), 429
                    request_counts[client_ip] = (count + 1, timestamp)
                else:
                    request_counts[client_ip] = (1, current_time)
            else:
                request_counts[client_ip] = (1, current_time)
            
            return fn(*args, **kwargs)
        return wrapper
    return decorator

def log_execution_time(fn):
    """Decorator to log function execution time."""
    @wraps(fn)
    def wrapper(*args, **kwargs):
        start_time = time.time()
        result = fn(*args, **kwargs)
        execution_time = time.time() - start_time
        
        logger.debug(f"Function {fn.__name__} executed in {execution_time:.4f} seconds")
        
        # Log slow operations
        if execution_time > 1.0:  # More than 1 second
            logger.warning(f"Slow operation detected: {fn.__name__} took {execution_time:.4f}s")
        
        return result
    return wrapper