"""
Centralized logging configuration for the Flask application with structured JSON output.
"""
import json
import logging
import sys
import time
from datetime import datetime
from typing import Dict, Any

from flask import has_request_context, request, g
from flask_jwt_extended import get_current_user


class StructuredJsonFormatter(logging.Formatter):
    """
    Custom JSON formatter with request context, user information, and correlation IDs.
    """
    
    def format(self, record: logging.LogRecord) -> str:
        """Format log record as JSON with structured data."""
        log_data: Dict[str, Any] = {
            "timestamp": datetime.utcnow().isoformat() + "Z",
            "level": record.levelname,
            "logger": record.name,
            "message": record.getMessage(),
            "module": record.module,
            "function": record.funcName,
            "line": record.lineno,
        }
        
        # Add request context if available
        if has_request_context():
            log_data.update({
                "request_id": getattr(g, "request_id", None),
                "correlation_id": getattr(g, "correlation_id", None),
                "method": request.method,
                "path": request.path,
                "endpoint": request.endpoint,
                "remote_addr": request.remote_addr,
                "user_agent": request.user_agent.string if request.user_agent else None,
            })
            
            # Add user information from JWT if authenticated
            try:
                current_user = get_current_user()
                if current_user and hasattr(current_user, 'id'):
                    log_data["user_id"] = current_user.id
            except:
                # Not authenticated or user not loaded yet
                pass
            
            # Add user info from g if available (as fallback)
            if hasattr(g, 'user_info') and isinstance(g.user_info, dict) and 'user_id' in g.user_info:
                log_data["user_id"] = g.user_info['user_id']
        
        # Add exception information if present
        if record.exc_info:
            log_data["exception"] = self.formatException(record.exc_info)
        
        # Add duration if available
        if hasattr(g, 'start_time'):
            duration = round(time.time() - g.start_time, 4)
            log_data["duration_seconds"] = duration
        
        # Add any extra attributes from the record
        if hasattr(record, 'extra') and record.extra:
            log_data.update(record.extra)
        
        return json.dumps(log_data, ensure_ascii=False)


def setup_logging(app):
    """
    Configure application-wide logging with JSON output to stdout.
    
    Args:
        app: Flask application instance
        
    Returns:
        Configured application logger
    """
    # Remove all existing handlers from app logger
    for handler in app.logger.handlers[:]:
        app.logger.removeHandler(handler)
    
    # Remove handlers from root logger too
    root_logger = logging.getLogger()
    for handler in root_logger.handlers[:]:
        root_logger.removeHandler(handler)
    
    # Configure handler
    handler = logging.StreamHandler(sys.stdout)
    handler.setFormatter(StructuredJsonFormatter())
    
    # Set log level from config or environment
    log_level_name = app.config.get("LOG_LEVEL", "INFO").upper()
    log_level = getattr(logging, log_level_name, logging.INFO)
    
    # Apply to app logger
    app.logger.addHandler(handler)
    app.logger.setLevel(log_level)
    
    # Apply to root logger (captures all logs)
    root_logger.addHandler(handler)
    root_logger.setLevel(log_level)
    
    # Configure third-party loggers
    third_party_loggers = [
        "werkzeug",
        "sqlalchemy.engine",
        "flask_jwt_extended",
        "stripe",
    ]
    
    for logger_name in third_party_loggers:
        logger = logging.getLogger(logger_name)
        
        # Remove existing handlers
        for h in logger.handlers[:]:
            logger.removeHandler(h)
            
        logger.addHandler(handler)
        logger.setLevel(log_level)
        
        # Disable propagation for werkzeug in production to avoid duplicate logs
        if logger_name == "werkzeug" and not app.debug:
            logger.propagate = False
    
    # Disable propagation to avoid duplicate logs
    app.logger.propagate = False
    
    # Log initialization
    app.logger.info(
        "logging_initialized",
        extra={
            "log_level": log_level_name,
            "environment": app.config.get("ENV", "production"),
            "debug_mode": app.debug,
            "third_party_loggers": third_party_loggers
        }
    )
    
    return app.logger


def get_request_context_log_data() -> Dict[str, Any]:
    """
    Get current request context data for logging.
    
    Returns:
        Dictionary with request context data
    """
    if not has_request_context():
        return {}
    
    data = {
        "request_id": getattr(g, "request_id", None),
        "correlation_id": getattr(g, "correlation_id", None),
        "method": request.method,
        "path": request.path,
        "endpoint": request.endpoint,
        "remote_addr": request.remote_addr,
    }
    
    # Add user info from various sources
    try:
        current_user = get_current_user()
        if current_user and hasattr(current_user, 'id'):
            data["user_id"] = current_user.id
    except:
        pass
    
    if hasattr(g, 'user_info') and isinstance(g.user_info, dict) and 'user_id' in g.user_info:
        data["user_id"] = g.user_info['user_id']
    
    # Add duration if available
    if hasattr(g, 'start_time'):
        duration = round(time.time() - g.start_time, 4)
        data["duration_seconds"] = duration
    
    return data


def log_with_context(level: str, message: str, **extra):
    """
    Helper function to log with request context.
    
    Args:
        level: Log level (info, warning, error, etc.)
        message: Log message
        **extra: Additional structured data
    """
    logger = logging.getLogger(__name__)
    log_method = getattr(logger, level.lower(), logger.info)
    
    # Get request context data
    context_data = get_request_context_log_data()
    
    # Merge with extra data
    log_data = {**context_data, **extra}
    
    log_method(message, extra=log_data)


# Convenience functions for common log levels
def log_info(message: str, **extra):
    """Log info message with context."""
    log_with_context("info", message, **extra)


def log_warning(message: str, **extra):
    """Log warning message with context."""
    log_with_context("warning", message, **extra)


def log_error(message: str, **extra):
    """Log error message with context."""
    log_with_context("error", message, **extra)


def log_debug(message: str, **extra):
    """Log debug message with context."""
    log_with_context("debug", message, **extra)