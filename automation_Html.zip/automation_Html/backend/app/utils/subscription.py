from flask import abort
from functools import wraps

def require_active_subscription(fn):
    @wraps(fn)
    def wrapper(*args, **kwargs):
        from flask_login import current_user

        if current_user.subscription_status != "active":
            abort(403, "Upgrade required")

        return fn(*args, **kwargs)

    return wrapper
