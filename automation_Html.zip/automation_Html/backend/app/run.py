#!/usr/bin/env python3
"""
Application entry point
"""
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

def get_config_class():
    """Determine and return the appropriate configuration class based on environment."""
    env = os.environ.get('FLASK_ENV', 'development').lower()
    
    if env == 'production':
        from app.config.settings import ProdConfig as Config
        print(f"🚀 Starting in PRODUCTION mode")
        return Config
    elif env == 'testing':
        from app.config.settings import TestConfig as Config
        print(f"🧪 Starting in TESTING mode")
        return Config
    else:
        from config.settings import DevConfig as Config
        print(f"🔧 Starting in DEVELOPMENT mode")
        return Config

def main():
    """Main application entry point."""
    # Get the appropriate config class
    ConfigClass = get_config_class()
    
    # Create application with the selected config
    from app.main import create_app
    app = create_app(ConfigClass)
    
    # Run the application based on environment
    if os.environ.get('FLASK_ENV', 'development').lower() == 'development':
        if app.debug:
            # Now we can use app.logger since the app is created
            app.logger.warning(
                "debug_mode_enabled",
                extra={"environment": "development"}
            )
        
        app.run(
            host=os.environ.get('HOST', '0.0.0.0'),
            port=int(os.environ.get('PORT', 5000)),
            debug=True
        )
    else:
        # For non-development environments, print instructions
        print("ℹ️  Use a production WSGI server like gunicorn:")
        print("   gunicorn --workers 4 --bind 0.0.0.0:5000 'run:app'")
        sys.exit(0)

if __name__ == '__main__':
    main()