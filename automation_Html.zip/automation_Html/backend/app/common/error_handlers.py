from flask import Flask
from werkzeug.exceptions import HTTPException
from common.responses import error_response


def register_error_handlers(app: Flask):
    @app.errorhandler(HTTPException)
    def handle_http_exception(e: HTTPException):
        return error_response(
            message=e.description,
            code=e.name.replace(" ", "_").upper(),
            status=e.code,
        )

    @app.errorhandler(Exception)
    def handle_unexpected_exception(e: Exception):
        return error_response(
            message="Internal server error",
            code="INTERNAL_SERVER_ERROR",
            status=500,
        )

    return app