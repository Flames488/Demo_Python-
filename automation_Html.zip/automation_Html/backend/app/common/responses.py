from typing import Any, Optional, Dict


def success_response(data: Any = None, message: str = "success", code: str = "OK", status: int = 200):
    body = {
        "status": "success",
        "code": code,
        "message": message,
        "data": data,
    }
    return body, status


def error_response(message: str, code: str = "ERROR", status: int = 400, details: Optional[Dict] = None):
    body = {
        "status": "error",
        "code": code,
        "message": message,
        "details": details,
    }
    return body, status