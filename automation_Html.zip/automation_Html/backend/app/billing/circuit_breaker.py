# circuit_breaker.py
import time
from typing import Optional
from enum import Enum


class CircuitState(Enum):
    CLOSED = "closed"
    OPEN = "open"
    HALF_OPEN = "half_open"


class CircuitBreaker:
    """Circuit breaker pattern implementation"""
    
    def __init__(
        self,
        failure_threshold: int = 5,
        recovery_timeout: int = 60,
        expected_exceptions: tuple = ()
    ):
        self.failure_threshold = failure_threshold
        self.recovery_timeout = recovery_timeout
        self.expected_exceptions = expected_exceptions
        
        self.failures = 0
        self.state = CircuitState.CLOSED
        self.last_failure_time: Optional[float] = None
        self.next_check: Optional[float] = None
    
    def allow_request(self) -> bool:
        """Check if request should be allowed"""
        if self.state == CircuitState.CLOSED:
            return True
        
        if self.state == CircuitState.OPEN:
            if self.next_check and time.time() > self.next_check:
                self.state = CircuitState.HALF_OPEN
                return True
            return False
        
        return True
    
    def record_success(self):
        """Record successful request"""
        self.failures = 0
        self.state = CircuitState.CLOSED
        self.last_failure_time = None
        self.next_check = None
    
    def record_failure(self):
        """Record failed request"""
        self.failures += 1
        self.last_failure_time = time.time()
        
        if self.failures >= self.failure_threshold:
            self.state = CircuitState.OPEN
            self.next_check = time.time() + self.recovery_timeout
    
    def status(self) -> dict:
        """Get current circuit breaker status"""
        return {
            "state": self.state.value,
            "failures": self.failures,
            "threshold": self.failure_threshold,
            "last_failure": self.last_failure_time,
            "next_check": self.next_check
        }