from fastapi import Depends, HTTPException
from sqlalchemy.orm import Session

from app.billing.service import BillingService
from app.db.session import get_db

def enforce_usage(feature: str, amount: int = 1):
    def dependency(
        subscription_id: str,
        db: Session = Depends(get_db),
    ):
        service = BillingService(db)
        try:
            service.consume_usage(
                subscription_id=subscription_id,
                feature=feature,
                amount=amount,
            )
        except Exception as e:
            raise HTTPException(status_code=402, detail=str(e))
    return dependency
