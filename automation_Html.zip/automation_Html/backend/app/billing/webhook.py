import stripe
from fastapi import Request, HTTPException
from app.core.config import settings

stripe.api_key = settings.STRIPE_SECRET_KEY

async def verify_stripe_webhook(request: Request):
    """
    Verify Stripe webhook signature and return the event object.
    
    Args:
        request: FastAPI Request object containing the webhook payload
        
    Returns:
        stripe.Event: The verified Stripe event
        
    Raises:
        HTTPException: If signature is missing or invalid
    """
    payload = await request.body()
    sig_header = request.headers.get("stripe-signature")

    if not sig_header:
        raise HTTPException(status_code=400, detail="Missing signature")

    try:
        event = stripe.Webhook.construct_event(
            payload=payload,
            sig_header=sig_header,
            secret=settings.STRIPE_WEBHOOK_SECRET,
        )
        return event

    except stripe.error.SignatureVerificationError as e:
        raise HTTPException(status_code=400, detail=f"Invalid signature: {str(e)}")
    except ValueError as e:
        raise HTTPException(status_code=400, detail=f"Invalid payload: {str(e)}")
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Webhook verification failed: {str(e)}")