# Add these imports at the top
from datetime import datetime, timezone
from decimal import Decimal
from typing import Dict, Any, Optional, Tuple, List
from uuid import uuid4

from sqlalchemy.orm import Session
from sqlalchemy.exc import IntegrityError, SQLAlchemyError
from sqlalchemy import select

from app.models.user import User
from app.models.billing import Subscription, PaymentRecord, UsageRecord
from app.models.webhook_event import WebhookEvent
from app.core.config import settings
from app.billing.stripe_gateway import StripeGateway
from contextlib import contextmanager
import logging


logger = logging.getLogger("billing")


class BillingService:
    def __init__(self, db: Session):
        self.db = db
        self.stripe_gateway = StripeGateway(settings.STRIPE_SECRET_KEY)
    
    # DEFENSE 2 - Idempotency check
    def already_processed(self, event_id: str) -> bool:
        """Check if event has already been processed"""
        return self.db.query(WebhookEvent).filter(
            WebhookEvent.id == event_id
        ).first() is not None
    
    # DEFENSE 3 - Transactional processing wrapper
    @contextmanager
    def transaction_context(self):
        """Context manager for transactional processing"""
        try:
            yield
            self.db.commit()
        except Exception as e:
            self.db.rollback()
            logger.error(f"Transaction failed, rolled back: {str(e)}")
            raise
    
    def create_checkout_session(
        self,
        user: User,
        plan: str,
        success_url: str,
        cancel_url: str,
        promotion_code: Optional[str] = None,
        trial_days: Optional[int] = None
    ) -> Dict[str, Any]:
        """Business logic for creating checkout sessions"""
        # Your checkout logic from billing.py routes
        prices = {
            "pro": settings.STRIPE_PRICE_PRO,
            "business": settings.STRIPE_PRICE_BUSINESS,
            "enterprise": settings.STRIPE_PRICE_ENTERPRISE
        }
        
        price_id = prices.get(plan)
        if not price_id:
            raise ValueError(f"Invalid plan '{plan}'")
        
        checkout_params = {
            "customer_email": user.email,
            "success_url": success_url,
            "cancel_url": cancel_url,
            "payment_method_types": ["card"],
            "mode": "subscription",
            "line_items": [{
                "price": price_id,
                "quantity": 1
            }],
            "metadata": {
                "user_id": str(user.id),
                "plan": plan,
                "trial_days": trial_days or 0
            },
            "subscription_data": {
                "metadata": {
                    "user_id": str(user.id),
                    "plan": plan
                }
            }
        }
        
        if trial_days and trial_days > 0:
            checkout_params["subscription_data"]["trial_period_days"] = trial_days
        
        if promotion_code:
            checkout_params["discounts"] = [{"promotion_code": promotion_code}]
        
        try:
            # Use gateway instead of direct Stripe call
            session = self.stripe_gateway.create_checkout_session(**checkout_params)
            return session
        except Exception as e:
            raise Exception(f"Stripe error: {str(e)}")
    
    # Updated process_checkout_completed with idempotency and transaction
    def process_checkout_completed(
        self,
        event_id: str,
        session_data: Dict[str, Any]
    ) -> bool:
        """Business logic for processing completed checkouts with idempotency"""
        # DEFENSE 2 - Idempotency check
        if self.already_processed(event_id):
            logger.info(f"Event {event_id} already processed, skipping")
            return False
        
        user_id = session_data["metadata"].get("user_id")
        plan = session_data["metadata"].get("plan")
        
        if not user_id or not plan:
            raise ValueError("Missing user_id or plan in session metadata")
        
        # DEFENSE 3 - Use transaction context
        with self.transaction_context():
            # Create or update subscription in database
            subscription = self.db.query(Subscription).filter(
                Subscription.user_id == user_id
            ).with_for_update().first()  # Lock row for update
            
            if subscription:
                # Update existing subscription
                subscription.plan = plan
                subscription.status = "active"
                subscription.stripe_subscription_id = session_data.get("subscription")
                expires_at = session_data.get("expires_at")
                subscription.current_period_end = datetime.fromtimestamp(
                    expires_at, tz=timezone.utc
                ) if expires_at else None
                subscription.updated_at = datetime.now(timezone.utc)
            else:
                # Create new subscription
                expires_at = session_data.get("expires_at")
                subscription = Subscription(
                    user_id=user_id,
                    plan=plan,
                    status="active",
                    stripe_subscription_id=session_data.get("subscription"),
                    current_period_end=datetime.fromtimestamp(
                        expires_at, tz=timezone.utc
                    ) if expires_at else None,
                    started_at=datetime.now(timezone.utc)
                )
                self.db.add(subscription)
            
            # Record the webhook event for idempotency
            webhook_event = WebhookEvent(
                id=event_id,
                type="checkout.session.completed",
                payload=session_data
            )
            self.db.add(webhook_event)
            
            # Flush to ensure both operations succeed or fail together
            self.db.flush()
        
        logger.info(f"Successfully processed checkout event {event_id} for user {user_id}")
        return True
    
    # Updated handle_payment_succeeded with idempotency and transaction
    def handle_payment_succeeded(
        self,
        event_id: str,
        invoice_data: Dict[str, Any]
    ) -> bool:
        """Business logic for successful payments with idempotency"""
        if self.already_processed(event_id):
            logger.info(f"Payment event {event_id} already processed")
            return False
        
        subscription_id = invoice_data.get("subscription")
        
        with self.transaction_context():
            # Record payment
            payment_record = PaymentRecord(
                stripe_invoice_id=invoice_data["id"],
                subscription_id=subscription_id,
                amount_paid=invoice_data.get("amount_paid", 0),
                currency=invoice_data.get("currency", "usd"),
                status="succeeded",
                paid_at=datetime.fromtimestamp(invoice_data.get("created", 0), tz=timezone.utc)
            )
            self.db.add(payment_record)
            
            # Record webhook event
            webhook_event = WebhookEvent(
                id=event_id,
                type="invoice.payment_succeeded",
                payload=invoice_data
            )
            self.db.add(webhook_event)
            
            self.db.flush()
        
        logger.info(f"Successfully processed payment event {event_id}")
        return True
    
    # Updated handle_payment_failed with idempotency and transaction
    def handle_payment_failed(
        self,
        event_id: str,
        invoice_data: Dict[str, Any]
    ) -> bool:
        """Business logic for failed payments with idempotency"""
        if self.already_processed(event_id):
            logger.info(f"Payment failed event {event_id} already processed")
            return False
        
        subscription_id = invoice_data.get("subscription")
        
        with self.transaction_context():
            subscription = self.db.query(Subscription).filter(
                Subscription.stripe_subscription_id == subscription_id
            ).with_for_update().first()
            
            if subscription:
                subscription.status = "past_due"
                subscription.updated_at = datetime.now(timezone.utc)
            
            # Record payment failure
            payment_record = PaymentRecord(
                stripe_invoice_id=invoice_data["id"],
                subscription_id=subscription_id,
                amount_paid=0,
                currency=invoice_data.get("currency", "usd"),
                status="failed",
                paid_at=datetime.fromtimestamp(invoice_data.get("created", 0), tz=timezone.utc)
            )
            self.db.add(payment_record)
            
            # Record webhook event
            webhook_event = WebhookEvent(
                id=event_id,
                type="invoice.payment_failed",
                payload=invoice_data
            )
            self.db.add(webhook_event)
            
            self.db.flush()
        
        logger.info(f"Processed payment failed event {event_id}")
        return True
    
    # Updated handle_subscription_updated with idempotency and transaction
    def handle_subscription_updated(
        self,
        event_id: str,
        subscription_data: Dict[str, Any]
    ) -> bool:
        """Business logic for subscription updates with idempotency"""
        if self.already_processed(event_id):
            logger.info(f"Subscription update event {event_id} already processed")
            return False
        
        with self.transaction_context():
            subscription = self.db.query(Subscription).filter(
                Subscription.stripe_subscription_id == subscription_data["id"]
            ).with_for_update().first()
            
            if subscription:
                subscription.status = subscription_data.get("status", subscription.status)
                current_period_end = subscription_data.get("current_period_end")
                if current_period_end:
                    subscription.current_period_end = datetime.fromtimestamp(
                        current_period_end, tz=timezone.utc
                    )
                subscription.cancel_at_period_end = subscription_data.get(
                    "cancel_at_period_end", False
                )
                subscription.updated_at = datetime.now(timezone.utc)
            
            # Record webhook event
            webhook_event = WebhookEvent(
                id=event_id,
                type="customer.subscription.updated",
                payload=subscription_data
            )
            self.db.add(webhook_event)
            
            self.db.flush()
        
        logger.info(f"Processed subscription update event {event_id}")
        return True
    
    # Updated handle_subscription_deleted with idempotency and transaction
    def handle_subscription_deleted(
        self,
        event_id: str,
        subscription_data: Dict[str, Any]
    ) -> bool:
        """Business logic for subscription cancellation with idempotency"""
        if self.already_processed(event_id):
            logger.info(f"Subscription deleted event {event_id} already processed")
            return False
        
        with self.transaction_context():
            subscription = self.db.query(Subscription).filter(
                Subscription.stripe_subscription_id == subscription_data["id"]
            ).with_for_update().first()
            
            if subscription:
                subscription.status = "canceled"
                subscription.canceled_at = datetime.now(timezone.utc)
                subscription.updated_at = datetime.now(timezone.utc)
            
            # Record webhook event
            webhook_event = WebhookEvent(
                id=event_id,
                type="customer.subscription.deleted",
                payload=subscription_data
            )
            self.db.add(webhook_event)
            
            self.db.flush()
        
        logger.info(f"Processed subscription deletion event {event_id}")
        return True
    
    # Add helper for event processing
    def process_webhook_event(self, event_type: str, event_id: str, data: Dict[str, Any]) -> bool:
        """Route webhook events to appropriate handlers"""
        try:
            if event_type == "checkout.session.completed":
                return self.process_checkout_completed(event_id, data)
            elif event_type == "invoice.payment_succeeded":
                return self.handle_payment_succeeded(event_id, data)
            elif event_type == "invoice.payment_failed":
                return self.handle_payment_failed(event_id, data)
            elif event_type == "customer.subscription.updated":
                return self.handle_subscription_updated(event_id, data)
            elif event_type == "customer.subscription.deleted":
                return self.handle_subscription_deleted(event_id, data)
            else:
                logger.debug(f"No handler for event type: {event_type}")
                return True  # Return success for unhandled events we don't care about
        except IntegrityError as exc:
            self.db.rollback()
            logger.exception(
                f"Billing integrity error processing event {event_id}",
                extra={
                    "event_id": event_id,
                    "event_type": event_type,
                    "operation": "process_webhook_event",
                },
            )
            raise
        except Exception as e:
            logger.error(f"Error processing {event_type} event {event_id}: {str(e)}")
            raise
    
    def cancel_subscription(
        self,
        user_id: str
    ) -> None:
        """Business logic for canceling subscriptions"""
        subscription = self.db.query(Subscription).filter(
            Subscription.user_id == user_id,
            Subscription.status == "active"
        ).first()
        
        if not subscription:
            raise ValueError("No active subscription found")
        
        try:
            # Use gateway instead of direct Stripe call
            self.stripe_gateway.cancel_subscription(
                subscription.stripe_subscription_id,
                cancel_at_period_end=True
            )
            
            subscription.cancel_at_period_end = True
            subscription.updated_at = datetime.now(timezone.utc)
            self.db.commit()
        except Exception as e:
            self.db.rollback()
            raise Exception(f"Stripe error: {str(e)}")
        except IntegrityError as e:
            self.db.rollback()
            logger.error(f"Database integrity error canceling subscription: {str(e)}")
            raise
    
    def charge_usage(
        self,
        user_id: str,
        subscription_id: str,
        amount: Decimal,
        units: int,
        description: str
    ) -> bool:
        """Charge for usage with proper error handling"""
        try:
            with self.transaction_context():
                # Create usage record
                usage_record = UsageRecord(
                    user_id=user_id,
                    subscription_id=subscription_id,
                    amount=amount,
                    units=units,
                    description=description,
                    recorded_at=datetime.now(timezone.utc)
                )
                self.db.add(usage_record)
                
                # Update subscription usage metrics if needed
                subscription = self.db.query(Subscription).filter(
                    Subscription.id == subscription_id
                ).with_for_update().first()
                
                if subscription:
                    # Add your usage tracking logic here
                    subscription.updated_at = datetime.now(timezone.utc)
                
                self.db.flush()
            
            logger.info(f"Charged usage for user {user_id}: {description} ({units} units)")
            return True
            
        except IntegrityError as exc:
            self.db.rollback()
            logger.exception(
                "Billing integrity error",
                extra={
                    "subscription_id": subscription_id,
                    "user_id": user_id,
                    "operation": "charge_usage",
                },
            )
            raise
    
    def report_usage(
        self,
        subscription_item_id: str,
        quantity: int,
        timestamp: Optional[datetime] = None,
        action: str = "increment"
    ) -> bool:
        """Report usage to Stripe for metered billing"""
        try:
            if timestamp is None:
                timestamp = datetime.now(timezone.utc)
            
            # Use gateway to report usage
            result = self.stripe_gateway.report_usage(
                subscription_item_id=subscription_item_id,
                quantity=quantity,
                timestamp=int(timestamp.timestamp()),
                action=action
            )
            
            logger.info(f"Reported usage for subscription item {subscription_item_id}: {quantity} units")
            return True
        except Exception as e:
            logger.error(f"Failed to report usage: {str(e)}")
            return False
    
    def get_subscription_details(
        self,
        stripe_subscription_id: str
    ) -> Optional[Dict[str, Any]]:
        """Get subscription details from Stripe"""
        try:
            # Use gateway to get subscription details
            return self.stripe_gateway.get_subscription(stripe_subscription_id)
        except Exception as e:
            logger.error(f"Failed to get subscription details: {str(e)}")
            return None
    
    def update_subscription_plan(
        self,
        user_id: str,
        new_plan: str
    ) -> bool:
        """Update subscription plan"""
        subscription = self.db.query(Subscription).filter(
            Subscription.user_id == user_id,
            Subscription.status == "active"
        ).first()
        
        if not subscription:
            raise ValueError("No active subscription found")
        
        prices = {
            "pro": settings.STRIPE_PRICE_PRO,
            "business": settings.STRIPE_PRICE_BUSINESS,
            "enterprise": settings.STRIPE_PRICE_ENTERPRISE
        }
        
        new_price_id = prices.get(new_plan)
        if not new_price_id:
            raise ValueError(f"Invalid plan '{new_plan}'")
        
        try:
            # Use gateway to update subscription
            updated_subscription = self.stripe_gateway.update_subscription(
                subscription.stripe_subscription_id,
                new_price_id
            )
            
            # Update local database
            subscription.plan = new_plan
            subscription.updated_at = datetime.now(timezone.utc)
            self.db.commit()
            
            logger.info(f"Updated subscription for user {user_id} to plan {new_plan}")
            return True
        except Exception as e:
            self.db.rollback()
            logger.error(f"Failed to update subscription: {str(e)}")
            raise