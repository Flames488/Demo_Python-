import stripe
from decimal import Decimal

class StripeGateway:
    def __init__(self, api_key: str):
        stripe.api_key = api_key

    def report_usage(
        self,
        subscription_item_id: str,
        quantity: Decimal,
        idempotency_key: str,
    ):
        return stripe.UsageRecord.create(
            subscription_item=subscription_item_id,
            quantity=int(quantity),
            action="increment",
            idempotency_key=idempotency_key,
        )
