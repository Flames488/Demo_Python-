# models.py - COMPLETELY REWRITTEN
import uuid
from datetime import datetime, timedelta
from decimal import Decimal
from sqlalchemy import CheckConstraint, Index
from app.db import db


class User(db.Model):
    """User model with balance and subscription info"""
    __tablename__ = "users"
    
    id = db.Column(db.Integer, primary_key=True)
    email = db.Column(db.String(255), unique=True, nullable=False)
    balance = db.Column(db.Numeric(20, 4), default=0, nullable=False)  # Supports microtransactions
    subscription_active = db.Column(db.Boolean, default=False)
    subscription_ends_at = db.Column(db.DateTime)
    version = db.Column(db.Integer, default=0, nullable=False)  # Optimistic locking
    
    __table_args__ = (
        CheckConstraint('balance >= 0', name='non_negative_balance'),
        Index('idx_user_active', 'subscription_active', 'subscription_ends_at'),
    )
    
    def to_dict(self):
        return {
            'id': self.id,
            'balance': float(self.balance),
            'subscription_active': self.subscription_active,
            'version': self.version
        }


class BillingEvent(db.Model):
    """Immutable billing event log"""
    __tablename__ = "billing_events"
    
    id = db.Column(db.UUID, primary_key=True, default=uuid.uuid4)
    idempotency_key = db.Column(db.String(128), unique=True, nullable=False, index=True)
    correlation_id = db.Column(db.String(128), nullable=True, index=True)  # For external tracing
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False, index=True)
    amount = db.Column(db.Numeric(20, 4), nullable=False)  # Positive for credit, negative for debit
    currency = db.Column(db.String(10), default="NGN", nullable=False)
    status = db.Column(db.String(32), nullable=False, default='pending')  # pending, completed, failed
    description = db.Column(db.String(512))
    metadata = db.Column(db.JSON, default=dict)
    created_at = db.Column(db.DateTime, default=datetime.utcnow, nullable=False)
    completed_at = db.Column(db.DateTime)
    
    __table_args__ = (
        Index('idx_user_events', 'user_id', 'created_at'),
        Index('idx_event_status', 'status', 'created_at'),
    )
    
    # Relationships
    user = db.relationship('User', backref=db.backref('billing_events', lazy='dynamic'))
    ledger_entries = db.relationship('BillingLedger', backref='event', lazy='dynamic')


class BillingLedger(db.Model):
    """Double-entry accounting ledger for full audit trail"""
    __tablename__ = "billing_ledger"
    
    id = db.Column(db.UUID, primary_key=True, default=uuid.uuid4)
    event_id = db.Column(db.UUID, db.ForeignKey('billing_events.id'), nullable=False, index=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False, index=True)
    entry_type = db.Column(db.String(32), nullable=False)  # debit, credit, adjustment
    account = db.Column(db.String(64), nullable=False)  # wallet, revenue, refund_reserve
    amount = db.Column(db.Numeric(20, 4), nullable=False)
    balance_before = db.Column(db.Numeric(20, 4), nullable=False)
    balance_after = db.Column(db.Numeric(20, 4), nullable=False)
    reference = db.Column(db.String(128))  # External reference
    created_at = db.Column(db.DateTime, default=datetime.utcnow, nullable=False)
    
    __table_args__ = (
        Index('idx_ledger_user', 'user_id', 'created_at'),
        Index('idx_ledger_account', 'account', 'created_at'),
        CheckConstraint('amount != 0', name='non_zero_amount'),
    )
    
    # Relationships
    user = db.relationship('User', backref=db.backref('ledger_entries', lazy='dynamic'))


class UsageRecord(db.Model):
    """Usage tracking with window-based limits"""
    __tablename__ = "usage_records"
    
    id = db.Column(db.UUID, primary_key=True, default=uuid.uuid4)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False, index=True)
    feature = db.Column(db.String(64), nullable=False, index=True)
    period = db.Column(db.String(32), nullable=False, default='monthly')  # daily, weekly, monthly
    used = db.Column(db.Integer, default=0, nullable=False)
    limit = db.Column(db.Integer, nullable=False)
    reset_at = db.Column(db.DateTime, nullable=False, index=True)
    version = db.Column(db.Integer, default=0, nullable=False)  # Optimistic locking
    created_at = db.Column(db.DateTime, default=datetime.utcnow, nullable=False)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    __table_args__ = (
        Index('idx_user_feature', 'user_id', 'feature', 'reset_at'),
        CheckConstraint('used >= 0', name='non_negative_usage'),
        CheckConstraint('limit > 0', name='positive_limit'),
        db.UniqueConstraint('user_id', 'feature', 'reset_at', name='unique_user_feature_window'),
    )
    
    # Relationships
    user = db.relationship('User', backref=db.backref('usage_records', lazy='dynamic'))
    
    @property
    def is_expired(self):
        return datetime.utcnow() >= self.reset_at
    
    def reset_if_expired(self):
        if self.is_expired:
            self.used = 0
            # Set next reset time based on period
            now = datetime.utcnow()
            if self.period == 'daily':
                self.reset_at = now + timedelta(days=1)
            elif self.period == 'weekly':
                self.reset_at = now + timedelta(weeks=1)
            elif self.period == 'monthly':
                # Simple monthly calculation
                self.reset_at = now.replace(day=28) + timedelta(days=4)
            else:
                self.reset_at = now + timedelta(days=30)


class BillingLock(db.Model):
    """Distributed locking for user-level operations"""
    __tablename__ = "billing_locks"
    
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, unique=True, nullable=False, index=True)
    lock_id = db.Column(db.UUID, nullable=False)
    expires_at = db.Column(db.DateTime, nullable=False, index=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow, nullable=False)