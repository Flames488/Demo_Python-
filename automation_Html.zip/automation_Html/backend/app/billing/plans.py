PLAN_MAP = {
    "pro": {
        "duration_days": 30
    },
    "business": {
        "duration_days": 30
    }
}
