# middleware.py - COMPLETELY REWRITTEN
import uuid
import functools
from typing import Callable, Optional

from flask import request, jsonify, g
from werkzeug.exceptions import HTTPException

from app.billing.exceptions import (
    BillingError, SubscriptionInactiveError,
    InsufficientBalanceError, UsageLimitExceededError,
    DuplicateEventError
)


class BillingMiddleware:
    """Middleware for billing-related HTTP endpoints"""
    
    @staticmethod
    def require_active_subscription(view_func: Optional[Callable] = None):
        """
        Decorator to require active subscription.
        Returns 402 Payment Required if inactive.
        """
        def decorator(f):
            @functools.wraps(f)
            def decorated_function(*args, **kwargs):
                # Get user from request context (adjust based on your auth system)
                user = getattr(g, 'user', None)
                
                if not user:
                    return jsonify({
                        'error': 'Authentication required',
                        'code': 'auth_required'
                    }), 401
                
                if not user.get('subscription_active', False):
                    return jsonify({
                        'error': 'Subscription inactive',
                        'code': 'subscription_inactive',
                        'user_id': user.get('id'),
                        'help': 'Please update your payment method or contact support'
                    }), 402
                
                return f(*args, **kwargs)
            return decorated_function
        
        if view_func:
            return decorator(view_func)
        return decorator
    
    @staticmethod
    def require_idempotency_key(view_func: Optional[Callable] = None):
        """
        Decorator to require idempotency key for billing endpoints.
        Returns 400 Bad Request if missing.
        """
        def decorator(f):
            @functools.wraps(f)
            def decorated_function(*args, **kwargs):
                idempotency_key = request.headers.get('Idempotency-Key') or \
                                 request.json.get('idempotency_key') if request.json else None
                
                if not idempotency_key:
                    # Generate one if not provided (for non-critical operations)
                    if request.method in ['GET', 'HEAD']:
                        idempotency_key = f"read_{uuid.uuid4().hex}"
                    else:
                        return jsonify({
                            'error': 'Idempotency-Key header required',
                            'code': 'idempotency_key_required',
                            'help': 'Include Idempotency-Key header for safe retries'
                        }), 400
                
                # Store in request context
                g.idempotency_key = idempotency_key
                
                return f(*args, **kwargs)
            return decorated_function
        
        if view_func:
            return decorator(view_func)
        return decorator
    
    @staticmethod
    def handle_billing_errors(view_func: Optional[Callable] = None):
        """
        Decorator to handle billing errors and return appropriate HTTP responses.
        """
        def decorator(f):
            @functools.wraps(f)
            def decorated_function(*args, **kwargs):
                try:
                    return f(*args, **kwargs)
                except SubscriptionInactiveError as e:
                    return jsonify({
                        'error': str(e),
                        'code': 'subscription_inactive',
                        'user_id': e.user_id,
                        'help': 'Please renew your subscription'
                    }), 402
                except InsufficientBalanceError as e:
                    return jsonify({
                        'error': str(e),
                        'code': 'insufficient_balance',
                        'user_id': e.user_id,
                        'balance': e.balance,
                        'amount': e.amount,
                        'help': 'Please add funds to your account'
                    }), 402
                except UsageLimitExceededError as e:
                    return jsonify({
                        'error': str(e),
                        'code': 'usage_limit_exceeded',
                        'user_id': e.user_id,
                        'feature': e.feature,
                        'used': e.used,
                        'limit': e.limit,
                        'help': 'Please upgrade your plan for higher limits'
                    }), 429  # Too Many Requests
                except DuplicateEventError as e:
                    return jsonify({
                        'error': str(e),
                        'code': 'duplicate_event',
                        'idempotency_key': e.idempotency_key,
                        'help': 'Request already processed'
                    }), 409  # Conflict
                except BillingError as e:
                    return jsonify({
                        'error': str(e),
                        'code': 'billing_error',
                        'user_id': e.user_id,
                        'transaction_id': e.transaction_id
                    }), 400
                except HTTPException:
                    # Let Flask handle HTTP exceptions
                    raise
                except Exception as e:
                    # Log unexpected errors
                    # logger.error(f"Unexpected billing error: {str(e)}")
                    return jsonify({
                        'error': 'Internal billing error',
                        'code': 'internal_error',
                        'request_id': getattr(g, 'request_id', None)
                    }), 500
            return decorated_function
        
        if view_func:
            return decorator(view_func)
        return decorator
    
    @staticmethod
    def inject_correlation_id(view_func: Optional[Callable] = None):
        """
        Decorator to inject correlation ID for distributed tracing.
        Updated to work with RequestLogger middleware.
        """
        def decorator(f):
            @functools.wraps(f)
            def decorated_function(*args, **kwargs):
                # Use existing correlation ID if already set by RequestLogger
                correlation_id = getattr(g, 'correlation_id', None)
                
                if not correlation_id:
                    correlation_id = request.headers.get('X-Correlation-ID') or \
                                    request.headers.get('X-Request-ID') or \
                                    str(uuid.uuid4())
                    
                    # Store in request context
                    g.correlation_id = correlation_id
                
                # Add to response headers
                response = f(*args, **kwargs)
                if isinstance(response, tuple):
                    response, status, headers = response[0], response[1], {}
                    if len(response) > 2:
                        headers = response[2]
                    headers = headers or {}
                    headers['X-Correlation-ID'] = correlation_id
                    return response, status, headers
                elif hasattr(response, 'headers'):
                    response.headers['X-Correlation-ID'] = correlation_id
                    return response
                else:
                    return response
            return decorated_function
        
        if view_func:
            return decorator(view_func)
        return decorator


# Convenience decorators
require_active_subscription = BillingMiddleware.require_active_subscription
require_idempotency_key = BillingMiddleware.require_idempotency_key
handle_billing_errors = BillingMiddleware.handle_billing_errors
inject_correlation_id = BillingMiddleware.inject_correlation_id