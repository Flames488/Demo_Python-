# exceptions.py - UPDATED
class BillingError(Exception):
    """Base exception for billing errors"""
    def __init__(self, message: str, user_id: int = None, transaction_id: str = None):
        self.message = message
        self.user_id = user_id
        self.transaction_id = transaction_id
        super().__init__(self.message)


class SubscriptionInactiveError(BillingError):
    """Raised when user subscription is inactive"""
    def __init__(self, user_id: int):
        super().__init__(
            f"Subscription inactive for user {user_id}",
            user_id=user_id
        )


class UsageLimitExceededError(BillingError):
    """Raised when usage limit is exceeded"""
    def __init__(self, user_id: int, feature: str, used: int, limit: int):
        super().__init__(
            f"Usage limit exceeded for {feature}: {used}/{limit}",
            user_id=user_id
        )
        self.feature = feature
        self.used = used
        self.limit = limit


class DuplicateEventError(BillingError):
    """Raised when duplicate billing event is detected"""
    def __init__(self, idempotency_key: str):
        super().__init__(
            f"Duplicate billing event detected: {idempotency_key}",
            transaction_id=idempotency_key
        )
        self.idempotency_key = idempotency_key


class InsufficientBalanceError(BillingError):
    """Raised when user has insufficient balance"""
    def __init__(self, user_id: int, balance: int, amount: int):
        super().__init__(
            f"Insufficient balance: {balance} < {amount}",
            user_id=user_id
        )
        self.balance = balance
        self.amount = amount


class ConcurrentModificationError(BillingError):
    """Raised when optimistic locking fails"""
    def __init__(self, user_id: int, expected_version: int, actual_version: int):
        super().__init__(
            f"Concurrent modification detected for user {user_id}. "
            f"Expected version {expected_version}, got {actual_version}",
            user_id=user_id
        )


class BillingTransactionError(BillingError):
    """Raised when billing transaction fails"""
    def __init__(self, transaction_id: str, reason: str):
        super().__init__(
            f"Billing transaction {transaction_id} failed: {reason}",
            transaction_id=transaction_id
        )