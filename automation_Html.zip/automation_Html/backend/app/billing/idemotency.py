from sqlalchemy.orm import Session
from sqlalchemy.exc import IntegrityError
from datetime import datetime, timezone

from app.models.webhook_event import WebhookEvent


class IdempotencyService:
    """
    Guarantees exactly-once processing of Stripe webhook events.
    Uses Stripe's event.id as the ONLY idempotency key.
    """

    def __init__(self, db: Session):
        self.db = db

    def already_processed(self, stripe_event_id: str) -> bool:
        """Check if a Stripe event has already been processed."""
        return (
            self.db.query(WebhookEvent)
            .filter(WebhookEvent.stripe_event_id == stripe_event_id)
            .first()
            is not None
        )

    def mark_processed(
        self,
        stripe_event_id: str,
        event_type: str,
        payload: dict,
    ) -> None:
        """
        Must be called ONLY AFTER successful processing.
        """
        event = WebhookEvent(
            stripe_event_id=stripe_event_id,  # MUST be Stripe's event.id
            event_type=event_type,
            payload=payload,
            processed_at=datetime.now(timezone.utc),
        )

        try:
            self.db.add(event)
            self.db.commit()
        except IntegrityError:
            # Stripe retried the same event (duplicate stripe_event_id)
            self.db.rollback()