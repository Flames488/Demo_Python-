# webhook_integration.py
import stripe
import asyncio
import json
import hashlib
import hmac
from typing import Optional, Dict, Any, Callable, Awaitable
from datetime import datetime
from functools import wraps

from fastapi import Request, HTTPException, Depends, BackgroundTasks
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from starlette.requests import ClientDisconnected
from pydantic import BaseModel, Field
from slowapi import Limiter, _rate_limit_exceeded_handler
from slowapi.util import get_remote_address
from slowapi.errors import RateLimitExceeded
import structlog

from app.core.config import settings
from app.core.redis import redis_client
from app.core.security import SecurityManager
from app.models.webhook import WebhookEvent, WebhookLog
from app.database.session import get_db
from app.core.metrics import webhook_metrics
from app.core.circuit_breaker import CircuitBreaker

# Configure logging
logger = structlog.get_logger(__name__)

# Initialize Stripe
stripe.api_key = settings.STRIPE_SECRET_KEY
stripe.max_network_retries = 3

# Rate limiter
limiter = Limiter(key_func=get_remote_address)

# Circuit breaker for webhook processing
webhook_circuit_breaker = CircuitBreaker(
    failure_threshold=5,
    recovery_timeout=60,
    expected_exceptions=(HTTPException, stripe.error.StripeError)
)


class WebhookConfig(BaseModel):
    """Webhook configuration model"""
    secret: str
    tolerance: int = Field(default=300, ge=0, le=900)
    api_version: Optional[str] = None
    idempotency_enabled: bool = True
    max_retries: int = 3
    retry_delay: float = 1.0


class WebhookEventMetadata(BaseModel):
    """Metadata for webhook event processing"""
    event_id: str
    event_type: str
    livemode: bool
    created: datetime
    request_id: Optional[str] = None
    processing_start: datetime = Field(default_factory=datetime.utcnow)
    processing_end: Optional[datetime] = None
    processing_time_ms: Optional[float] = None
    attempts: int = 0


class WebhookVerifier:
    """Advanced webhook verification and processing class"""
    
    def __init__(self, config: WebhookConfig):
        self.config = config
        self.event_handlers: Dict[str, Callable[[stripe.Event], Awaitable[Any]]] = {}
        self._setup_stripe_api_version()
    
    def _setup_stripe_api_version(self):
        """Set Stripe API version if configured"""
        if self.config.api_version:
            stripe.api_version = self.config.api_version
    
    def register_handler(self, event_type: str):
        """Decorator to register event handlers"""
        def decorator(handler: Callable[[stripe.Event], Awaitable[Any]]):
            self.event_handlers[event_type] = handler
            return handler
        return decorator
    
    async def verify_signature(
        self,
        payload: bytes,
        sig_header: str,
        timestamp: Optional[int] = None
    ) -> bool:
        """Verify webhook signature with advanced validation"""
        
        # Parse signature header
        signatures = self._parse_signature_header(sig_header)
        
        if not signatures:
            logger.warning("No valid signatures found in header")
            return False
        
        # Generate expected signature
        signed_payload = f"{timestamp or ''}.{payload.decode('utf-8', errors='replace')}"
        expected_signature = hmac.new(
            self.config.secret.encode(),
            signed_payload.encode(),
            hashlib.sha256
        ).hexdigest()
        
        # Check if any signature matches using constant-time comparison
        return any(
            self._secure_compare(sig, expected_signature)
            for sig in signatures
        )
    
    def _parse_signature_header(self, sig_header: str) -> list:
        """Parse Stripe signature header"""
        signatures = []
        for item in sig_header.split(','):
            try:
                key, value = item.strip().split('=', 1)
                if key == 'v1':
                    signatures.append(value)
            except ValueError:
                continue
        return signatures
    
    @staticmethod
    def _secure_compare(a: str, b: str) -> bool:
        """Constant-time comparison to prevent timing attacks"""
        return hmac.compare_digest(a, b)
    
    async def process_event(
        self,
        event: stripe.Event,
        metadata: WebhookEventMetadata,
        background_tasks: BackgroundTasks
    ) -> Dict[str, Any]:
        """Process webhook event with retry logic and idempotency"""
        
        # Check idempotency
        if self.config.idempotency_enabled:
            processed = await self._check_idempotency(event.id)
            if processed:
                logger.info("Event already processed", event_id=event.id)
                return {"status": "already_processed", "event_id": event.id}
        
        # Get handler for event type
        handler = self.event_handlers.get(event.type)
        if not handler:
            logger.warning("No handler for event type", event_type=event.type)
            return {"status": "no_handler", "event_type": event.type}
        
        # Process with retry logic
        result = await self._process_with_retry(
            handler, event, metadata, background_tasks
        )
        
        # Store idempotency key
        if self.config.idempotency_enabled:
            await self._store_idempotency_key(event.id)
        
        return result
    
    async def _process_with_retry(
        self,
        handler: Callable,
        event: stripe.Event,
        metadata: WebhookEventMetadata,
        background_tasks: BackgroundTasks,
        attempt: int = 1
    ) -> Dict[str, Any]:
        """Process event with exponential backoff retry"""
        
        try:
            # Update metadata
            metadata.attempts = attempt
            
            # Execute handler
            result = await handler(event)
            
            # Log success
            await self._log_event(event, metadata, success=True)
            
            # Update metrics
            webhook_metrics.increment_success(event.type)
            
            return {
                "status": "success",
                "result": result,
                "attempts": attempt
            }
            
        except Exception as e:
            logger.error(
                "Event processing failed",
                event_id=event.id,
                attempt=attempt,
                error=str(e),
                exc_info=True
            )
            
            # Update metrics
            webhook_metrics.increment_failure(event.type)
            
            # Check if we should retry
            if attempt < self.config.max_retries and self._should_retry(e):
                # Exponential backoff
                delay = self.config.retry_delay * (2 ** (attempt - 1))
                logger.info("Retrying event", event_id=event.id, delay=delay)
                
                await asyncio.sleep(delay)
                
                # Retry in background
                background_tasks.add_task(
                    self._process_with_retry,
                    handler, event, metadata, background_tasks, attempt + 1
                )
                
                return {
                    "status": "retrying",
                    "attempt": attempt,
                    "next_attempt": attempt + 1
                }
            
            # Log failure
            await self._log_event(event, metadata, success=False, error=str(e))
            
            # Circuit breaker
            webhook_circuit_breaker.record_failure()
            
            return {
                "status": "failed",
                "error": str(e),
                "attempts": attempt
            }
    
    def _should_retry(self, error: Exception) -> bool:
        """Determine if error is retryable"""
        retryable_errors = (
            stripe.error.APIConnectionError,
            stripe.error.RateLimitError,
            stripe.error.Timeout,
            ConnectionError,
            TimeoutError,
            asyncio.TimeoutError
        )
        return isinstance(error, retryable_errors)
    
    async def _check_idempotency(self, event_id: str) -> bool:
        """Check if event was already processed"""
        key = f"webhook:idempotency:{event_id}"
        return await redis_client.exists(key)
    
    async def _store_idempotency_key(self, event_id: str):
        """Store idempotency key with TTL"""
        key = f"webhook:idempotency:{event_id}"
        await redis_client.setex(key, 86400, "processed")  # 24 hours
    
    async def _log_event(
        self,
        event: stripe.Event,
        metadata: WebhookEventMetadata,
        success: bool,
        error: Optional[str] = None
    ):
        """Log webhook event to database"""
        metadata.processing_end = datetime.utcnow()
        metadata.processing_time_ms = (
            metadata.processing_end - metadata.processing_start
        ).total_seconds() * 1000
        
        webhook_log = WebhookLog(
            event_id=event.id,
            event_type=event.type,
            livemode=event.livemode,
            created=event.created,
            processing_start=metadata.processing_start,
            processing_end=metadata.processing_end,
            processing_time_ms=metadata.processing_time_ms,
            attempts=metadata.attempts,
            success=success,
            error_message=error,
            payload=event.to_dict()
        )
        
        # Store in database (fire and forget)
        asyncio.create_task(self._store_log(webhook_log))
    
    async def _store_log(self, log: WebhookLog):
        """Async log storage"""
        try:
            async with get_db() as db:
                db.add(log)
                await db.commit()
        except Exception as e:
            logger.error("Failed to store webhook log", error=str(e))


# Dependency injection for webhook verifier
def get_webhook_verifier() -> WebhookVerifier:
    """Get webhook verifier instance"""
    config = WebhookConfig(
        secret=settings.STRIPE_WEBHOOK_SECRET,
        tolerance=settings.STRIPE_WEBHOOK_TOLERANCE,
        api_version=settings.STRIPE_API_VERSION,
        idempotency_enabled=settings.WEBHOOK_IDEMPOTENCY_ENABLED,
        max_retries=settings.WEBHOOK_MAX_RETRIES,
        retry_delay=settings.WEBHOOK_RETRY_DELAY
    )
    return WebhookVerifier(config)


# Main webhook endpoint with advanced features
@limiter.limit("10/minute")
async def handle_stripe_webhook(
    request: Request,
    background_tasks: BackgroundTasks,
    security: HTTPBearer = Depends(),
    verifier: WebhookVerifier = Depends(get_webhook_verifier)
):
    """
    Advanced Stripe webhook handler with:
    - Rate limiting
    - Authentication
    - Signature verification
    - Idempotency
    - Retry logic
    - Circuit breaking
    - Comprehensive logging
    """
    
    # Check circuit breaker
    if not webhook_circuit_breaker.allow_request():
        logger.warning("Circuit breaker open")
        raise HTTPException(
            status_code=503,
            detail="Service temporarily unavailable"
        )
    
    # Verify authentication
    credentials: HTTPAuthorizationCredentials = await security(request)
    if not SecurityManager.verify_webhook_token(credentials.credentials):
        raise HTTPException(status_code=403, detail="Invalid authentication token")
    
    try:
        # Read payload with timeout
        payload = await asyncio.wait_for(request.body(), timeout=5.0)
        sig_header = request.headers.get("stripe-signature")
        
        if not sig_header:
            raise HTTPException(status_code=400, detail="Missing Stripe signature")
        
        # Verify signature using our custom verifier
        timestamp = request.headers.get("stripe-signature-timestamp")
        
        if not await verifier.verify_signature(payload, sig_header, timestamp):
            webhook_circuit_breaker.record_failure()
            raise HTTPException(status_code=400, detail="Invalid signature")
        
        # Parse event
        try:
            event = stripe.Event.construct_from(
                json.loads(payload),
                stripe.api_key
            )
        except json.JSONDecodeError as e:
            raise HTTPException(status_code=400, detail=f"Invalid JSON: {str(e)}")
        except stripe.error.StripeError as e:
            raise HTTPException(status_code=400, detail=f"Stripe error: {str(e)}")
        
        # Create metadata
        metadata = WebhookEventMetadata(
            event_id=event.id,
            event_type=event.type,
            livemode=event.livemode,
            created=datetime.fromtimestamp(event.created),
            request_id=request.headers.get("stripe-request-id")
        )
        
        # Process event
        result = await verifier.process_event(event, metadata, background_tasks)
        
        # Update circuit breaker on success
        webhook_circuit_breaker.record_success()
        
        # Return appropriate response
        return {
            "status": "received",
            "event_id": event.id,
            "processing_result": result
        }
        
    except asyncio.TimeoutError:
        logger.error("Request timeout")
        raise HTTPException(status_code=408, detail="Request timeout")
    except ClientDisconnected:
        logger.warning("Client disconnected")
        raise HTTPException(status_code=499, detail="Client disconnected")
    except RateLimitExceeded:
        raise HTTPException(status_code=429, detail="Rate limit exceeded")


# Error handler for rate limiting
async def rate_limit_exceeded_handler(request: Request, exc: RateLimitExceeded):
    """Custom rate limit exceeded handler"""
    logger.warning("Rate limit exceeded", client_ip=get_remote_address(request))
    raise HTTPException(
        status_code=429,
        detail={
            "error": "rate_limit_exceeded",
            "message": "Too many requests",
            "retry_after": exc.retry_after
        }
    )


# Example event handlers using the decorator
@verifier.register_handler("payment_intent.succeeded")
async def handle_payment_succeeded(event: stripe.Event):
    """Handle successful payment"""
    payment_intent = event.data.object
    
    # Your business logic here
    logger.info("Payment succeeded", payment_intent_id=payment_intent.id)
    
    # Example: Update order status, send confirmation email, etc.
    return {"processed": True, "payment_intent": payment_intent.id}


@verifier.register_handler("charge.refunded")
async def handle_charge_refunded(event: stripe.Event):
    """Handle charge refund"""
    charge = event.data.object
    
    logger.info("Charge refunded", charge_id=charge.id)
    
    # Your business logic here
    return {"processed": True, "charge_id": charge.id}


# Health check endpoint for webhook service
async def webhook_health_check():
    """Health check for webhook service"""
    return {
        "status": "healthy",
        "timestamp": datetime.utcnow().isoformat(),
        "circuit_breaker": webhook_circuit_breaker.status(),
        "handlers_registered": len(verifier.event_handlers)
    }