import stripe
from flask import Blueprint, jsonify, request
from core.config import settings

bp = Blueprint("billing", __name__)

@bp.route("/create-checkout-session", methods=["POST"])
def create_checkout():
    session = stripe.checkout.Session.create(
        mode="subscription",
        payment_method_types=["card"],
        line_items=[{
            "price": settings.STRIPE_PRICE_ID,
            "quantity": 1
        }],
        success_url="https://yourdomain.com/success",
        cancel_url="https://yourdomain.com/cancel",
    )
    return jsonify({"url": session.url})
