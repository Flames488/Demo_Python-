"""
Flask Application Factory and Configuration.
Professional-grade application setup with advanced features.
"""

import time
import uuid
import logging
from functools import wraps
from typing import Set, Dict, Any, Optional, Callable
from contextlib import contextmanager

from flask import Flask, request, g, jsonify, current_app, Response, abort
from flask_jwt_extended import (
    verify_jwt_in_request, 
    jwt_required, 
    get_current_user,
    JWTManager,
    decode_token,
    get_jwt_identity,
    create_access_token,
    get_jwt
)
from app.webhook import verify_stripe_webhook
from flask_cors import CORS
from werkzeug.middleware.proxy_fix import ProxyFix
from prometheus_flask_exporter import PrometheusMetrics
import sentry_sdk
from sentry_sdk.integrations.flask import FlaskIntegration

from app.config.settings import Config
from app.extensions import db, login_manager, migrate, cache, limiter
from app.core.errors import (
    register_error_handlers,
    AppError,
    ValidationError,
    AuthenticationError,
    AuthorizationError,
    NotFoundError,
    RateLimitError,
    DatabaseError,
    ExternalServiceError,
    error_handler_decorator,
    error_context
)
from app.utils.logging import setup_logging, RequestContextFilter
from app.middleware.request_logger import RequestLogger
from app.middleware.rate_limiter import RateLimiterMiddleware
# Removed problematic import - will handle subscription differently
# from subscription.middleware import subscription_required

# Import transaction management
from app.db.session import (
    get_db_session,
    transactional,
    TransactionContext,
    TransactionType,
    setup_flask_db,
    DatabaseHealth
)
from app.infrastructure.env_validation import validate_env

validate_env()  # 🚨 Fail fast if env is broken

# Import unified middleware system
from app.middleware import GlobalMiddlewareManager, init_middleware, public_route, require_tier

# Public routes that don't require authentication
PUBLIC_ROUTES: Set[str] = {
    "/api/auth/login",
    "/api/auth/register",
    "/api/auth/refresh",
    "/api/auth/forgot-password",
    "/api/auth/reset-password",
    "/health",
    "/api/health",
    "/metrics",
    "/docs",
    "/swagger",
    "/favicon.ico",
    "/webhooks",
    "/api/db/health",
}

# Read-only routes that don't need subscription checks
READONLY_ROUTES: Set[str] = {
    "/api/tasks",
    "/api/gmail/threads",
    "/api/billing/plans",
}

# Rate limiting exempt routes
RATE_LIMIT_EXEMPT_ROUTES: Set[str] = {
    "/health",
    "/api/health",
    "/metrics",
    "/api/db/health",
}

# Global variables for utility functions
_current_request_path: str = ""


@contextmanager
def timing_context(name: str):
    """Context manager for timing operations."""
    start_time = time.perf_counter()
    try:
        yield
    finally:
        duration = time.perf_counter() - start_time
        current_app.logger.debug(
            f"operation_completed",
            extra={
                "operation": name,
                "duration_seconds": round(duration, 4),
                "request_id": getattr(g, "request_id", None)
            }
        )


def setup_monitoring(app: Flask) -> None:
    """Initialize monitoring and observability tools."""
    # Initialize Sentry for error tracking
    if app.config.get("SENTRY_DSN"):
        sentry_sdk.init(
            dsn=app.config["SENTRY_DSN"],
            integrations=[FlaskIntegration()],
            traces_sample_rate=app.config.get("SENTRY_TRACES_SAMPLE_RATE", 1.0),
            environment=app.config.get("ENVIRONMENT", "production"),
            release=app.config.get("RELEASE_VERSION", "1.0.0"),
        )
        app.logger.info("sentry_initialized")
    
    # Initialize Prometheus metrics
    if app.config.get("ENABLE_METRICS", False):
        metrics = PrometheusMetrics(app)
        app.metrics = metrics
        app.logger.info("prometheus_metrics_initialized")


def setup_middleware(app: Flask) -> None:
    """Setup application middleware."""
    # Handle reverse proxy headers
    if app.config.get("BEHIND_PROXY", False):
        app.wsgi_app = ProxyFix(
            app.wsgi_app,
            x_for=app.config.get("PROXY_FIX_X_FOR", 1),
            x_proto=app.config.get("PROXY_FIX_X_PROTO", 1),
            x_host=app.config.get("PROXY_FIX_X_HOST", 1),
            x_port=app.config.get("PROXY_FIX_X_PORT", 1),
            x_prefix=app.config.get("PROXY_FIX_X_PREFIX", 1),
        )
        app.logger.info("proxy_fix_middleware_initialized")
    
    # Initialize unified global middleware system
    init_middleware(app)
    app.logger.info("global_middleware_initialized")
    
    # Initialize rate limiting middleware (as backup to global system)
    if app.config.get("ENABLE_RATE_LIMITING", True):
        RateLimiterMiddleware(app)
        app.logger.info("rate_limiter_middleware_initialized")
    
    # Setup database transaction middleware
    setup_database_middleware(app)


def setup_database_middleware(app: Flask) -> None:
    """Setup database transaction middleware with automatic rollback."""
    
    @app.before_request
    def start_database_transaction():
        """Start a database transaction for this request."""
        # Skip for public routes that don't need database access
        if is_public_route(request.path) and not request.path.startswith("/api/"):
            return
        
        # Create database session with transaction context
        from app.db.session import get_db_session, TransactionType
        
        # Determine transaction type based on request method
        if request.method in ["GET", "HEAD", "OPTIONS"]:
            transaction_type = TransactionType.READ_ONLY
        else:
            transaction_type = TransactionType.READ_WRITE
        
        # Start transaction context
        try:
            db_context = get_db_session(transaction_type=transaction_type)
            g.db_context = db_context
            g.db = db_context.__enter__()
            
            app.logger.debug(
                f"Database transaction started: type={transaction_type}, "
                f"method={request.method}, path={request.path}"
            )
        except Exception as e:
            app.logger.error(f"Failed to start database transaction: {e}")
            # Don't raise here, let the request continue without DB if possible
    
    @app.after_request
    def commit_database_transaction(response: Response) -> Response:
        """Commit or rollback database transaction based on response status."""
        if hasattr(g, 'db_context') and hasattr(g, 'db'):
            try:
                # Check if we should commit or rollback
                if response.status_code >= 200 and response.status_code < 400:
                    # Successful request, commit transaction
                    try:
                        g.db.commit()
                        app.logger.debug(f"Database transaction committed for request {g.get('request_id', 'unknown')}")
                    except Exception as e:
                        app.logger.error(f"Failed to commit transaction: {e}")
                        g.db.rollback()
                else:
                    # Error response, rollback transaction
                    try:
                        g.db.rollback()
                        app.logger.debug(f"Database transaction rolled back due to error {response.status_code}")
                    except Exception as e:
                        app.logger.error(f"Failed to rollback transaction: {e}")
            except Exception as e:
                app.logger.error(f"Error handling database transaction: {e}")
            finally:
                # Clean up database context
                try:
                    g.db_context.__exit__(None, None, None)
                except Exception as e:
                    app.logger.debug(f"Error exiting db context: {e}")
                
                # Close session
                try:
                    g.db.close()
                except Exception as e:
                    app.logger.debug(f"Error closing db session: {e}")
                
                # Remove from g object
                for attr in ['db_context', 'db']:
                    try:
                        delattr(g, attr)
                    except Exception:
                        pass
        
        return response
    
    @app.teardown_request
    def cleanup_database_on_exception(exception=None):
        """Clean up database resources if an exception occurs."""
        if exception and hasattr(g, 'db'):
            app.logger.error(f"Request teardown with exception, cleaning up database: {exception}")
            try:
                if hasattr(g, 'db_context'):
                    g.db_context.__exit__(type(exception), exception, None)
            except Exception:
                pass
            try:
                if g.db.is_active:
                    g.db.rollback()
                g.db.close()
            except Exception:
                pass
    
    app.logger.info("database_transaction_middleware_initialized")


def create_app(config_class: type = Config) -> Flask:
    """
    Advanced application factory for creating Flask app instances.
    
    Args:
        config_class: Configuration class to use
        
    Returns:
        Flask application instance
    """
    app = Flask(__name__, instance_relative_config=True)
    
    # Load configuration with priority:
    # 1. Instance config (instance/config.py)
    # 2. Environment-specific config
    # 3. Default config class
    app.config.from_object(config_class)
    
    # Load instance config if it exists
    try:
        app.config.from_pyfile('config.py', silent=True)
    except Exception:
        pass
    
    # Load environment-specific config
    env_config = f"config.{app.config.get('ENVIRONMENT', 'production').lower()}"
    try:
        app.config.from_object(env_config)
    except ImportError:
        app.logger.warning(f"environment_config_not_found: {env_config}")
    
    # Initialize logging FIRST
    setup_logging(app)
    app.logger = logging.getLogger(__name__)
    
    # Add request context filter to logger
    app.logger.addFilter(RequestContextFilter())
    
    # Setup monitoring and observability
    setup_monitoring(app)
    
    # Setup middleware (includes unified global middleware)
    setup_middleware(app)
    
    # Setup database transaction management
    setup_flask_db(app)
    
    # Register request logging middleware
    RequestLogger.middleware(app)
    
    # Configure CORS
    configure_cors(app)
    
    # Initialize extensions
    initialize_extensions(app)
    
    # Add security headers
    register_security_headers(app)
    
    # Register application components
    register_blueprints(app)
    register_error_handlers(app)
    register_cli_commands(app)
    register_request_handlers(app)
    register_teardown_handlers(app)
    register_billing_routes(app)
    
    # Create database tables if needed
    initialize_database(app)
    
    # Final initialization log
    app.logger.info(
        "app_initialized",
        extra={
            "app_name": app.config.get("APP_NAME"),
            "environment": app.config.get("ENVIRONMENT"),
            "version": app.config.get("API_VERSION"),
            "debug": app.debug,
            "release": app.config.get("RELEASE_VERSION", "unknown"),
            "database_transactions": True,
            "global_middleware": True
        }
    )
    
    return app


def configure_cors(app: Flask) -> None:
    """Configure CORS with advanced options."""
    origins = app.config.get("CORS_ALLOWED_ORIGINS", [])
    
    # Convert origins to strings if needed
    origin_strings = []
    for origin in origins:
        if hasattr(origin, "__str__"):
            origin_strings.append(str(origin))
        else:
            origin_strings.append(origin)
    
    # Development defaults
    if not origin_strings and app.config.get("ENVIRONMENT") == "development":
        origin_strings = ["http://localhost:3000", "http://localhost:8080"]
        app.logger.warning("cors_using_development_defaults")
    
    CORS(
        app,
        origins=origin_strings,
        supports_credentials=app.config.get("CORS_SUPPORTS_CREDENTIALS", True),
        allow_headers=app.config.get("CORS_ALLOW_HEADERS", [
            "Content-Type",
            "Authorization",
            "X-Request-ID",
            "X-API-Version",
            "X-Client-Version",
            "X-API-Key"
        ]),
        methods=app.config.get("CORS_ALLOW_METHODS", ["GET", "POST", "PUT", "DELETE", "OPTIONS", "PATCH"]),
        expose_headers=app.config.get("CORS_EXPOSE_HEADERS", [
            "X-Request-ID",
            "X-RateLimit-Limit",
            "X-RateLimit-Remaining",
            "X-RateLimit-Reset",
            "X-Correlation-ID"
        ]),
        max_age=app.config.get("CORS_MAX_AGE", 600)
    )
    
    app.logger.info(
        "cors_configured",
        extra={
            "origin_count": len(origin_strings),
            "supports_credentials": app.config.get("CORS_SUPPORTS_CREDENTIALS", True)
        }
    )


def register_security_headers(app: Flask) -> None:
    """Register advanced security headers middleware."""
    
    @app.after_request
    def add_security_headers(response: Response) -> Response:
        """Add comprehensive security headers to all responses."""
        
        # Content Security Policy (CSP)
        csp_directives = [
            "default-src 'self'",
            "script-src 'self' 'unsafe-inline' 'unsafe-eval'",
            "style-src 'self' 'unsafe-inline' https://fonts.googleapis.com",
            "font-src 'self' https://fonts.gstatic.com",
            "img-src 'self' data: https:",
            "connect-src 'self'",
            "frame-ancestors 'none'",
            "base-uri 'self'",
            "form-action 'self'"
        ]
        
        if app.config.get("ENVIRONMENT") == "production":
            response.headers["Content-Security-Policy"] = "; ".join(csp_directives)
        
        # Security headers
        security_headers = {
            "X-Content-Type-Options": "nosniff",
            "X-Frame-Options": "DENY",
            "X-XSS-Protection": "1; mode=block",
            "Referrer-Policy": "strict-origin-when-cross-origin",
            "Permissions-Policy": "camera=(), microphone=(), geolocation=(), interest-cohort=()",
            "Cross-Origin-Embedder-Policy": "require-corp",
            "Cross-Origin-Opener-Policy": "same-origin",
            "Cross-Origin-Resource-Policy": "same-origin"
        }
        
        for header, value in security_headers.items():
            response.headers[header] = value
        
        # HSTS - only in production over HTTPS
        if app.config.get("ENVIRONMENT") == "production" and request.is_secure:
            response.headers["Strict-Transport-Security"] = (
                "max-age=31536000; includeSubDomains; preload"
            )
        
        # Custom headers
        response.headers["X-API-Version"] = app.config.get("API_VERSION", "1.0")
        response.headers["X-Content-Duration"] = str(getattr(g, "request_duration", 0))
        
        # Add correlation ID if available
        if hasattr(g, 'request_id'):
            response.headers["X-Request-ID"] = g.request_id
        
        # Database transaction info (for debugging)
        if app.debug and hasattr(g, 'db'):
            response.headers["X-DB-Transaction"] = "active" if g.db.is_active else "inactive"
        
        # Cache control for API responses
        if request.path.startswith("/api/"):
            response.headers["Cache-Control"] = "no-store, no-cache, must-revalidate, max-age=0"
            response.headers["Pragma"] = "no-cache"
            response.headers["Expires"] = "0"
        
        return response
    
    app.logger.debug("security_headers_registered")


def initialize_extensions(app: Flask) -> None:
    """Initialize all Flask extensions with proper error handling."""
    
    # Initialize JWT Manager first (before other extensions that might depend on it)
    jwt_manager = JWTManager(app)
    app.jwt_manager = jwt_manager
    
    extensions = [
        ("sqlalchemy", db.init_app, [app]),
        ("login_manager", login_manager.init_app, [app]),
        ("cache", cache.init_app, [app]),
    ]
    
    for name, init_func, args in extensions:
        try:
            with timing_context(f"initialize_{name}"):
                init_func(*args)
            app.logger.debug(f"extension_initialized", extra={"extension": name})
        except Exception as e:
            app.logger.error(
                f"extension_initialization_failed",
                extra={
                    "extension": name,
                    "error": str(e),
                    "exception_type": type(e).__name__
                }
            )
            if app.config.get("ENVIRONMENT") == "production":
                raise
    
    # Initialize Flask-Migrate if database is configured
    if app.config.get("SQLALCHEMY_DATABASE_URI"):
        try:
            migrate.init_app(app, db)
            app.logger.debug("flask_migrate_initialized")
        except Exception as e:
            app.logger.error(
                "migration_extension_failed",
                extra={
                    "error": str(e),
                    "exception_type": type(e).__name__
                }
            )
    
    # Initialize rate limiter
    if hasattr(app, "limiter"):
        app.limiter.init_app(app)
        app.logger.debug("rate_limiter_initialized")


def register_blueprints(app: Flask) -> None:
    """Register all application blueprints with versioning support."""
    
    # API version mapping
    api_versions = {
        "v1": {
            "auth": "/api/v1/auth",
            "gmail": "/api/v1/gmail",
            "tasks": "/api/v1/tasks",
            "admin": "/api/v1/admin",
            "billing": "/api/v1/billing",
            "webhooks": "/api/v1/webhooks"
        }
    }
    
    current_version = app.config.get("API_VERSION", "v1")
    version_prefixes = api_versions.get(current_version, {})
    
    blueprints_to_register = []
    
    try:
        from app.api.v1.auth import bp as auth_bp_v1
        from app.api.v1.gmail import bp as gmail_bp_v1
        from app.api.v1.tasks import bp as tasks_bp_v1
        from app.api.v1.admin import bp as admin_bp_v1
        from app.api.v1.billing import bp as billing_bp_v1
        
        blueprints_to_register.extend([
            (auth_bp_v1, version_prefixes.get("auth", "/api/v1/auth")),
            (gmail_bp_v1, version_prefixes.get("gmail", "/api/v1/gmail")),
            (tasks_bp_v1, version_prefixes.get("tasks", "/api/v1/tasks")),
            (admin_bp_v1, version_prefixes.get("admin", "/api/v1/admin")),
            (billing_bp_v1, version_prefixes.get("billing", "/api/v1/billing"))
        ])
        
        # Try to import webhooks blueprint
        try:
            from app.api.v1.webhooks import bp as webhooks_bp_v1
            blueprints_to_register.append((webhooks_bp_v1, version_prefixes.get("webhooks", "/api/v1/webhooks")))
        except ImportError:
            app.logger.debug("webhooks_blueprint_not_found")
        
    except ImportError as e:
        app.logger.error(
            "v1_blueprint_import_failed",
            extra={
                "error": str(e),
                "exception_type": type(e).__name__
            },
            exc_info=True
        )
        # Fallback to non-versioned imports for backward compatibility
        try:
            from app.api.auth import bp as auth_bp
            from app.api.gmail import bp as gmail_bp
            from app.api.tasks import bp as tasks_bp
            from app.api.admin import bp as admin_bp
            from app.api.billing import bp as billing_bp
            
            blueprints_to_register.extend([
                (auth_bp, "/api/auth"),
                (gmail_bp, "/api/gmail"),
                (tasks_bp, "/api/tasks"),
                (admin_bp, "/api/admin"),
                (billing_bp, "/api/billing")
            ])
            
            # Try non-versioned webhooks
            try:
                from app.api.webhooks import bp as webhooks_bp
                blueprints_to_register.append((webhooks_bp, "/api/webhooks"))
            except ImportError:
                app.logger.debug("non_versioned_webhooks_blueprint_not_found")
            
        except ImportError as fallback_error:
            app.logger.critical(
                "blueprint_import_failed",
                extra={
                    "error": str(fallback_error),
                    "exception_type": type(fallback_error).__name__
                }
            )
            raise
    
    # Register all blueprints
    for bp, url_prefix in blueprints_to_register:
        try:
            app.register_blueprint(bp, url_prefix=url_prefix)
            app.logger.debug(
                "blueprint_registered",
                extra={
                    "blueprint": bp.name,
                    "url_prefix": url_prefix,
                    "version": current_version
                }
            )
        except Exception as e:
            app.logger.error(
                "blueprint_registration_failed",
                extra={
                    "blueprint": bp.name if hasattr(bp, "name") else "unknown",
                    "url_prefix": url_prefix,
                    "error": str(e),
                    "exception_type": type(e).__name__
                }
            )
            if app.config.get("ENVIRONMENT") == "production":
                raise
    
    app.logger.info(
        "blueprints_registered",
        extra={
            "count": len(blueprints_to_register),
            "api_version": current_version
        }
    )


def register_billing_routes(app: Flask) -> None:
    """Register billing routes from app.routes.billing module."""
    try:
        # Try to import billing module
        import app.routes.billing as billing_module
        
        if hasattr(billing_module, 'bp'):
            # Register as blueprint
            app.register_blueprint(billing_module.bp, url_prefix='/api/billing/v2')
            app.logger.info(
                "billing_routes_registered",
                extra={
                    "blueprint": billing_module.bp.name,
                    "url_prefix": "/api/billing/v2"
                }
            )
        elif hasattr(billing_module, 'router'):
            app.logger.warning(
                "billing_router_not_blueprint",
                extra={"router_type": type(billing_module.router).__name__}
            )
            # Could add conversion from FastAPI router to Flask routes here
        else:
            app.logger.warning("billing_module_has_no_blueprint_or_router")
    except ImportError as e:
        app.logger.debug(
            "billing_routes_not_found",
            extra={
                "error": str(e),
                "exception_type": type(e).__name__
            }
        )
    except Exception as e:
        app.logger.error(
            "billing_routes_registration_failed",
            extra={
                "error": str(e),
                "exception_type": type(e).__name__
            }
        )


def register_cli_commands(app: Flask) -> None:
    """Register CLI commands with advanced features."""
    try:
        from app.cli import register_commands
        register_commands(app)
        app.logger.info("cli_commands_registered")
    except ImportError as e:
        app.logger.warning(
            "cli_commands_not_found",
            extra={"error": str(e), "exception_type": type(e).__name__}
        )
    except Exception as e:
        app.logger.error(
            "cli_registration_failed",
            extra={"error": str(e), "exception_type": type(e).__name__}
        )
        if app.debug:
            raise


def register_request_handlers(app: Flask) -> None:
    """Register comprehensive request handlers."""
    
    @app.before_request
    def start_request_tracking() -> None:
        """Start request tracking with advanced metrics."""
        g.start_time = time.perf_counter()
        g.request_id = str(uuid.uuid4())
        g.request_start = time.time()
        
        # Store request context for logging
        g.request_context = {
            "id": g.request_id,
            "method": request.method,
            "path": request.path,
            "ip": request.remote_addr,
            "user_agent": request.user_agent.string if request.user_agent else None,
            "referrer": request.referrer
        }
        
        app.logger.info(
            "request_started",
            extra=g.request_context
        )
    
    @app.after_request
    def log_request_and_metrics(response: Response) -> Response:
        """Log request completion and collect metrics."""
        if hasattr(g, "start_time"):
            duration = time.perf_counter() - g.start_time
            g.request_duration = duration
            
            # Collect metrics
            status_category = f"{response.status_code // 100}xx"
            
            # Add user information if available
            user_info = {}
            try:
                user = getattr(g, 'user', None)
                if user and hasattr(user, "id"):
                    user_info["user_id"] = user.id
                    user_info["user_role"] = getattr(user, "role", "user")
                    user_info["auth_method"] = getattr(g, "auth_method", "unknown")
            except:
                pass
            
            # Add database transaction info
            db_info = {}
            if hasattr(g, 'db'):
                db_info["db_transaction_active"] = True
            
            # Log request completion
            app.logger.info(
                "request_completed",
                extra={
                    **g.request_context,
                    "status_code": response.status_code,
                    "status_category": status_category,
                    "duration_seconds": round(duration, 4),
                    "response_size": response.calculate_content_length(),
                    "auth_type": getattr(g, "auth_type", "none"),
                    **user_info,
                    **db_info
                }
            )
            
            # Add headers
            response.headers["X-Request-ID"] = g.request_id
            response.headers["Server-Timing"] = f"total;dur={duration*1000:.2f}"
            
            # Rate limiting headers
            if hasattr(g, "rate_limit"):
                response.headers.update(g.rate_limit)
        
        return response
    
    @app.after_request
    def cleanup_request_context(response: Response) -> Response:
        """Clean up request context to prevent memory leaks."""
        # Clean up Flask-G object except for essential items
        keep_keys = ['request_id', 'start_time', 'request_duration', 'user', 'auth_method']
        for key in list(g.__dict__.keys()):
            if key not in keep_keys and not key.startswith("_"):
                try:
                    delattr(g, key)
                except:
                    pass
        
        return response
    
    # Health check endpoint with detailed system info
    @app.route("/health")
    @app.route("/api/health")
    def health_check() -> Response:
        """Comprehensive health check endpoint."""
        health_data = {
            "status": "healthy",
            "service": app.config.get("APP_NAME", "flask-app"),
            "version": app.config.get("API_VERSION", "1.0"),
            "environment": app.config.get("ENVIRONMENT", "production"),
            "timestamp": time.time(),
            "request_id": getattr(g, "request_id", None),
            "uptime": getattr(app, "start_time", None),
            "database": "connected" if check_database_connection() else "disconnected",
            "cache": "connected" if check_cache_connection() else "disconnected",
            "database_details": DatabaseHealth.check_health() if check_database_connection() else None
        }
        
        return jsonify(health_data), 200
    
    # Enhanced metrics endpoint for Prometheus
    @app.route("/metrics")
    def metrics() -> Response:
        """Prometheus metrics endpoint with database metrics."""
        if not app.config.get("ENABLE_METRICS", False):
            return jsonify({"error": "metrics_disabled"}), 404
        
        from prometheus_client import generate_latest, CONTENT_TYPE_LATEST
        
        # Add custom database metrics
        metrics_data = generate_latest()
        
        return Response(
            metrics_data,
            mimetype=CONTENT_TYPE_LATEST
        )
    
    # Database health endpoint
    @app.route("/api/db/health")
    def db_health() -> Response:
        """Database health check endpoint."""
        health = DatabaseHealth.check_health()
        return jsonify(health), 200 if health.get("status") == "healthy" else 503
    
    # Example transaction-protected endpoint
    @app.route("/api/transaction-example", methods=["POST"])
    @require_tier('pro')  # Requires pro tier or higher
    @transactional(retry_on_deadlock=2)
    def transaction_example():
        """Example endpoint using transactional decorator."""
        try:
            data = request.get_json()
            
            # User is already authenticated by global middleware
            user = getattr(g, 'user', None)
            if not user:
                return jsonify({"error": "User not found"}), 404
            
            # Database operations are automatically in a transaction
            # Note: Need to import models inside function to avoid circular imports
            try:
                from app.models.payment import Payment
            except ImportError:
                # Fallback if Payment model doesn't exist
                return jsonify({"error": "Payment model not available"}), 500
            
            # Process payment (simulated)
            payment = Payment(
                user_id=user.id,
                amount=data.get('amount', 0),
                status='pending'
            )
            db.session.add(payment)
            db.session.flush()  # Get payment ID
            
            # Update user subscription
            user.subscription_level = 'premium'
            user.payment_id = payment.id
            
            # Update payment status
            payment.status = 'completed'
            
            # All operations succeed or all fail together
            return jsonify({
                "success": True,
                "message": "Payment processed and subscription upgraded",
                "payment_id": payment.id,
                "subscription_level": user.subscription_level
            })
            
        except Exception as e:
            app.logger.error(f"Transaction example failed: {e}")
            # Transaction will be automatically rolled back by decorator
            raise
    
    # Run job endpoint with advanced features and transaction support
    @app.route("/run-job", methods=["POST"])
    @require_tier('premium')  # Requires premium tier
    @transactional(retry_on_deadlock=1)
    def run_job() -> Response:
        """Advanced job execution endpoint with transaction support."""
        try:
            # User is already authenticated by global middleware
            user = getattr(g, 'user', None)
            if not user:
                return jsonify({"error": "Authentication required"}), 401
            
            # Validate input
            data = request.get_json()
            if not data:
                return jsonify({
                    "error": "invalid_input",
                    "message": "Request body must be JSON"
                }), 400
            
            # Generate job ID with prefix based on type
            job_type = data.get("type", "default")
            job_id = f"{job_type}_{uuid.uuid4().hex[:12]}"
            
            # Store job metadata
            g.job_metadata = {
                "id": job_id,
                "type": job_type,
                "user_id": user.id,
                "submitted_at": time.time()
            }
            
            # Log job submission
            app.logger.info(
                "job_submitted",
                extra={
                    "job_id": job_id,
                    "job_type": job_type,
                    "user_id": user.id,
                    "request_id": g.request_id
                }
            )
            
            # Process job with database operations
            try:
                from app.models.job import Job
                job_record = Job(
                    job_id=job_id,
                    user_id=user.id,
                    job_type=job_type,
                    status="submitted"
                )
                db.session.add(job_record)
            except ImportError:
                # Job model not available
                app.logger.warning("Job model not found, skipping database storage")
            
            # Process job asynchronously
            response_data = {
                "status": "accepted",
                "message": "Job submitted successfully",
                "job_id": job_id,
                "job_type": job_type,
                "estimated_completion": time.time() + 60,
                "status_url": f"/api/jobs/{job_id}/status",
                "request_id": g.request_id
            }
            
            return jsonify(response_data), 202
            
        except Exception as e:
            app.logger.error(
                "job_submission_failed",
                extra={
                    "error": str(e),
                    "exception_type": type(e).__name__,
                    "request_id": g.request_id,
                    "stack_trace": True
                },
                exc_info=True
            )
            
            # Transaction will be automatically rolled back by decorator
            error_response = {
                "status": "error",
                "message": "Failed to submit job",
                "error": str(e) if app.debug else "Internal server error",
                "error_code": "JOB_SUBMISSION_FAILED",
                "request_id": g.request_id,
                "docs": app.config.get("ERROR_DOCS_URL", "")
            }
            
            return jsonify(error_response), 500
    
    app.logger.debug("request_handlers_registered")


def register_teardown_handlers(app: Flask) -> None:
    """Register teardown handlers for resource cleanup."""
    
    @app.teardown_appcontext
    def shutdown_session(exception=None) -> None:
        """Clean up database session."""
        if db.session:
            if exception:
                db.session.rollback()
            else:
                try:
                    db.session.commit()
                except Exception as e:
                    app.logger.error(f"Error committing session: {e}")
                    db.session.rollback()
            db.session.remove()
    
    @app.teardown_request
    def cleanup_request_resources(exception=None) -> None:
        """Clean up request-specific resources."""
        # Close any open file handles, connections, etc.
        if hasattr(g, "db_connections"):
            for conn in g.db_connections:
                try:
                    conn.close()
                except:
                    pass
        
        # Ensure any remaining database sessions are closed
        if hasattr(g, 'db'):
            try:
                if hasattr(g.db, 'is_active') and g.db.is_active:
                    g.db.rollback()
                g.db.close()
            except:
                pass
    
    app.logger.debug("teardown_handlers_registered")


def initialize_database(app: Flask) -> None:
    """Initialize database with advanced features."""
    should_create_tables = (
        app.config.get("ENVIRONMENT") == "development" or
        app.config.get("CREATE_TABLES_ON_START", False)
    )
    
    if should_create_tables and app.config.get("SQLALCHEMY_DATABASE_URI"):
        try:
            with app.app_context():
                with timing_context("database_schema_creation"):
                    db.create_all()
                
                # Create initial data if needed
                if app.config.get("CREATE_INITIAL_DATA", False):
                    create_initial_data(app)
                
                app.logger.info(
                    "database_initialized",
                    extra={
                        "tables_created": True,
                        "initial_data": app.config.get("CREATE_INITIAL_DATA", False)
                    }
                )
                
        except Exception as e:
            app.logger.critical(
                "database_initialization_failed",
                extra={
                    "error": str(e),
                    "exception_type": type(e).__name__,
                    "stack_trace": True
                },
                exc_info=True
            )
            
            if app.config.get("ENVIRONMENT") in ["development", "staging"]:
                raise
    else:
        app.logger.debug("database_creation_skipped")


# Utility functions
def is_public_route(path: str) -> bool:
    """Check if a route is public."""
    return any(path.startswith(route) for route in PUBLIC_ROUTES)


def is_readonly_route(path: str) -> bool:
    """Check if a route is read-only."""
    return any(path.startswith(route) for route in READONLY_ROUTES)


def requires_subscription(path: str) -> bool:
    """Check if a route requires subscription."""
    # Subscription required for all non-public, non-readonly POST/PUT/PATCH/DELETE routes
    global _current_request_path
    current_path = _current_request_path or path
    
    return (
        not is_public_route(current_path) and
        not is_readonly_route(current_path) and
        request.method in ["POST", "PUT", "PATCH", "DELETE"]
    )


def check_database_connection() -> bool:
    """Check database connection."""
    try:
        db.session.execute("SELECT 1")
        return True
    except Exception:
        return False


def check_cache_connection() -> bool:
    """Check cache connection."""
    try:
        cache.set("health_check", "ok", timeout=1)
        return cache.get("health_check") == "ok"
    except Exception:
        return False


def create_initial_data(app: Flask) -> None:
    """Create initial database data."""
    # Implement initial data creation
    # This could include admin users, default settings, etc.
    pass


def create_fastapi_app() -> FastAPI:
    """
    Create a FastAPI application instance.
    This can be used alongside Flask or as a separate service.
    """
    from fastapi import FastAPI
    from slowapi.errors import RateLimitExceeded
    from slowapi.middleware import SlowAPIMiddleware
    from slowapi import _rate_limit_exceeded_handler
    
    # Import limiter if available, otherwise create a default one
    try:
        from app.infrastructure.rate_limiter import limiter
    except ImportError:
        # Create a default limiter if not available
        from slowapi import Limiter
        from slowapi.util import get_remote_address
        limiter = Limiter(key_func=get_remote_address)
    
    app = FastAPI(
        title="API Service",
        description="FastAPI application",
        version="1.0.0"
    )
    
    # Attach limiter
    app.state.limiter = limiter
    app.add_exception_handler(RateLimitExceeded, _rate_limit_exceeded_handler)
    app.add_middleware(SlowAPIMiddleware)
    
    # Import and include routers below
    # Example:
    # from app.api.fastapi_routers import router
    # app.include_router(router)
    
    return app


# Production entry point
def get_application() -> Flask:
    """
    Get the Flask application instance for production use.
    
    Returns:
        Flask application instance ready for WSGI servers
    """
    app = create_app()
    
    # Store app start time for uptime tracking
    app.start_time = time.time()
    
    return app


# Create Flask application instance for WSGI servers
app = get_application()

# Optional: Create FastAPI instance if needed
# fastapi_app = create_fastapi_app()