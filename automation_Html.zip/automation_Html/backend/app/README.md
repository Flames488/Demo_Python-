# Backend Service — Input Validation and API Documentation

## Overview
This package adds:

- strict request validation
- consistent success/error response envelope
- global exception handling
- OpenAPI 3 specification
- usage guidance for clients and contributors

These address:
- (6) Input validation and API guarantees
- (7) Documentation gaps

## Installation

1. Add dependency:
   - pydantic>=2
2. Copy `validation/` and `common/` folders into your backend project
3. Include error handlers and validators in your app factory

## How to enable validation

```
from validation.decorators import validate_body
from validation.schemas import UserCreate
from common.responses import success_response
from common.error_handlers import register_error_handlers

app = Flask(__name__)
register_error_handlers(app)

@app.route("/auth/register", methods=["POST"])
@validate_body(UserCreate)
def register():
    data = request.validated_body
    return success_response(message="User created", status=201)
```

## Error response contract

Every error returns:

```
{
  "status": "error",
  "code": "BAD_REQUEST",
  "message": "Invalid request body",
  "details": {...}
}
```

## Success response contract

```
{
  "status": "success",
  "code": "OK",
  "message": "success",
  "data": {}
}
```

## API Documentation

Full API schema resides in:
- docs/openapi.yaml

You can load it into Swagger UI or Postman.

## Contribution rules

- all new endpoints require:
  - schema-validated input
  - documented response
  - OpenAPI update
- avoid ad-hoc JSON responses
- never return raw exceptions

> **For production deployment**: See [README_PRODUCTION.md](README_PRODUCTION.md)