#!/usr/bin/env python
# scripts/validate_env.py
"""
Validate environment before deployment.
Run this before starting the app in production.
"""
import os
import sys
from pathlib import Path
import logging

# Add project root to path
BASE_DIR = Path(__file__).parent.parent
sys.path.insert(0, str(BASE_DIR))

def main():
    """Validate environment variables."""
    from dotenv import load_dotenv
    
    # Setup basic logging for script
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s - %(levelname)s - %(message)s'
    )
    logger = logging.getLogger(__name__)
    
    # Load .env if exists
    env_path = BASE_DIR / '.env'
    if env_path.exists():
        load_dotenv(env_path)
        logger.info(f"Loaded environment from {env_path}")
    
    # Import validation after loading env
    from config.validation import validate_config
    
    try:
        validate_config()
        logger.info("Environment validation passed")
        return 0
    except RuntimeError as e:
        logger.error(f"Validation failed: {e}")
        return 1
    except Exception as e:
        logger.error(f"Unexpected error: {e}", exc_info=True)
        return 1

if __name__ == '__main__':
    sys.exit(main())