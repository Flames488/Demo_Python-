from fastapi import HTTPException, status


def require_admin(user):
    if not user or not getattr(user, "is_admin", False):
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Admin only action"
        )