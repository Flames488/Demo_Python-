from flask import Flask, request
from flask_cors import CORS
from flask_limiter import Limiter
from flask_limiter.util import get_remote_address
from .config.settings import settings


def apply_security(app: Flask):

    # === CORS with explicit allowlist ===
    CORS(
        app,
        resources={r"/*": {"origins": [str(o) for o in settings.CORS_ALLOWED_ORIGINS]}},
        supports_credentials=True
    )

    # === Rate Limiting ===
    limiter = Limiter(
        get_remote_address,
        app=app,
        default_limits=[settings.RATE_LIMIT],
        storage_uri="memory://",
    )

    # === Security Headers ===
    @app.after_request
    def set_security_headers(response):
        response.headers["X-Content-Type-Options"] = "nosniff"
        response.headers["X-Frame-Options"] = "DENY"
        response.headers["X-XSS-Protection"] = "1; mode=block"
        response.headers["Strict-Transport-Security"] = (
            "max-age=63072000; includeSubDomains; preload"
            if settings.REQUIRE_HTTPS
            else ""
        )
        response.headers["Content-Security-Policy"] = (
            "default-src 'self'; frame-ancestors 'none'; object-src 'none'"
        )
        return response

    # === HTTPS Enforcement ===
    if settings.REQUIRE_HTTPS:
        @app.before_request
        def enforce_https():
            if not request.is_secure and request.headers.get("X-Forwarded-Proto", "http") != "https":
                return {"detail": "HTTPS is required"}, 400

    return app