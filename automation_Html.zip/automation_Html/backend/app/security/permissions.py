
from functools import wraps
from flask import g, jsonify

def admin_required(f):
    @wraps(f)
    def wrapper(*args, **kwargs):
        user = g.get('current_user')
        if not user or user.get('role') != 'admin':
            return jsonify({"error": "Admin permission required"}), 403
        return f(*args, **kwargs)
    return wrapper
