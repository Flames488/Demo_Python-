import click
from flask.cli import with_appcontext
from app.models.user import User
from app.models.task import Task
from app.extensions import db

@click.command("create-admin")
@click.argument("email")
@click.argument("password")
@with_appcontext
def create_admin(email, password):
    """Create an admin user"""
    if User.query.filter_by(email=email).first():
        click.echo(f"❌ User {email} already exists.")
        return
    
    admin = User(email=email, role="admin")
    admin.set_password(password)
    db.session.add(admin)
    db.session.commit()
    click.echo(f"✅ Admin user {email} created successfully.")

@click.command("list-users")
@with_appcontext
def list_users():
    """List all users"""
    users = User.query.all()
    if not users:
        click.echo("No users found.")
        return
    
    click.echo("📋 Users:")
    click.echo("-" * 50)
    for user in users:
        click.echo(f"ID: {user.id}")
        click.echo(f"Email: {user.email}")
        click.echo(f"Role: {user.role}")
        click.echo("-" * 30)

@click.command("create-user")
@click.argument("email")
@click.argument("password")
@click.option("--role", default="user", help="User role (default: user)")
@with_appcontext
def create_user(email, password, role):
    """Create a regular user"""
    if User.query.filter_by(email=email).first():
        click.echo(f"❌ User {email} already exists.")
        return
    
    user = User(email=email, role=role)
    user.set_password(password)
    db.session.add(user)
    db.session.commit()
    click.echo(f"✅ User {email} created with role '{role}'.")

@click.command("reset-password")
@click.argument("email")
@click.argument("new_password")
@with_appcontext
def reset_password(email, new_password):
    """Reset a user's password"""
    user = User.query.filter_by(email=email).first()
    if not user:
        click.echo(f"❌ User {email} not found.")
        return
    
    user.set_password(new_password)
    db.session.commit()
    click.echo(f"✅ Password reset for {email}.")

@click.command("cleanup-tasks")
@click.option("--days", default=30, help="Delete tasks older than X days")
@with_appcontext
def cleanup_tasks(days):
    """Clean up old tasks"""
    from datetime import datetime, timedelta
    from sqlalchemy import func
    
    cutoff_date = datetime.utcnow() - timedelta(days=days)
    
    # Assuming you have a created_at column
    if hasattr(Task, 'created_at'):
        old_tasks = Task.query.filter(Task.created_at < cutoff_date).all()
        count = len(old_tasks)
        
        for task in old_tasks:
            db.session.delete(task)
        
        db.session.commit()
        click.echo(f"✅ Deleted {count} tasks older than {days} days.")
    else:
        click.echo("❌ Task model doesn't have 'created_at' field.")

@click.command("init-db")
@with_appcontext
def init_db():
    """Initialize the database (create tables)"""
    db.create_all()
    click.echo("✅ Database tables created.")

# Register all commands
def register_commands(app):
    """Register all CLI commands with the Flask app"""
    app.cli.add_command(create_admin)
    app.cli.add_command(list_users)
    app.cli.add_command(create_user)
    app.cli.add_command(reset_password)
    app.cli.add_command(cleanup_tasks)
    app.cli.add_command(init_db)