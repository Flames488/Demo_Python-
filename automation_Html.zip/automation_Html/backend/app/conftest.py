import pytest
from app.main import create_app
from app.config import DevConfig
from app.extensions import db as _db
from app.models.user import User


@pytest.fixture(scope='session')
def app():
    """Create application for testing"""
    app = create_app(DevConfig)
    app.config['TESTING'] = True
    app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///:memory:'
    app.config['WTF_CSRF_ENABLED'] = False
    
    with app.app_context():
        yield app


@pytest.fixture(scope='session')
def db(app):
    """Create database for testing"""
    with app.app_context():
        _db.create_all()
        yield _db
        _db.session.remove()
        _db.drop_all()


@pytest.fixture(scope='function')
def db_session(db):
    """Create a new database session for each test"""
    connection = db.engine.connect()
    transaction = connection.begin()
    
    session = db.create_scoped_session(options={'bind': connection})
    db.session = session
    
    yield session
    
    transaction.rollback()
    connection.close()
    session.remove()


@pytest.fixture
def client(app):
    """Test client"""
    return app.test_client()


@pytest.fixture
def auth(client):
    """Authentication helper"""
    class AuthActions:
        def login(self, email='test@example.com', password='password123'):
            # Create user first if needed
            user = User.query.filter_by(email=email).first()
            if not user:
                user = User(email=email, role='user')
                user.set_password(password)
                _db.session.add(user)
                _db.session.commit()
            
            return client.post('/auth/login', data={
                'email': email,
                'password': password
            })
        
        def logout(self):
            return client.get('/auth/logout')
    
    return AuthActions()


@pytest.fixture
def runner(app):
    """CLI runner"""
    return app.test_cli_runner()