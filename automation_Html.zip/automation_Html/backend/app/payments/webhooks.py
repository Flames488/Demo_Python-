import hmac
import hashlib
import os
from flask import Blueprint, request, abort

from app.payments.paystack import verify_transaction
from app.payments.service import finalize_payment
from app.subscriptions.service import activate_subscription

bp = Blueprint("paystack_webhooks", __name__)

PAYSTACK_SECRET = os.getenv("PAYSTACK_SECRET_KEY")

def verify_signature(payload, signature):
    computed = hmac.new(
        PAYSTACK_SECRET.encode(),
        payload,
        hashlib.sha512
    ).hexdigest()
    return hmac.compare_digest(computed, signature)

@bp.route("/webhooks/paystack", methods=["POST"])
def paystack_webhook():
    signature = request.headers.get("x-paystack-signature")
    if not verify_signature(request.data, signature):
        abort(401)

    event = request.json
    if event["event"] == "charge.success":
        data = event["data"]
        reference = data["reference"]
        user_id = data["metadata"]["user_id"]

        finalize_payment(
            user_id=user_id,
            reference=reference,
            amount=data["amount"] // 100
        )

        activate_subscription(user_id)

    return {"status": "ok"}
