from abc import ABC, abstractmethod

class PaymentProvider(ABC):

    @abstractmethod
    def initialize(self, *, email: str, amount: int, reference: str):
        pass

    @abstractmethod
    def verify(self, *, reference: str):
        pass
