import uuid
import os
from app.payments.paystack import PaystackProvider
from app.payments.stripe import StripeProvider
from app.billing.service import create_billing_event

PROVIDER = os.getenv("PAYMENT_PROVIDER", "paystack")

def get_provider():
    if PROVIDER == "stripe":
        return StripeProvider()
    return PaystackProvider()

def start_payment(user, amount: int):
    """General payment initialization for any amount"""
    reference = f"pay_{uuid.uuid4().hex}"
    provider = get_provider()

    return provider.initialize(
        email=user.email,
        amount=amount,
        reference=reference
    )

def start_subscription_payment(user):
    """Specialized method for subscription payments with fixed amount"""
    reference = f"sub_{uuid.uuid4().hex}"
    provider = get_provider()
    
    # Fixed subscription amount: ₦5,000 for paystack, $ equivalent for stripe
    amount = 5000  # base amount in NGN
    
    if PROVIDER == "stripe":
        # Convert NGN 5000 to USD (approximate conversion)
        amount = amount / 780  # ~$6.41, adjust conversion rate as needed
    
    return provider.initialize(
        email=user.email,
        amount=amount,
        reference=reference
    )

def finalize_payment(*, user_id: int, reference: str, amount: int):
    """Finalize payment and create billing event"""
    create_billing_event(
        idempotency_key=reference,
        user_id=user_id,
        amount=amount,
        currency="USD" if PROVIDER == "stripe" else "NGN"
    )