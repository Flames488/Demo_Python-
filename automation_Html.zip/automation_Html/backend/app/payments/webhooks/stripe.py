import stripe, os
from flask import Blueprint, request, abort
from app.payments.service import finalize_payment
from app.subscriptions.service import activate_subscription

bp = Blueprint("stripe_webhooks", __name__)

@bp.route("/webhooks/stripe", methods=["POST"])
def stripe_webhook():
    payload = request.data
    sig = request.headers.get("Stripe-Signature")

    try:
        event = stripe.Webhook.construct_event(
            payload,
            sig,
            os.getenv("STRIPE_WEBHOOK_SECRET")
        )
    except stripe.error.SignatureVerificationError:
        abort(401)

    if event["type"] == "checkout.session.completed":
        session = event["data"]["object"]

        reference = session["metadata"]["reference"]
        user_id = session["metadata"]["user_id"]
        amount = session["amount_total"] // 100

        finalize_payment(
            user_id=user_id,
            reference=reference,
            amount=amount
        )

        activate_subscription(user_id)

    return {"status": "ok"}
