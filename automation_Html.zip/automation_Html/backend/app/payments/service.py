import uuid
from app.payments.paystack import initialize_transaction
from app.billing.service import create_billing_event

def start_subscription_payment(user):
    reference = f"sub_{uuid.uuid4().hex}"

    payment = initialize_transaction(
        email=user.email,
        amount=5000,  # example: ₦5,000
        reference=reference
    )

    return {
        "payment_url": payment["authorization_url"],
        "reference": reference
    }

def finalize_payment(*, user_id: int, reference: str, amount: int):
    create_billing_event(
        idempotency_key=reference,
        user_id=user_id,
        amount=amount,
        currency="NGN"
    )
