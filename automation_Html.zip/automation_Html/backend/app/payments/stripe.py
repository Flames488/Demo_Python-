import stripe
import os
from app.payments.base import PaymentProvider

stripe.api_key = os.getenv("STRIPE_SECRET_KEY")

class StripeProvider(PaymentProvider):

    def initialize(self, *, email: str, amount: int, reference: str):
        session = stripe.checkout.Session.create(
            payment_method_types=["card"],
            mode="payment",
            customer_email=email,
            line_items=[{
                "price_data": {
                    "currency": "usd",
                    "product_data": {"name": "Pro Subscription"},
                    "unit_amount": amount * 100,
                },
                "quantity": 1
            }],
            metadata={"reference": reference},
            success_url=os.getenv("STRIPE_SUCCESS_URL"),
            cancel_url=os.getenv("STRIPE_CANCEL_URL"),
        )

        return {
            "payment_url": session.url,
            "reference": reference
        }

    def verify(self, *, reference: str):
        # Stripe verification is webhook-driven (not polling)
        return True
