from pydantic import BaseModel, EmailStr, constr
from typing import Optional


class UserCreate(BaseModel):
    email: EmailStr
    password: constr(min_length=8)
    full_name: constr(min_length=2, max_length=80)


class UserLogin(BaseModel):
    email: EmailStr
    password: constr(min_length=8)


class TokenResponse(BaseModel):
    access_token: str
    refresh_token: Optional[str] = None
    token_type: str = "bearer"


class ErrorResponse(BaseModel):
    message: str
    code: str
    details: Optional[dict] = None