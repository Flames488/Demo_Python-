import functools
from flask import request
from pydantic import ValidationError
from validation.schemas import ErrorResponse


def validate_body(schema):
    def decorator(fn):
        @functools.wraps(fn)
        def wrapper(*args, **kwargs):
            try:
                json_data = request.get_json(force=True, silent=False)
                validated = schema(**json_data) if json_data is not None else schema()
            except ValidationError as e:
                return (
                    ErrorResponse(
                        message="Invalid request body",
                        code="BAD_REQUEST",
                        details=e.errors(),
                    ).dict(),
                    400,
                )
            except Exception:
                return (
                    ErrorResponse(
                        message="Malformed JSON body",
                        code="BAD_JSON",
                        details=None,
                    ).dict(),
                    400,
                )

            request.validated_body = validated
            return fn(*args, **kwargs)
        return wrapper
    return decorator