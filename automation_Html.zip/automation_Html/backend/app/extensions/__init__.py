from flask_sqlalchemy import SQLAlchemy
from flask_login import LoginManager
from flask_bcrypt import Bcrypt
# Add other extensions you're using

db = SQLAlchemy()
login_manager = LoginManager()
bcrypt = Bcrypt()
# Initialize other extensions here

# DO NOT call init_app here! That should happen in your app factory