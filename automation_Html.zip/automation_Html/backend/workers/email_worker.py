
from workers.celery_app import celery
from app.services.email_processor import process_email

@celery.task
def sync_emails():
    process_email("Test Email","This is a synced email")
