
from functools import wraps
from flask import abort

def require_active_subscription(fn):
    @wraps(fn)
    def wrapper(*args, **kwargs):
        # placeholder for Stripe lookup
        has_active = True
        if not has_active:
            abort(402)
        return fn(*args, **kwargs)
    return wrapper
